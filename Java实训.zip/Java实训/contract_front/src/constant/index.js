import $utils from "@/utils/help";

export default {
    role: $utils.buildLabVal(["超级管理员","部门经理","普通职员"],[0,1,2]),
    gender: $utils.buildLabVal(["男","女","未知"],[0,1,2]),
    BG: $utils.buildLabVal(["无部门","研发部", "设计部", "运营部", "市场部"], [0,1, 2, 3, 4]),
    BU: $utils.buildLabVal(["PC开发部", "IOS开发部", "UI设计", "视觉设计", "产品推广", "产品运营", "广告", "公关"], [1, 2, 3, 4, 5, 6, 7, 8]),
    industry: $utils.buildLabVal(["消费行业", "医药行业", "先进制造业", "文教行业"], [1, 2, 3, 4]),
    industryChild: $utils.buildLabVal(["食品", "服装", "医疗服务", "医疗机械", "传媒娱乐"], [1, 2, 3, 4, 5]),
    projectType: $utils.buildLabVal(["研发类项目", "软件产品实施", "开发项目"], [1, 2, 3]),
    region: $utils.buildLabVal(["华北", "华中", "华南"], [1, 2, 3]),
    organization: $utils.buildLabVal(["管理机构", "经营机构"], [1, 2]),
    province: $utils.buildLabVal(["安徽省", "浙江省", "江苏省", "河南省", "湖北省"], [1, 2, 3, 4, 5]),
    accountManager: $utils.buildLabVal(["李华", "张三", "李四"], [1, 2, 3]),
    productLine: $utils.buildLabVal(["采控", "客服", "综调"], [1, 2, 3]),
    customerOrgan: $utils.buildLabVal(["皖能合肥发电", "大数据有限公司"], [1, 2]),
    contractStatus: $utils.buildLabVal(["在途合同", "已验收合同"], [1, 2]),
    protectionTime: $utils.buildLabVal(["3年", "5年", "10年"], [1, 2, 3]),
    taxRate: $utils.buildLabVal(["0", "0.01", "0.03", "0.05"], [1, 2, 3, 4]),
    level: $utils.buildLabVal(["普通", "vip"], [1, 2]),
    city: $utils.buildLabVal(["合肥市", "芜湖市"], [1, 2]),
    county: $utils.buildLabVal(["肥西县", "肥东县"], [1, 2]),
}
