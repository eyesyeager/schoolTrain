<template>
  <el-card>
    <span>欢迎登录</span>
    <el-divider></el-divider>
    <el-form ref="resetform" :rules="rules">
      <el-form-item prop="account" >
        <el-input v-model="data.account" clearable placeholder="请输入用户名" />
      </el-form-item>

      <el-form-item prop="checkPassword">
        <el-input type="password" v-model="data.pass"  clearable placeholder="请输入密码"  />
      </el-form-item>

      <el-form-item v-if="data.commit" prop="identify">
        <el-input v-model="data.check" style="width : 235px;" clearable placeholder="请输入验证码"></el-input>
        &nbsp;&nbsp;<img :src="data.codeImg" style="height:30px;width:115px;" @click="check">
      </el-form-item>
      
      <p>
        <router-link to="/login/forget">忘记密码</router-link>
      </p>
      
      <el-form-item v-if="!data.commit">
        <el-button type="primary" v-if="!data.commit" @click="check">登录</el-button>
      </el-form-item>

      <el-form-item v-if="data.commit">
        <el-button type="primary" v-if="data.commit" @click="submitForm">登录</el-button>
      </el-form-item>

    </el-form>


 </el-card>

<first v-if = "data.dialogVisible" :account="data.account"></first>

</template>

<script>
import { defineComponent, reactive } from "vue";
import $api from "@/server/api"
import { useRouter } from "vue-router";
import $utils from "@/utils/help"
import first from '@/components/login/first.vue'
import anime from 'animejs/lib/anime.js';

export default defineComponent({
  name:'login_in',

  components: {
    first
  },

  setup() {
    const router = useRouter();

    anime({
      targets: '.red',
      strokeDashoffset: [anime.setDashoffset, 0],
      easing: 'easeInOutSine',
      duration: 1500,
      delay: function(el, i) { return i * 250 },
      direction: 'alternate',
      loop: true
    });

    let data = reactive({
      account:'',
      pass:'',
      commit: false,
      codeImg:'data:image/png;base64,',
      key:'',
      check:'',
      userAvatar:'',
      token:'',
      dialogVisible:false
    })

    async function check() {
      data.commit = true;
      data.codeImg = 'data:image/png;base64,'   
      console.log(data.account);
      await $api.check({
        id : parseInt(data.account)
      }).then(res => {
        if(res.code != 200){
          ElMessage.error("获取验证码失败");
        }else{
          console.log(res);
          data.key = res.data.code;
          data.codeImg = `${data.codeImg}${res.data.img}`;
        }
      });  
    }
    
    async function submitForm(){
        let password = $utils.encryption(data.pass);
        let test = $utils.encryption("rootroot");
        console.log("test",test);
        await $api.submitForm({
            id: parseInt(data.account),
            password : password,
            key : data.key,
            code : data.check
        })
        .then(res => {
          console.log("登录成功返回：", res);
          if(res.message == "用户名与密码不匹配，请检查后重新输入！"){
            data.commit = false;
            data.check = '';
            ElMessage.error("账号或密码错误")
          }else if(res.message == "验证码错误！"||res.message == "验证码错误"){
            ElMessage.error("验证码错误")
          }else if(res.message == "验证码失效"){
            ElMessage.error("验证码失效")
          }else if(res.message == "首次登录，需修改邮箱"){
           
            data.dialogVisible = true
          }else{
            localStorage.setItem("token", res.data.token);
            localStorage.setItem("role", $utils.obj2str({
              id: parseInt(data.account),
              role: res.data.role,
              avatar: res.data.avatar,
              name: res.data.name
            }));
            router.push("/contractBoard");
          }
      });
      }

      //校验用户名是否为空
      let validateAccount  = (rule, value, callback) => {
        if (data.account === ""){
          callback(new Error("用户名不能为空！"));
        }else 
          callback();
      };

      // 密码重复验证
      let validatePassword = (rule, value, callback) => {
        if (data.pass === "") {
          callback(new Error("密码不能为空！"));
        }else
          callback();
      };

      let validateIdentify = (rule, value, callback) => {
        if (data.pass === "") {
          callback(new Error("验证码不能为空！"));
        }else
          callback();
      };
      
      const rules = reactive({
        account: [
          {
            validator: validateAccount,
            trigger: "blur"
          }
        ],
        checkPassword: [
          {
            validator: validatePassword,
            trigger: "blur"
          }
        ],
        identify: [
          {
            validator: validateIdentify,
            trigger: "blur"
          }
        ]
      })

    return {
      data,
      check,
      submitForm,
      rules
    };
  }
});

</script>

<style lang="scss" scoped>
.el-card {
  position: absolute;
  color:#0b0b0b;
  top:50%;
  left:50%;
  transform: translate(-50%, -50%);
  width: 400px;
  background: linear-gradient(#436dc9, #58b7e3) left top,
  linear-gradient(#436dc9, #436dc9) left top,
  linear-gradient(#436dc9, #58b7e3) right top,
  linear-gradient(#436dc9, #436dc9) right top,
  linear-gradient(#58b7e3, #436dc9) left bottom,
  linear-gradient(#436dc9, #436dc9) left bottom,
  linear-gradient(#58b7e3, #436dc9) right bottom,
  linear-gradient(#436dc9, #436dc9) right bottom;
  background-repeat: no-repeat;
  background-size: 0.4vw 2.4vw, 2.4vw 0.4vw; 
  


}
span{
  font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  font-weight: bold;
  font-size: 30px;
  text-align: center;
  display:block;
}
.el-button{
  text-align: center;
  min-width: 357px;
}
.router-link-active {
  text-decoration: none;
  color: yellow;
}
a{
  text-decoration: none;
  color: rgb(54, 98, 211);
}
</style>