<template>
    <el-dialog  modelValue="data.dialogVisible" :close-on-click-modal="false" title="欢迎使用" :closable="false">
        <div v-if="data.num == 0" style="width: 480px;" v-loading = "data.auth_time > 55">
            <el-form-item prop="mail" label="绑定邮箱">
                <el-input style="width: 320px;" v-model="data.mail" clearable placeholder="请输入邮箱" ></el-input>
            </el-form-item>

            <el-form-item prop="mail" label="&nbsp&nbsp&nbsp验证码">
                <el-input style="width: 180px;" v-model="data.code" clearable placeholder="请输入验证码" autocomplete="off" ></el-input>
                &nbsp;&nbsp;
                <el-button type="info" v-show="data.sendAuthCode"  @click="getAuthCode">获取验证码</el-button>
                <el-button type="info" v-show="!data.sendAuthCode" >{{data.auth_time}}s后重新发送</el-button> 
            </el-form-item>

            <el-button type="primary" @click="submitmail, data.num = 1">确  认</el-button>
        </div>

        <div v-if="data.num == 1" >
           <el-form :rules="rules">
                <el-form-item  label="&nbsp&nbsp&nbsp新密码" prop="password">
                <el-input v-model="data.new_code" type="password" clearable placeholder="请输入密码" autocomplete="off"/>
                </el-form-item>

                <el-form-item label="确认密码"  prop="checkPassword">
                <el-input v-model="data.confirm_code" type="password" clearable placeholder="请再次输入" autocomplete="off" ></el-input>
                </el-form-item>
            </el-form>

            <el-button type="primary" @click="submitpassword">确认</el-button>

        </div>
    </el-dialog>
</template>

<script>
import { reactive } from "vue";
import $api from "@/server/api"
import $utils from "@/utils/help"
import router from '@/router';

export default {
    
    props:['account'],
    name : 'first',

    setup(props) {
        let data = reactive({
            dialogVisible : true,
            sendAuthCode : true,/*布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */
            auth_time : 0, /*倒计时 计数器*/
            num:0, //控制展示哪个面板
            mail:'',
            code:'',
            key:'',
            new_code:'',
            confirm_code:'',
            account:'',
            loading : false,
            can : false,
            can1 : false
        })
        
        data.account = props.account

        //获取邮箱验证码
        async function getAuthCode(){
            data.sendAuthCode = false
            data.auth_time = 60;
            var auth_timetimer = setInterval(()=>{
                data.auth_time--;
                if(data.auth_time<=0){
                    data.sendAuthCode = true;
                    clearInterval(auth_timetimer);
                }
            }, 1000);
            data.loading = true,
            console.log("dada",data.loading)

            await $api.getMailCode({
                email:data.mail,
                id: parseInt(data.account)
            }).then(res => {
                data.loading = false,
                console.log("res:", res);
                if(res.message == "邮箱有误"){
                    ElMessage.error("邮箱有误")
                }else{
                    data.key=res.data.key;
                    console.log(res)
                }
            });  
        }

        //提交新密码
        async function submitpassword(){
            if(data.can === false || data.can1 == false){
                ElMessage.error("输入错误！")
            }else{
                let password = $utils.encryption(data.new_code);
                await $api.submitpassword({
                    id: parseInt(data.account) ,
                    password,
                    code: data.code,
                    key:  data.key,
                    email: data.mail
                })
                .then(res => {
                    console.log(res)
                    if(res.massage == "修改失败！"){
                        ElMessage.error("响应超时！")
                    }else if(res.massage == "邮箱已注册"){
                        data.num == 0;
                        ElMessage.error("邮箱已注册")

                    }else{
                        
                        ElMessage.success("修改密码成功！")
                        router.go(0)
                        

                    }
                });  
            }
            
        }

        //校验密码是否为空
        let validatePassword  = (rule, value, callback) => {
            if (data.new_code === ""){
                data.can = false ;
                callback(new Error("密码不能为空！"));
            }else if(data.new_code.length < 8){
                data.can = false ;
                callback(new Error("密码长度不能少于8位！"));
            }else {
                data.can = true ;
                callback();
            }
        };

        // 密码重复验证
        let validateCheckPassword = (rule, value, callback) => {
            if (data.confirm_code === ""){
                data.can1 = false ;
                callback(new Error("密码不能为空！"));
            } 
            else if (data.confirm_code !== data.new_code) {
                data.can1 = false ;

                callback(new Error("密码不一致！"));
            } else{
                data.can1 = true;
                callback();
            } 
        };

        const rules = reactive({
        password: [
            {
            validator: validatePassword,
            trigger: "blur"
            }
        ],
        checkPassword: [
            {
            validator: validateCheckPassword,
            trigger: "blur"
            }
        ]
        })

        return {
            data,
            getAuthCode,
            rules,
            submitpassword
        };
    }
    
}
</script>

<style lang="scss">
.el-dialog{
    width:500px;
    height: auto;

    .el-form-item{
        margin-left: 5%;
        .el-button{
            min-width: 140px;
            height: 32px;
            margin-top: 0px;
            margin-bottom: 0px;
            margin-left: 0px;
        }
    }
    .el-button{
        margin-left: 8%;
        min-width: 80%;
        height: 40px;
        margin-top: 10px;
        margin-bottom: 20px;
    }
}
</style>