<template>
  <el-card> 
    <!-- 头部 -->
    <el-steps :active="data.active" finish-status="success">
        <el-step title="验证邮箱" />
        <el-step title="修改密码" />
        <el-step title="完成" />
    </el-steps>
    <el-divider></el-divider>
    <!-- 头部 -->

    <div v-if="data.num == 1" v-loading = "data.auth_time > 55">
        <el-form-item style="margin-top: 35px;" prop="account" label="用户名">
            <el-input v-model="data.account" clearable placeholder="请输入用户名" />
        </el-form-item>

        <el-form-item prop="mail" label="邮&nbsp&nbsp&nbsp箱">
            <el-input v-model="data.mail" clearable placeholder="请输入邮箱" ></el-input>
        </el-form-item>

        <el-form-item prop="mail" label="验证码">
            <el-input style="width: 230px;" v-model="data.code" clearable placeholder="请输入验证码" autocomplete="off" ></el-input>
            &nbsp;&nbsp;
            <el-button type="info" v-show="data.sendAuthCode"  @click="getAuthCode">{{}}获取验证码</el-button>
            <el-button type="info" v-show="!data.sendAuthCode" >{{data.auth_time}}s后重新发送</el-button> 
        </el-form-item>
        <el-button type="primary"  @click="submitmail">确认</el-button>
    </div>

    <div v-if="data.num == 2">
        <el-form :rules="rules">
            <el-form-item style="margin-top: 35px;" label="&nbsp&nbsp&nbsp新密码" prop="password">
            <el-input v-model="data.new_code" type="password" clearable placeholder="请输入密码" autocomplete="off"/>
            </el-form-item>

            <el-form-item label="确认密码" prop="checkPassword">
            <el-input v-model="data.confirm_code" type="password" clearable placeholder="请再次输入" autocomplete="off" ></el-input>
            </el-form-item>
        </el-form>

        <el-button type="primary" @click="submitpassword">确认</el-button>

    </div>

    <div v-if="data.num == 3">
        <el-result icon="success" title="修改密码成功"></el-result>
        <el-button type="primary" @click="to_login">返回登录界面</el-button>
    </div>


 </el-card>
</template>

<script>
import { defineComponent, reactive, ref } from "vue";
import $api from "@/server/api"
import {useRouter} from "vue-router";
import $utils from "@/utils/help"


export default defineComponent({
  name:'forget',

  setup() {

    const router = useRouter();

    let data = reactive({
        sendAuthCode:true,/*布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */
        auth_time: 0, /*倒计时 计数器*/
        active : ref(0),
        account:'',
        mail:'',
        key:'',
        num:1,
        code:'',
        //修改密码
        new_code:'',
        confirm_code:'',
        loading: false ,
        can : false,
        can1 : false
    })

    //请求发送验证码到邮箱，并保存验证码的key值
    async function getAuthCode(){
        data.sendAuthCode = false;
        data.auth_time = 60;
        var auth_timetimer =  setInterval(()=>{
            data.auth_time--;
            if(data.auth_time<=0){
                data.sendAuthCode = true;
                clearInterval(auth_timetimer);
            }
        }, 1000);
        await $api.getMailCode({
          id :parseInt(data.account) ,
          email :data.mail
        }).then(res => {
            if(res.message == "邮箱有误！" ){
              ElMessage.error("邮箱有误！请重新修改")
              data.active--;
              data.num--; 
            }else if(res.message == "操作失败！请联系管理员！"){
              ElMessage.error("操作失败！请联系管理员！")
            }else{
              data.key=res.data.key;
              console.log(res)
            }
        });  
    }

    //验证输入的邮箱验证码是否正确
    async function submitmail(){
      data.active++;
      data.num++; 
    }
    
    //提交新修改的密码
    async function submitpassword(){
        if(data.can === false || data.can1 == false){
          ElMessage.error("输入错误！")
        }else{
          let password = $utils.encryption(data.new_code);
          await $api.updatePsd({
              id: parseInt(data.account) ,
              password,
              code: data.code,
              key:  data.key,
              email: data.mail
          })
          .then(res => {
              if(res.message == "邮箱有误！" ){
                ElMessage.error("邮箱有误！请重新修改")
                data.active--;
                data.num--; 
              }else if(res.message == "操作失败！请联系管理员！"){
                ElMessage.error("操作失败！请联系管理员！")             
              }else{
                data.active++;
                data.num++; 
                console.log(res)   
              }
          });  
        }
        
    }

    function to_login(){
        router.push("/login/login_in");
    }

    //校验密码是否为空
    let validatePassword  = (rule, value, callback) => {
      if (data.new_code === ""){
        data.can = false ;
        callback(new Error("密码不能为空！"));
      }else if(data.new_code.length < 8){
        data.can = false ;
        callback(new Error("密码长度不能少于8位！"));
      }else {
        data.can = true;
        callback();
      }

    };
    // 密码重复验证
    let validateCheckPassword = (rule, value, callback) => {
      if (data.confirm_code === "") {
        data.can1 = false ;
        callback(new Error("密码不能为空！"));
      }
      else if (data.confirm_code !== data.new_code) {
        data.can1 = false ;
        callback(new Error("密码不一致！"));
      } else {
        data.can1 = true;
        callback();
      }

    };

    const rules = reactive({
      password: [
        {
          validator: validatePassword,
          trigger: "blur"
        }
      ],
      checkPassword: [
        {
          validator: validateCheckPassword,
          trigger: "blur"
        }
      ]
    })


    return {
      data,
      getAuthCode,
      submitmail,
      rules,
      submitpassword,
      to_login
    };
  }
});

</script>

<style lang="scss" scoped>

.el-card {
  position: absolute;
  top:40%;
  left:50%;
  transform: translate(-50%, -50%);
  width: 700px;

    .el-form-item{
        width: 450px;
        margin-left: 105px;

        span{
            font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            font-size: 15px;
        }
        .el-button{
            min-width: 140px;
            margin-top: 0px;
            margin-bottom: 0px;
        }
       
    }
    .el-button{
        display: block;
        margin: auto;
        min-width: 440px;
        height: 40px;
        margin-top: 25px;
        margin-bottom: 40px;
    }

}
</style>