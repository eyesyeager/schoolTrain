<template>
    <div class="container">
        <el-drawer v-model="drawer" size="50%" destroyOnClose=true>
            <template #header>
                <div style="text-align: left;font-weight: bold;font-size: 40px;color:black;position: relative;top:30px">
                    添加客户</div>
            </template>
            <newCustomer :closeDrawer="closeDrawer" />
        </el-drawer>
        <div class="header">
            <el-row>
                <el-col :span="22" style="position: relative;top:20px">
                    <h1>合同新增</h1>
                </el-col>
                <el-col :span="2">
                    <el-button @click="$router.go(-1)" style="top:45px; position: relative;">
                        <svg t="1657073712709" class="icon" viewBox="0 0 1024 1024" version="1.1"
                            xmlns="http://www.w3.org/2000/svg" p-id="2291" width="16" height="16">
                            <path
                                d="M957.046154 452.923077H303.261538c-17.723077 0-25.6-21.661538-13.784615-33.476923l189.046154-189.046154c11.815385-11.815385 11.815385-29.538462 0-41.353846l-43.323077-43.323077c-11.815385-11.815385-29.538462-11.815385-41.353846 0L49.230769 492.307692c-11.815385 11.815385-11.815385 29.538462 0 41.353846L393.846154 878.276923c11.815385 11.815385 29.538462 11.815385 41.353846 0l41.353846-41.353846c11.815385-11.815385 11.815385-29.538462 0-41.353846l-189.046154-189.046154c-11.815385-13.784615-3.938462-35.446154 13.784616-35.446154h653.784615c15.753846 0 29.538462-11.815385 29.538462-27.569231v-59.076923c0-15.753846-11.815385-31.507692-27.569231-31.507692z"
                                p-id="2292"></path>
                        </svg>
                        返回
                    </el-button>
                </el-col>
            </el-row>
        </div>
        <div class="main">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class='form'>
                <div class="baseInfo">
                    <div class="baseInfoTitle">基础信息</div>
                    <el-divider></el-divider>
                    <el-form-item label="合同名称" prop="name" required>
                        <el-input v-model="ruleForm.name"></el-input>
                    </el-form-item>
                    <el-form-item label="合同编号" prop="identifier">
                        <el-input v-model="ruleForm.identifier"></el-input>
                    </el-form-item>
                    <el-row>
                        <el-col :span="20">
                            <el-form-item label="客户名称" prop="customer" required>
                                <el-select v-model="ruleForm.customer" placeholder="请选择" style="width:100%"
                                    @click="findCustomer">
                                    <el-option v-for="item in customers" :key="item.name" :label="item.name"
                                        :value="item.name" style="width:100%">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-button type="primary" @click="drawer = true">添加客户</el-button>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="BG" prop="bg" required>
                                <el-select v-model="ruleForm.bg" placeholder="请选择">
                                    <el-option v-for="item in constant.BG" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="BU" prop="bu" required>
                                <el-select v-model="ruleForm.bu" placeholder="请选择">
                                    <el-option v-for="item in constant.BU" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="行业" prop="industry" required>
                                <el-select v-model="ruleForm.industry" placeholder="请选择">
                                    <el-option v-for="item in constant.industry" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="子行业" prop="industryChild" required>
                                <el-select v-model="ruleForm.industryChild" placeholder="请选择">
                                    <el-option v-for="item in constant.industryChild" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="项目类型" prop="projectType" required>
                                <el-select v-model="ruleForm.projectType" placeholder="请选择">
                                    <el-option v-for="item in constant.projectType" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="区域" prop="region" required>
                                <el-select v-model="ruleForm.region" placeholder="请选择">
                                    <el-option v-for="item in constant.region" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="机构" prop="organization" required>
                                <el-select v-model="ruleForm.organization" placeholder="请选择">
                                    <el-option v-for="item in constant.organization" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="省份" prop="province" required>
                                <el-select v-model="ruleForm.province" placeholder="请选择">
                                    <el-option v-for="item in constant.province" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="客户经理" prop="accountManager" required>

                                <el-input v-model="ruleForm.accountManager" placeholder="请完善客户经理">
                                </el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="产品线" prop="productLine" required>
                                <el-select v-model="ruleForm.productLine" placeholder="请选择">
                                    <el-option v-for="item in constant.productLine" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="乙方单位" prop="customerOrgan" required>
                                <el-select v-model="ruleForm.customerOrgan" placeholder="请选择">
                                    <el-option v-for="item in constant.customerOrgan" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="签订时间" prop="createTime" required>
                                <el-date-picker v-model="ruleForm.createTime" type="date" placeholder="选择日期"
                                    :disabled-date="disabledDate">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="签单状态" prop="contractStatus" required>
                                <el-select v-model="ruleForm.contractStatus" placeholder="请选择">
                                    <el-option v-for="item in constant.contractStatus" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="维保期" prop="protectionTime" required>
                                <el-select v-model="ruleForm.protectionTime" placeholder="请选择">
                                    <el-option v-for="item in constant.protectionTime" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="约定货币">
                                <el-radio-group v-model="ruleForm.currency">
                                    <el-radio-button label="1">人民币</el-radio-button>
                                    <el-radio-button label="2">美元</el-radio-button>
                                    <el-radio-button label="3">日元</el-radio-button>
                                    <el-radio-button label="4">英镑</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>
                <div class="contractType table">
                    <el-row>
                        <div class="contractTypeTitle">合同类型</div>
                        <div class="requiredError">
                            <el-form-item prop="checkContractType"></el-form-item>
                        </div>
                    </el-row>

                    <el-divider></el-divider>
                    <el-table :data="ruleForm.contractTypeList" style="width: 100%">
                        <el-table-column header-align="center" align="center">
                            <template #header>
                                合同类型<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <span style="margin-left: 10px">{{ scope.row.name }}</span>
                                <el-checkbox v-model="scope.row.checked"></el-checkbox>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center">
                            <template #header>
                                合同金额<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <el-form-item>
                                    <el-input class="tableItem" v-model="scope.row.money" placeholder="￥0.00">
                                    </el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center">
                            <template #header>
                                税率<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <el-form-item>
                                    <el-select class="tableItem" v-model="scope.row.taxRate" placeholder="请选择"
                                        style="width:100%">
                                        <el-option v-for="item in constant.taxRate" :key="item.value"
                                            :label="item.label" :value="item.value" style="width:100%">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column class="tableItem" label="税率额" header-align="center">
                            <template #default="scope">
                                <el-form-item>
                                    <el-input v-model="scope.row.taxMoney" placeholder="￥0.00">
                                    </el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div class="isBond">
                    <div class="isBondTitle">履约保证金</div>
                    <el-divider></el-divider>
                    <el-form-item>
                        <el-checkbox v-model="ruleForm.isBondChecked" style="margin-left:0">本合同存在履约保证金</el-checkbox>
                    </el-form-item>
                </div>

                <div class="payInfo">
                    <el-row>
                        <div class="payInfoTitle">支付信息</div>
                        <div class="requiredError">
                            <el-form-item prop="checkPayInfo"></el-form-item>
                        </div>
                    </el-row>
                    <el-divider></el-divider>
                    <el-tabs type="border-card" v-model='tabNum' :stretch='true'>
                        <el-tab-pane label="项目进度" name="first">
                            <el-table :data="ruleForm.contractPayList" style="width: 100%" :show-header="false">
                                <el-table-column label="进度节点">
                                    <template #default="scope">
                                        <span style="margin-left: 10px">{{ scope.row.name }}</span>
                                        <el-checkbox v-model="scope.row.checked"></el-checkbox>
                                    </template>
                                </el-table-column>
                                <el-table-column label="支付额" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payMoney" style="width: 80%">
                                            <template #prepend>支付额</template>
                                            <template #append>元</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="合同额占比" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payRate" style="width: 80%">
                                            <template #prepend>占合同额</template>
                                            <template #append>%</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="支付节点" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payNode" style="width: 80%">
                                            <template #prepend>支付节点</template>
                                            <template #append>%</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="付款条件" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payCondition" style="width: 80%">
                                            <template #prepend>付款条件</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-tab-pane>
                        <el-tab-pane label="按自定义方式" name="second">to be continued</el-tab-pane>
                    </el-tabs>
                    <el-form-item label="付款方式" style="margin-top:20px" prop="payType" required>
                        <el-radio-group v-model="ruleForm.payType">
                            <el-radio-button label="1">支票</el-radio-button>
                            <el-radio-button label="2">电汇</el-radio-button>
                            <el-radio-button label="3">银行承兑汇票</el-radio-button>
                            <el-radio-button label="4">商业承兑汇票</el-radio-button>
                            <el-radio-button label="5">转账</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                </div>

                <div class="accessory">
                    <el-row>
                        <div class="accessoryTitle">合同附录</div>
                        <div class="requiredError">
                            <el-form-item prop="checkAccessory"></el-form-item>
                        </div>
                    </el-row>
                    <el-divider></el-divider>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.contractBody" download>合同正文</el-link> -->
                        合同正文
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <el-upload class="upload-demo" :action="urlConfig.fileUploadUrl" :on-success="handle_success"
                            :limit="1">
                            <el-button size="small" type="primary" @click="currentAccessoryType = 'contractBody'">点击上传
                            </el-button>
                        </el-upload>
                    </el-row>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.grossProfitTable" download>毛利率分析表</el-link> -->
                        毛利率分析表
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <el-upload class="upload-demo" :action="urlConfig.fileUploadUrl" :on-success="handle_success"
                            :limit="1">
                            <el-button size="small" type="primary" @click="currentAccessoryType = 'grossProfitTable'">
                                点击上传</el-button>
                        </el-upload>
                    </el-row>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.schedulePricesTable" download>价格清单表</el-link> -->
                        价格清单表
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <el-upload class="upload-demo" :action="urlConfig.fileUploadUrl" :on-success="handle_success"
                            :limit="1">
                            <el-button size="small" type="primary"
                                @click="currentAccessoryType = 'schedulePricesTable'">点击上传</el-button>
                        </el-upload>
                    </el-row>
                </div>

                <div class="others">
                    <div class="othersTitle">其他</div>
                    <el-divider></el-divider>
                    <el-input type="textarea" :rows="6" placeholder="请输入附件内容" v-model="ruleForm.otherInfo">
                    </el-input>
                </div>
                <el-row style="margin-top:20px">
                    <el-col :span="7">
                        共<span style="color:red">&nbsp;&nbsp;{{ contractTypeNum }}&nbsp;&nbsp;</span>种合同类型
                    </el-col>
                    <el-col :span="7">
                        合同总额￥<span style="color:red">&nbsp;&nbsp;{{ contractTotalMoney }}&nbsp;&nbsp;</span>
                    </el-col>
                    <el-col :span="7">
                        税率总额￥<span style="color:red">&nbsp;&nbsp; {{ contractTotalTax }}&nbsp;&nbsp;</span>
                    </el-col>
                    <el-col :span="3">
                        <el-button type="primary" @click="submitForm('ruleForm')">现在发布</el-button>
                    </el-col>
                </el-row>


            </el-form>
        </div>
    </div>


</template>

<script >
import $constant from "@/constant";
import $api from '@/server/api';
import newCustomer from "./newCustomer.vue";
import { urlConfig } from "@/config";
export default {
    data() {
        const validateType = (rule, value, callback) => {
            if (this.contractTypeNum == 0) return callback(new Error('合同类型不能不填写'));
            this.ruleForm.contractTypeList.forEach(item => {
                // console.log(item);
                if ((item.money || item.taxRate)) {
                    if (!item.checked) {
                        return callback(new Error('合同金额或税率被填写但对应项未被勾选'));
                    }
                }
                if (item.checked) {
                    if (!(item.money && item.taxRate)) {
                        return callback(new Error('合同金额或税率未填写'));
                    }
                }
            });
            callback()
        };
        const validateAccessory = (rule, value, callback) => {
            if (!this.ruleForm.contractBody) return callback(new Error('合同正文未上传'));
            if (!this.ruleForm.grossProfitTable) return callback(new Error('毛利率分析表未上传'));
            if (!this.ruleForm.schedulePricesTable) return callback(new Error('价格清单表未上传'));
            callback()
        };
        const validatePayInfo = (rule, value, callback) => {
            this.ruleForm.contractPayList.forEach(item => {
                // console.log(item);
                if ((item.payMoney || item.payRate || item.payNode || item.payCondition)) {
                    if (!item.checked) {
                        return callback(new Error('某节点的信息被填写但对应项未被勾选'));
                    }
                }
            });
            callback()
        };

        return {
            urlConfig,
            currentAccessoryType: '',
            drawer: false,
            tabNum: 'first',
            constant: $constant,
            customers: [],
            ruleForm: {
                name: '',
                identifier: '',
                customer: '',
                bg: '',
                bu: '',
                industry: '',
                industryChild: '',
                projectType: '',
                region: '',
                organization: '',
                province: '',
                accountManager: '',
                productLine: '',
                customerOrgan: '',
                createTime: '',
                contractStatus: '',
                protectionTime: '',
                currency: 1,
                contractTypeList: [
                    {
                        type: 1,
                        name: '软件开发',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                    {
                        type: 2,
                        name: '第三方硬件',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                    {
                        type: 3,
                        name: '第三方软件',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                    {
                        type: 4,
                        name: '系统集成',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                    {
                        type: 5,
                        name: '维护保障',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                    {
                        type: 6,
                        name: '技术服务',
                        checked: false,
                        money: '',
                        taxRate: '',
                        taxMoney: ''
                    },
                ],
                isBondChecked: false,
                contractPayList: [
                    {
                        timeNode: 1,
                        name: '首付款',
                        checked: false,
                        payMoney: '',
                        payRate: '',
                        payNode: '',
                        payCondition: ''
                    },
                    {
                        timeNode: 2,
                        name: '上线款',
                        checked: false,
                        payMoney: '',
                        payRate: '',
                        payNode: '',
                        payCondition: ''
                    },
                    {
                        timeNode: 3,
                        name: '初验款',
                        checked: false,
                        payMoney: '',
                        payRate: '',
                        payNode: '',
                        payCondition: ''
                    },
                    {
                        timeNode: 4,
                        name: '终验款',
                        checked: false,
                        payMoney: '',
                        payRate: '',
                        payNode: '',
                        payCondition: ''
                    },
                    {
                        timeNode: 5,
                        name: '尾款',
                        checked: false,
                        payMoney: '',
                        payRate: '',
                        payNode: '',
                        payCondition: ''
                    }
                ],
                payType: '',
                contractBody: '',
                grossProfitTable: '',
                schedulePricesTable: '',
                otherInfo: '',

            },
            rules: {
                checkContractType: [
                    { validator: validateType, trigger: 'blur' }
                ],
                checkAccessory: [
                    { validator: validateAccessory, trigger: 'blur' }
                ],
                checkPayInfo: [
                    { validator: validatePayInfo, trigger: 'blur' }
                ]
            },

        };
    },
    computed: {
        contractTypeNum() {
            return this.ruleForm.contractTypeList.filter(item => item.checked).length
        },
        contractPayNum() {
            return this.ruleForm.contractPayList.filter(item => item.checked).length
        },
        contractTotalMoney() {
            let totalMoney = 0;
            this.ruleForm.contractTypeList.forEach(item => {
                if (item.checked && item.money) totalMoney += parseFloat(item.money);
            });
            return totalMoney.toFixed(2);
        },
        contractTotalTax() {
            let totalTax = 0;
            this.ratevalueTotruevalue()
            this.ruleForm.contractTypeList.forEach(item => {
                if (item.checked && item.money && item.taxRate) totalTax += parseFloat(item.money) * parseFloat(item.trueValue);
            });
            return totalTax.toFixed(2);
        },
        payInfoTotalMoney() {
            let totalMoney = 0;
            this.ruleForm.contractPayList.forEach(item => {
                if (item.checked && item.payMoney) totalMoney += parseFloat(item.payMoney);
            });
            return totalMoney.toFixed(2);
        }
    },
    mounted() {
        // this.findCustomer()
        console.log(this.urlConfig.fileUploadUrl);
    },
    methods: {
        async findCustomer() {
            await $api.findCustomer().then(res => {
                // console.log(res);
                this.customers = res.data
            })
        },
        async addContract() {
            var submitForm = this.ruleForm
            submitForm.contractTypeDoList = submitForm.contractTypeList.filter(item => item.checked)
            submitForm.contractPayDoList = (submitForm.contractPayList.filter(item => item.checked).length == 0) ? null : submitForm.contractPayList.filter(item => item.checked)
            submitForm.isBond = submitForm.isBondChecked ? 2 : 1
            submitForm.contractTypeNum = this.contractTypeNum
            submitForm.contractTotalMoney = this.contractTotalMoney
            submitForm.contractTotalTax = this.contractTotalTax
            // console.log(this.ruleForm);
            await $api.addContract(submitForm).then(res => {
                if (res.code == 200) {
                    ElMessage({
                        message: "添加成功",
                        type: 'success',
                        showClose: true
                    })//用户友好性,再次新建/返回
                    this.$router.go(-1)
                }
                else if (res.code == 401) {
                    ElMessage({
                        message: "合同名重复，请重新输入",
                        type: 'error',
                        showClose: true
                    })
                }
            })
        },
        submitForm(formName) {
            this.$refs[formName].validate((valid) => {

                if (valid) {
                    if (this.contractPayNum > 0 && this.contractTotalMoney != this.payInfoTotalMoney)
                        ElMessage({
                            message: "合同类型中的合同金额与支付信息中的总金额不一致,添加失败",
                            type: 'error',
                            showClose: true
                        })
                    else this.addContract()
                } else {
                    console.log(valid);
                    ElMessage({
                        message: "信息不全，添加失败",
                        type: 'error',
                        showClose: true
                    })
                    return false;
                }
            });
        },
        disabledDate(date) {
            return date > new Date()
        },
        closeDrawer() {
            this.drawer = false
            // this.findCustomer()
        },
        handle_success(res) {
            // console.log(res);
            this.ruleForm[this.currentAccessoryType] = res.data.url
        },
        ratevalueTotruevalue() {
            this.ruleForm.contractTypeList.forEach(item => {
                // console.log(item);
                // console.log($constant.taxRate.find(element => parseInt(item.taxRate) == element.value));
                item.trueValue = item.taxRate ? $constant.taxRate.find(element => item.taxRate == element.value).label : null;
                // console.log(item.trueValue);
            });
        }

    },
    components: { newCustomer }
}
</script>

<style lang="scss">
.baseInfoTitle,
.contractTypeTitle,
.isBondTitle,
.payInfoTitle,
.accessoryTitle,
.othersTitle {
    text-align: left;
    margin-top: 20px;
    font-weight: bolder;
    font-size: larger;
}

.container {
    background-color: #fff;
}

.form .table .el-form-item__content {
    margin-left: 50px !important;
}

.tableItem {
    margin-top: 15px
}

.main {
    padding: 20px;
}

// .upload-demo{
//     padding-top: 10px;
// }
.requiredError .el-form-item__error {
    font-size: 16px;
    width: max-content;
    margin-top: 24px;
}
</style>>
