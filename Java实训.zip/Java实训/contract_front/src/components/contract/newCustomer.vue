<template>
    <div class="container">
        <el-form :model="customerInfo" :rules="rules" ref="customerInfo" label-width="100px">
            <!-- <div class="header"></div> -->
            <div class="baseInfo">
                <div class="baseInfoTitle">基础信息</div>
                <el-divider></el-divider>
                <el-form-item label="客户名称" prop="name">
                    <el-input v-model="customerInfo.name"></el-input>
                </el-form-item>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="客户级别" prop="level">
                            <el-select v-model="customerInfo.level" placeholder="请选择">
                                <el-option v-for="item in constant.level" :key="item.value" :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="行业" prop="industry">
                            <el-select v-model="customerInfo.industry" placeholder="请选择">
                                <el-option v-for="item in constant.industry" :key="item.value" :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="邮政编码" prop="postalCode">
                            <el-input v-model="customerInfo.postalCode"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="所在省" prop="province">
                            <el-select v-model="customerInfo.province" placeholder="请选择">
                                <el-option v-for="item in constant.province" :key="item.value" :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="所在市" prop="city">
                            <el-select v-model="customerInfo.city" placeholder="请选择">
                                <el-option v-for="item in constant.city" :key="item.value" :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="所在县" prop="county">
                            <el-select v-model="customerInfo.county" placeholder="请选择">
                                <el-option v-for="item in constant.county" :key="item.value" :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-form-item label="地址" prop="postalCode">
                    <el-input v-model="customerInfo.address" placeholder="请输入所在地址" style="width:100%"></el-input>
                </el-form-item>
            </div>
            <div class="invoiceInfo">
                <div class="invoiceHeader" style="display:flex;justify-content: space-between;">
                    <div class="invoiceInfoTitle">
                        发票信息
                    </div>
                    <el-button type="primary" @click="newCustomer" class="newCustomer">添加客户</el-button>
                </div>
                <el-divider></el-divider>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="单位" prop="invoiceOrganization">
                            <el-input v-model="customerInfo.invoiceOrganization"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="税号" prop="industry">
                            <el-input v-model="customerInfo.invoiceTaxNumber"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="电话" prop="postalCode">
                            <el-input v-model="customerInfo.invoicePhone"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="地址" prop="invoiceAddress">
                            <el-input v-model="customerInfo.invoiceAddress"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="开户行" prop="invoiceBank">
                            <el-input v-model="customerInfo.invoiceBank"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="账号" prop="invoiceAccount">
                            <el-input v-model="customerInfo.invoiceAccount"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </div>
        </el-form>
    </div>

</template>

<script>
import $constant from "@/constant";
import $api from "@/server/api"
export default {
    name: "newCustomer",
    props: ['closeDrawer'],
    data() {
        return {
            constant: $constant,
            customerInfo: {
                name: '',
                level: '',
                industry: '',
                postalCode: '',
                province: '',
                city: '',
                county: '',
                address: '',
                invoiceOrganization: '',
                invoiceTaxNumber: '',
                invoicePhone: '',
                invoiceAddress: '',
                invoiceBank: '',
                invoiceAccount: ''
            },
            rules: {
                name: [
                    { required: true, message: '请输入客户名', trigger: 'blur' }
                ]
            }
        }
    },
    methods: {
        async addCustomer() {
            const req = this.customerInfo
            console.log(req, 111);
            await $api.addCustomer(req).then(res => {
                // console.log(res);
                if (res.code == 200) {
                    ElMessage({
                        message: "添加成功",
                        type: 'success',
                        showClose: true
                    })
                    this.$refs['customerInfo'].resetFields();
                    this.closeDrawer();
                }
                else if (res.code == 401) {
                    ElMessage({
                        message: "客户名重复，添加失败",
                        type: "error",
                        showClose: true
                    })
                }
            })
        },
        newCustomer() {
            this.$refs['customerInfo'].validate((valid) => {
                if (valid) {
                    this.addCustomer()
                } else {
                    console.log(valid);
                    ElMessage({
                        message: "未填写客户名",
                        type: "error",
                        showClose: true
                    })
                    return
                }
            })

        }
    }
}
</script>

<style scoped>
.container {
    background-color: #fff;
    padding: 20px;
}


.baseInfoTitle,
.invoiceInfoTitle {
    text-align: left;
    margin-top: 20px;
    font-weight: bolder;
    font-size: larger;
}

.newCustomer {
    margin: auto 0;
}
</style>