<template>
    <el-dialog v-model="dialogTableVisible" title="付款节点">
        <el-table :data="contractPayDoList" style="width: 100%" :show-header="true"
            :header-cell-style="{ 'text-align': 'center' }" :cell-style="{ 'text-align': 'center' }">
            <el-table-column label="进度节点">
                <template #default="scope">
                    <span style="margin-left: 10px;">{{ scope.row.nodeName }}</span>
                </template>
            </el-table-column>
            <el-table-column label="支付额" header-align="center">
                <template #default="scope">
                    <!-- <el-input disabled="true" v-model.number="scope.row.payMoney" style="width: 80%">
                                        <template #prepend>支付额</template>
                                        <template #append>元</template>
                                    </el-input> -->
                    {{ scope.row.payMoney }}元
                </template>
            </el-table-column>
            <el-table-column label="合同额占比" header-align="center" style="width:20%">
                <template #default="scope">
                    <!-- <el-input  disabled="true" v-model="scope.row.payRate" style="width: 80%">
                                        <template #prepend>占合同额</template>
                                        <template #append>%</template>
                                    </el-input> -->
                    {{ scope.row.payRate }}%
                </template>
            </el-table-column>
            <el-table-column label="支付节点" header-align="center">
                <template #default="scope">
                    <!-- <el-input disabled="true" v-model="scope.row.payNode" style="width: 80%">
                                        <template #prepend>支付节点</template>
                                        <template #append>%</template>
                                    </el-input> -->
                    {{ scope.row.payNode }}%
                </template>
            </el-table-column>
            <el-table-column label="付款条件" header-align="center">
                <template #default="scope">
                    <!-- <el-input disabled="true" v-model="scope.row.payCondition" style="width: 80%">
                                        <template #prepend>付款条件</template>
                                    </el-input> -->
                    {{ scope.row.payCondition }}
                </template>
            </el-table-column>
        </el-table>
    </el-dialog>
    <!-- <el-drawer v-model="drawer" size="100%" direction="ttb">
        <template #header>
            <div style="text-align: left;font-weight: bold;font-size: 40px;color:black;position: relative;top:30px">
                合同信息</div>
        </template>
        <showContract :ruleForm="selectedContract" />
    </el-drawer> -->

    <el-container>
        <el-header></el-header>
        <el-drawer v-model="drawer" size="100%" direction="ttb">
            <template #header>
                <div style="text-align: left;font-weight: bold;font-size: 40px;color:black;position: relative;top:30px">
                    合同信息</div>
            </template>
            <showContract :ruleForm="selectedContract" />
        </el-drawer>
        <el-main style="display:flex;justify-content: space-around;">
            <div class="contractList">
                <div class="header">
                    <el-row>
                        <h3 style="margin:auto 10px">履约合同</h3>
                        <el-menu mode="horizontal" default-active='2022' @select="findByTime($event, 1, 1)"
                            class="time">
                            <el-menu-item index="2022">今年</el-menu-item>
                            <el-menu-item index='2021'>去年</el-menu-item>
                            <el-menu-item index='2020'>2020年</el-menu-item>
                            <el-menu-item index='2019'>2019年</el-menu-item>
                            <el-menu-item index='more'>更多</el-menu-item>
                        </el-menu>
                        <el-button type="primary" style="margin:auto 0px" @click="$router.push('/newContract')"
                            :disabled="role == 1 || role == 0">创建合同
                        </el-button>
                    </el-row>
                </div>
                <div class="main">
                    <ul v-for="c in formatContractList1" :key="c.name">
                        <div class="contract">
                            <div class="info">
                                <img src="https://img.codesocean.top/image/1657264660097" alt="" class="teamicon">
                                <div class="name">{{ c.name }}</div>
                            </div>
                            <div class="operation">
                                <div>
                                    <el-link type="primary" @click="previewContract(c.name)">合同正文预览</el-link>
                                </div>
                                <div>
                                    <el-link type="primary" @click="findContractPay(c.name)">查看付款节点</el-link>
                                </div>
                                <div>
                                    <el-link type="primary" @click="enterContract(c.name)">进入合同</el-link>
                                </div>
                            </div>
                        </div>
                        <div class="data">
                            <span class="createTime">签订日期 {{ c.createTime }}</span>
                            <span class="money">合同额 {{ c.contractTotalMoney }} 万</span>
                        </div>
                    </ul>
                    <div class="div_pag">
                        <el-pagination v-model="contract1.current" :pageSize="contract1.pageSize"
                            :current-page="contract1.current" v-show="contract1.contractList.length > 0"
                            @current-change="handleCurrentChange1" :page-count="contract1.pages"
                            :total="contract1.totalNum" />
                    </div>
                </div>
            </div>
            <div class="contractList">
                <div class="header">
                    <el-row>
                        <h3 style="margin:auto 10px">已交付合同</h3>
                        <el-menu mode="horizontal" default-active='2022' @select="findByTime($event, 2, 1)"
                            class="time">
                            <el-menu-item index="2022">今年</el-menu-item>
                            <el-menu-item index='2021'>去年</el-menu-item>
                            <el-menu-item index='2020'>2020年</el-menu-item>
                            <el-menu-item index='2019'>2019年</el-menu-item>
                            <el-menu-item index='more'>更多</el-menu-item>
                        </el-menu>
                    </el-row>
                </div>
                <div class="main">
                    <ul v-for="c in formatContractList2" :key="c.name">
                        <div class="contract">
                            <div class="info">
                                <img src="https://img.codesocean.top/image/1657264660097" alt="" class="teamicon">
                                <div class="name">{{ c.name }}</div>
                            </div>
                            <div class="operation">
                                <div>
                                    <el-link type="primary" @click="previewContract(c.name)">合同正文预览</el-link>
                                </div>
                                <div>
                                    <el-link type="primary" @click="findContractPay(c.name)">查看付款节点</el-link>
                                </div>
                                <div>
                                    <el-link type="primary" @click="enterContract(c.name)">进入合同</el-link>
                                </div>
                            </div>
                        </div>
                        <div class="data">
                            <span class="createTime">签订日期 {{ c.createTime }}</span>
                            <span class="money">合同额 {{ c.contractTotalMoney }} 万</span>
                        </div>
                    </ul>
                    <div class="div_pag">
                        <el-pagination v-model="contract2.current" :pageSize="contract2.pageSize"
                            :current-page="contract2.current" v-show="contract2.contractList.length > 0"
                            @current-change="handleCurrentChange2" :page-count="contract2.pages"
                            :total="contract2.totalNum" />
                    </div>
                </div>
            </div>
        </el-main>
    </el-container>

</template>
<script>
import utils from "@/utils/help.js"
import $api from "@/server/api"
import showContract from "@/components/contract/showContract.vue";
import dayjs from 'dayjs'
export default {
    mounted() {
        this.role = utils.str2obj(localStorage.getItem('role')).role
        // console.log(this.role);
        this.findByTime(2022, 1, 1)
        this.findByTime(2022, 2, 1)
    },
    components: { showContract },
    data() {
        return {
            role: '',
            contract1: {
                current: 1,
                totalNum: 0,
                time: '',
                pages: 0,
                contractList: [],
                pageSize: 0
            },
            contract2: {
                current: 1,
                time: '',
                current: 1,
                totalNum: 0,
                pages: 0,
                contractList: [],
                pageSize: 0
            },
            selectedContract: {}
            ,
            contractPayDoList: {},
            dialogTableVisible: false,
            drawer: false,
        };
    },
    computed: {
        formatContractList1() {
            let formatContractList = this.contract1.contractList
            formatContractList.forEach(element => {
                element.createTime = dayjs(element.createTime).format('YYYY/MM/DD')
            });
            return formatContractList
        },
        formatContractList2() {
            let formatContractList = this.contract2.contractList
            formatContractList.forEach(element => {
                element.createTime = dayjs(element.createTime).format('YYYY/MM/DD')
            });
            return formatContractList
        }
    },
    methods: {
        async findByTime(time, status, current) {
            const req = "?time=" + time + "&status=" + status + "&current=" + current
            // console.log(time,status);
            if (time != 'more')
                await $api.findByTime(req).then(res => {
                    res.data.records.forEach(item => {
                        // console.log(parseFloat(item.contractTotalMoney) % 10000);
                        item.contractTotalMoney = (parseFloat(item.contractTotalMoney) / 10000).toFixed(2);
                        // console.log(item.customer);
                    });
                    if (status == 1) {
                        this.contract1.current = current
                        this.contract1.contractList = res.data.records;
                        this.contract1.time = time
                        this.contract1.totalNum = res.data.total
                        this.contract1.pageSize = res.data.size
                        this.contract1.pages = res.data.pages
                    }
                    else if (status == 2) {
                        this.contract2.current = current
                        this.contract2.contractList = res.data.records;
                        this.contract2.time = time
                        this.contract2.totalNum = res.data.total
                        this.contract2.pageSize = res.data.size
                        this.contract2.pages = res.data.pages
                    }
                })
            else this.$router.push('/contractList')
        },
        async findContractPay(name) {
            const req = "?name=" + name
            await $api.findContractPay(req).then(res => {
                // console.log(res);
                this.contractPayDoList = res.data
                this.contractPayDoList.forEach(item => {
                    item.nodeName = this.timeNodeToNodeName(item.timeNode)
                });
            })
            this.dialogTableVisible = true
        },
        async previewContract(name) {
            const req = "?name=" + name
            await $api.previewContract(req).then(res => {
                // console.log(res);
                const url = res.data.contractBody;
                let fileType = url.slice(url.lastIndexOf('.'))
                //window.open(url)
                let x = new XMLHttpRequest();
                x.open("GET", url, true);
                x.responseType = 'blob';
                x.onload = function (e) {
                    let url = window.URL.createObjectURL(x.response)
                    let a = document.createElement('a');
                    a.href = url
                    a.download = name + "合同正文" + fileType;
                    a.click()
                }
                x.send();
            })
        },
        async enterContract(name) {
            const req = "?name=" + name
            await $api.enterContract(req).then(res => {
                console.log(res);
                this.selectedContract = res.data
                this.selectedContract.contractTypeDoList.forEach(element => {
                    element.typeName = this.typeToTypeName(element.type)
                });
                this.selectedContract.contractPayDoList.forEach(element => {
                    element.nodeName = this.timeNodeToNodeName(element.timeNode)
                });

                this.drawer = true
            })
        },
        handleCurrentChange1(val) {
            console.log(`当前页: ${val}`);
            this.contract1.current = val;
            this.findByTime(this.contract1.time, 1, this.contract1.current)
        },
        handleCurrentChange2(val) {
            console.log(`当前页: ${val}`);
            this.contract2.current = val;
            this.findByTime(this.contract2.time, 2, this.contract2.current)
        },
        timeNodeToNodeName(val) {
            switch (val) {
                case 1:
                    return "首付款"
                case 2:
                    return "上线款"
                case 3:
                    return "初验款"
                case 4:
                    return "终验款"
                case 5:
                    return "尾款"

            }
        },
        typeToTypeName(val) {
            switch (val) {
                case 1:
                    return "软件开发"
                case 2:
                    return "第三方硬件"
                case 3:
                    return "第三方软件"
                case 4:
                    return "系统集成"
                case 5:
                    return "维护保障"
                case 6:
                    return "技术服务"
            }
        }
    },
};
</script>

<style scoped lang="scss">
.contractList {
    background-color: #fff;
    height: min-content;
    width: 48%;
}

.time {
    width: 450px;
    height: 80px;
    margin: auto 0;
}

.el-menu.el-menu--horizontal {
    border: none;
}

.contract {
    margin-top: 50px;
    display: flex;

    .info {
        display: flex;

        .teamicon {
            width: 50px;
            height: 50px;
        }

        .name {
            text-align: left;
            margin: 10px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100px;
        }
    }

    .operation {
        display: flex;
        margin-top: 7px;
        width: 400px;
        justify-content: space-around;
    }

}

.data {
    display: flex;
    justify-content: left;
    margin-top: 20px;

    .createTime {
        margin-right: 50px;
    }
}

.div_pag {
    margin-top: 25px;
    display: flex;
    justify-content: flex-end;
    background-color: #fff;
}
</style>