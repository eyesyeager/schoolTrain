<template>
    <el-container>
        <!-- <el-header></el-header> -->
        <el-drawer v-model="drawer" size="100%" direction="ttb">
            <template #header>
                <div style="text-align: left;font-weight: bold;font-size: 40px;color:black;position: relative;top:30px">
                    合同信息</div>
            </template>
            <showContract :ruleForm="selectedContract" />
        </el-drawer>
        <el-main>
            <el-dialog v-model="dialogTableVisible" title="付款节点">
                <el-table :data="contractPayDoList" style="width: 100%" :show-header="true"
                    :header-cell-style="{ 'text-align': 'center' }" :cell-style="{ 'text-align': 'center' }">
                    <el-table-column label="进度节点">
                        <template #default="scope">
                            <span style="margin-left: 10px;">{{ scope.row.nodeName }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column label="支付额" header-align="center">
                        <template #default="scope">
                            <!-- <el-input disabled="true" v-model.number="scope.row.payMoney" style="width: 80%">
                                        <template #prepend>支付额</template>
                                        <template #append>元</template>
                                    </el-input> -->
                            {{ scope.row.payMoney }}元
                        </template>
                    </el-table-column>
                    <el-table-column label="合同额占比" header-align="center" style="width:20%">
                        <template #default="scope">
                            <!-- <el-input  disabled="true" v-model="scope.row.payRate" style="width: 80%">
                                        <template #prepend>占合同额</template>
                                        <template #append>%</template>
                                    </el-input> -->
                            {{ scope.row.payRate }}%
                        </template>
                    </el-table-column>
                    <el-table-column label="支付节点" header-align="center">
                        <template #default="scope">
                            <!-- <el-input disabled="true" v-model="scope.row.payNode" style="width: 80%">
                                        <template #prepend>支付节点</template>
                                        <template #append>%</template>
                                    </el-input> -->
                            {{ scope.row.payNode }}%
                        </template>
                    </el-table-column>
                    <el-table-column label="付款条件" header-align="center">
                        <template #default="scope">
                            <!-- <el-input disabled="true" v-model="scope.row.payCondition" style="width: 80%">
                                        <template #prepend>付款条件</template>
                                    </el-input> -->
                            {{ scope.row.payCondition }}
                        </template>
                    </el-table-column>
                </el-table>
            </el-dialog>
            <el-row>
                <div class="mainTitle">我的合同</div>
                <el-button type="primary" style="margin:auto 0 auto 1200px" @click="$router.push('/newContract')"
                    :disabled="role == 1 || role == 0">创建合同
                </el-button>
            </el-row>
            <div class="mainHeader">
                <el-row>
                    <el-col :span="5">
                        <el-menu mode="horizontal" default-active='1' class="time" @select="changeStatus">
                            <el-menu-item index="1">履约合同</el-menu-item>
                            <el-menu-item index='2'>已交付合同</el-menu-item>
                        </el-menu>
                    </el-col>
                    <el-col :span="3" :offset="10" class="search">
                        <el-input v-model="partName" @keydown.enter="findByName" placeholder="搜索合同"
                            :prefix-icon="Search" />
                    </el-col>
                    <el-col :span="3" class="time" :offset="1">
                        <el-date-picker v-model="time" type="year" value-format="YYYY" :disabled-date="disabledDate"
                            @change="handleTimeChange">
                        </el-date-picker>
                        <!-- 默认值 -->
                    </el-col>
                </el-row>
            </div>

            <el-table :data="formatContractList" style="width: 100%">
                <el-table-column label=" 合同名称">
                    <template #default="scope">
                        <span style="margin-left: 10px">{{ scope.row.name }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="合同额(单位：万元)" header-align="center" align="center">
                    <template #default="scope">
                        <span style="margin-left: 10px">{{ scope.row.contractTotalMoney }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="客户名称" header-align="center" align="center">
                    <template #default="scope">
                        <span style="margin-left: 10px">{{ scope.row.customer }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="签订时间" header-align="center" align="center">
                    <template #default="scope">
                        <span style="margin-left: 10px">{{ scope.row.createTime }}</span>
                    </template>
                </el-table-column>
                <el-table-column label="操作" header-align="center">
                    <template #default="scope">
                        <el-row>
                            <el-col :span="12" style="text-align:center">
                                <el-link type="primary" @click="enterContract(scope.row.name)">进入合同</el-link>
                            </el-col>
                            <el-col :span="12" style="text-align:center">
                                <el-link type="primary" @click="findContractPay(scope.row.name)">查看付款节点</el-link>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="12" style="text-align:center">
                                <el-link type="primary" @click="previewContract(scope.row.name)">合同正文预览</el-link>
                            </el-col>
                            <el-col :span="12" style="text-align:center">
                                <el-link type="primary" v-if="status == 1" @click="closeContract(scope.row.name)"
                                    :disabled="role == 2">关闭合同
                                </el-link>
                            </el-col>
                        </el-row>
                    </template>
                </el-table-column>
            </el-table>
            <div class="div_pag">
                <el-pagination :pageSize="pageSize" v-if="contractList.length > 0" :current-page="current"
                    @current-change="handleCurrentChange" :page-count="pages" :total="totalNum" />
            </div>
        </el-main>
    </el-container>
</template>

<script>
import utils from "@/utils/help.js"
import { Search } from '@element-plus/icons-vue'
import $api from '@/server/api'
import $constant from '@/constant'
import showContract from './showContract.vue'
import dayjs from 'dayjs'
export default {
    $constant, dayjs,
    name: 'contractList',
    mounted() {
        this.role = utils.str2obj(localStorage.getItem('role')).role
        this.findByTime()
    },
    components: { showContract },
    data() {
        return {
            Search,
            role: '',
            lastOperation: '',
            contractList: [
            ],
            contractPayDoList: [],
            partName: '',
            status: 1,
            time: '2022',
            dialogTableVisible: false,
            drawer: false,
            selectedContract: {},
            current: 1,
            totalNum: 0,
            pageSize: 0,
            pages: 0
        }
    },
    computed: {
        formatContractList() {
            let formatContractList = this.contractList
            formatContractList.forEach(element => {
                // console.log(String(element.createTime))
                element.createTime = dayjs(String(element.createTime)).format('YYYY/MM/DD')
                element.contractTotalMoney = (parseFloat(element.contractTotalMoney) / 10000).toFixed(2);
            });
            return formatContractList
        }
    },
    watch: {
        status() {
            if (this.lastOperation == 1) this.findByTime()
            else if (this.lastOperation == 2) this.findByName()
        }
    },
    methods: {
        async findByTime() {
            // console.log(this.status, this.time);
            // console.log("get is used");
            if (this.lastOperation == 2) this.current = 1
            this.partName = ''
            const req = "?time=" + this.time + "&status=" + this.status + "&current=" + this.current
            await $api.findByTime(req).then(res => {
                this.contractList = res.data.records;
                this.totalNum = res.data.total
                this.pageSize = res.data.size
                this.pages = res.data.pages
                this.contractList.forEach(item => {
                    // console.log(parseFloat(item.contractTotalMoney) % 10000);
                    // console.log(item.customer);
                });
                this.lastOperation = 1;
            })
        },
        changeStatus(val) {
            this.status = val
            this.current = 1
        },
        async findContractPay(name) {
            const req = "?name=" + name
            await $api.findContractPay(req).then(res => {
                // console.log(res);
                this.contractPayDoList = res.data
                this.contractPayDoList.forEach(item => {
                    item.nodeName = this.timeNodeToNodeName(item.timeNode)
                });
            })
            this.dialogTableVisible = true
        },
        async previewContract(name) {
            const req = "?name=" + name
            await $api.previewContract(req).then(res => {
                // console.log(res);
                const url = res.data.contractBody;
                let x = new XMLHttpRequest();
                x.open("GET", url, true);
                x.responseType = 'blob';
                x.onload = function (e) {
                    let url = window.URL.createObjectURL(x.response)
                    let a = document.createElement('a');
                    a.href = url
                    a.download = name + "合同正文";
                    a.click()
                }
                x.send();
            })
        },
        async enterContract(name) {
            const req = "?name=" + name
            await $api.enterContract(req).then(res => {
                // console.log(res);
                this.selectedContract = res.data
                this.selectedContract.contractTypeDoList.forEach(element => {
                    element.typeName = this.typeToTypeName(element.type)
                });
                this.selectedContract.contractPayDoList.forEach(element => {
                    element.nodeName = this.timeNodeToNodeName(element.timeNode)
                });
                this.drawer = true
            })
        },
        async closeContract(name) {
            const req = "?name=" + name
            await $api.closeContract(req).then(res => {
                console.log(res);
                ElMessage({
                    message: "关闭成功",
                    type: 'success',
                    showClose: true
                })
                if (this.lastOperation == 1) this.findByTime()
                else if (this.lastOperation == 2) this.findByName()
                // this.$router.go(0)
                // this.findByTime()
            })
        },
        async findByName() {
            if (this.lastOperation == 1) this.current = 1
            this.time = ''
            const req = "?name=" + this.partName + "&status=" + this.status + "&current=" + this.current
            await $api.findByName(req).then(res => {
                // console.log(res);
                this.contractList = res.data.records;
                this.pages = res.data.pages
                this.totalNum = res.data.total
                this.pageSize = res.data.size
                this.lastOperation = 2
                // this.contractList.forEach(item => {
                //     item.customer = $constant.customers.find(element => item.customer == element.value).label;
                //     console.log(item.customer);
                // });
            })
        },
        // 选择当前页是第几页
        handleCurrentChange(val) {
            // console.log(`当前页: ${val}`);
            this.current = val;
            console.log(this.current, this.lastOperation);
            if (this.lastOperation == 1) this.findByTime()
            else if (this.lastOperation == 2) this.findByName()
        },
        handleTimeChange(val) {
            // this.time = val
            console.log(val);
            this.findByTime()
        },
        disabledDate(date) {
            return date > new Date()
        },
        selected(val) {

        },
        timeNodeToNodeName(val) {
            switch (val) {
                case 1:
                    return "首付款"
                case 2:
                    return "上线款"
                case 3:
                    return "初验款"
                case 4:
                    return "终验款"
                case 5:
                    return "尾款"

            }
        },
        typeToTypeName(val) {
            switch (val) {
                case 1:
                    return "软件开发"
                case 2:
                    return "第三方硬件"
                case 3:
                    return "第三方软件"
                case 4:
                    return "系统集成"
                case 5:
                    return "维护保障"
                case 6:
                    return "技术服务"

            }
        }
    }
}
</script>

<style scoped>
.mainTitle {
    text-align: left;
    margin: 15px;
    font-weight: bold;
}

.mainHeader {
    background-color: #fff;
}

.search,
.time {
    margin-top: auto;
    margin-bottom: auto;
}

.el-menu.el-menu--horizontal {
    border: none;
}

.div_pag {
    margin-top: 25px;
    display: flex;
    justify-content: flex-end;
    background-color: #fff;
}
</style>