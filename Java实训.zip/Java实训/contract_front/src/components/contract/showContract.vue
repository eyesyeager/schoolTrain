<template>
    <div class="container">
        <div class="main">
            <el-form :model="ruleForm" disabled="true" label-width="100px" class='form'>
                <div class="baseInfo">
                    <div class="baseInfoTitle">基础信息</div>
                    <el-divider></el-divider>
                    <el-form-item label="合同名称" prop="name" required>
                        <el-input v-model="ruleForm.name"></el-input>
                    </el-form-item>
                    <el-form-item label="合同编号" prop="identifier">
                        <el-input v-model="ruleForm.identifier"></el-input>
                    </el-form-item>
                    <el-row>
                        <el-col :span="20">
                            <el-form-item label="客户名称" prop="customer" required>
                                <el-select v-model="ruleForm.customer" style="width:100%">
                                    <el-option v-for="item in constant.customers" :key="item.value" :label="item.label"
                                        :value="item.value" style="width:100%">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="BG" prop="bg" required>
                                <el-select v-model="ruleForm.bg">
                                    <el-option v-for="item in constant.BG" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="BU" prop="bu" required>
                                <el-select v-model="ruleForm.bu">
                                    <el-option v-for="item in constant.BU" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="行业" prop="industry" required>
                                <el-select v-model="ruleForm.industry">
                                    <el-option v-for="item in constant.industry" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="子行业" prop="industryChild" required>
                                <el-select v-model="ruleForm.industryChild">
                                    <el-option v-for="item in constant.industryChild" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="项目类型" prop="projectType" required>
                                <el-select v-model="ruleForm.projectType">
                                    <el-option v-for="item in constant.projectType" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="区域" prop="region" required>
                                <el-select v-model="ruleForm.region">
                                    <el-option v-for="item in constant.region" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="机构" prop="organization" required>
                                <el-select v-model="ruleForm.organization">
                                    <el-option v-for="item in constant.organization" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="省份" prop="province" required>
                                <el-select v-model="ruleForm.province">
                                    <el-option v-for="item in constant.province" :key="item.value" :label="item.label"
                                        :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="客户经理" prop="accountManager" required>

                                <el-input v-model="ruleForm.accountManager">
                                </el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="产品线" prop="productLine" required>
                                <el-select v-model="ruleForm.productLine">
                                    <el-option v-for="item in constant.productLine" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="乙方单位" prop="customerOrgan" required>
                                <el-select v-model="ruleForm.customerOrgan">
                                    <el-option v-for="item in constant.customerOrgan" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="签订时间">
                                <el-date-picker v-model="formatTime" type="date" value-format="YYYY/MM/DD">
                                </el-date-picker>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="签单状态" prop="contractStatus" required>
                                <el-select v-model="ruleForm.contractStatus">
                                    <el-option v-for="item in constant.contractStatus" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="维保期" prop="protectionTime" required>
                                <el-select v-model="ruleForm.protectionTime">
                                    <el-option v-for="item in constant.protectionTime" :key="item.value"
                                        :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="约定货币">
                                <el-radio-group v-model.number="ruleForm.currency">
                                    <el-radio-button label="1" v-if="ruleForm.currency == 1">人民币</el-radio-button>
                                    <el-radio-button label="2" v-if="ruleForm.currency == 2">美元</el-radio-button>
                                    <el-radio-button label="3" v-if="ruleForm.currency == 3">日元</el-radio-button>
                                    <el-radio-button label="4" v-if="ruleForm.currency == 4">英镑</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </div>
                <div class="contractType table">
                    <el-row>
                        <div class="contractTypeTitle">合同类型</div>
                    </el-row>

                    <el-divider></el-divider>
                    <el-table :data="ruleForm.contractTypeDoList" style="width: 100%">
                        <el-table-column header-align="center" align="center">
                            <template #header>
                                合同类型<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <span style="margin-left: 10px">{{ scope.row.typeName }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center">
                            <template #header>
                                合同金额<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <el-form-item>
                                    <el-input class="tableItem" v-model.number="scope.row.money">
                                    </el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column header-align="center">
                            <template #header>
                                税率<span style="color:red">*</span>
                            </template>
                            <template #default="scope">
                                <el-form-item>
                                    <el-select class="tableItem" v-model.number="scope.row.taxRate" style="width:100%">
                                        <el-option v-for="item in constant.taxRate" :key="item.value"
                                            :label="item.label" :value="item.value" style="width:100%">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </template>
                        </el-table-column>
                        <el-table-column class="tableItem" label="税率额" header-align="center">
                            <template #default="scope">
                                <el-form-item>
                                    <el-input v-model.number="scope.row.taxMoney">
                                    </el-input>
                                </el-form-item>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div class="isBond">
                    <div class="isBondTitle">履约保证金</div>
                    <el-divider></el-divider>
                    <el-form-item>
                        <span v-show="ruleForm.isBond == 2" style="margin-left:0">本合同存在履约保证金</span>
                        <span v-show="ruleForm.isBond == 1" style="margin-left:0">本合同不存在履约保证金</span>
                    </el-form-item>
                </div>

                <div class="payInfo">
                    <div class="payInfoTitle">支付信息</div>
                    <el-divider></el-divider>
                    <el-tabs type="border-card" v-model='tabNum' :stretch='true'>
                        <el-tab-pane label="项目进度" name="first">
                            <el-table :data="ruleForm.contractPayDoList" style="width: 100%" :show-header="false">
                                <el-table-column label="进度节点">
                                    <template #default="scope">
                                        <span style="margin-left: 10px">{{ scope.row.nodeName }}</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="支付额" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model.number="scope.row.payMoney" style="width: 80%">
                                            <template #prepend>支付额</template>
                                            <template #append>元</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="合同额占比" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payRate" style="width: 80%">
                                            <template #prepend>占合同额</template>
                                            <template #append>%</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="支付节点" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payNode" style="width: 80%">
                                            <template #prepend>支付节点</template>
                                            <template #append>%</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                                <el-table-column label="付款条件" header-align="center">
                                    <template #default="scope">
                                        <el-input v-model="scope.row.payCondition" style="width: 80%">
                                            <template #prepend>付款条件</template>
                                        </el-input>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-tab-pane>
                        <el-tab-pane label="按自定义方式" name="second">to be continued</el-tab-pane>
                    </el-tabs>
                    <el-form-item label="付款方式" style="margin-top:20px" prop="payType" required>
                        <el-radio-group v-model="ruleForm.payType">
                            <el-radio-button label="1" v-if="ruleForm.payType == 1">支票</el-radio-button>
                            <el-radio-button label="2" v-if="ruleForm.payType == 2">电汇</el-radio-button>
                            <el-radio-button label="3" v-if="ruleForm.payType == 3">银行承兑汇票</el-radio-button>
                            <el-radio-button label="4" v-if="ruleForm.payType == 4">商业承兑汇票</el-radio-button>
                            <el-radio-button label="5" v-if="ruleForm.payType == 5">转账</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                </div>

                <div class="accessory">
                    <el-row>
                        <div class="accessoryTitle">合同附录</div>
                    </el-row>
                    <el-divider></el-divider>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.contractBody" target="_blank">合同正文</el-link> -->
                        <el-link @click="downloadFile(ruleForm.grossProfitTable, '合同正文')">合同正文</el-link>
                    </el-row>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.grossProfitTable" target="_blank">毛利率分析表</el-link> -->
                        <el-link @click="downloadFile(ruleForm.grossProfitTable, '毛利率分析表')">毛利率分析表</el-link>
                    </el-row>
                    <el-row>
                        <span style="color:red">*</span>
                        <!-- <el-link :href="ruleForm.schedulePricesTable" target="_blank">价格清单表</el-link> -->
                        <el-link @click="downloadFile(ruleForm.grossProfitTable, '价格清单表')">价格清单表</el-link>
                    </el-row>
                </div>

                <div class="others">
                    <div class="othersTitle">其他</div>
                    <el-divider></el-divider>
                    <el-input type="textarea" :rows="6" v-model="ruleForm.otherInfo">
                    </el-input>
                </div>
                <el-row style="margin-top:20px">
                    <el-col :span="7">
                        共<span style="color:red">&nbsp;&nbsp;{{ ruleForm.contractTypeNum }}&nbsp;&nbsp;</span>种合同类型
                    </el-col>
                    <el-col :span="7">
                        合同总额￥<span style="color:red">&nbsp;&nbsp;{{ ruleForm.contractTotalMoney }}&nbsp;&nbsp;</span>
                    </el-col>
                    <el-col :span="7">
                        税率总额￥<span style="color:red">&nbsp;&nbsp; {{ ruleForm.contractTotalTax }}&nbsp;&nbsp;</span>
                    </el-col>
                </el-row>
            </el-form>
        </div>
    </div>


</template>

<script >
import $constant from "@/constant";
import dayjs from "dayjs"
export default {
    data() {
        return {
            drawer: false,
            tabNum: 'first',
            constant: $constant
        };
    },
    computed: {
        formatTime() {
            return dayjs(String(this.ruleForm.createTime)).format('YYYY/MM/DD')
        }
    },
    methods: {
        downloadFile(url, suffixname) {
            let fileName = this.ruleForm.name + suffixname
            let fileType = url.slice(url.lastIndexOf('.'))
            // console.log(fileType);
            let x = new XMLHttpRequest();
            x.open("GET", url, true);
            x.responseType = 'blob';
            x.onload = function (e) {
                let url = window.URL.createObjectURL(x.response)
                let a = document.createElement('a');
                a.href = url
                a.download = fileName + fileType;
                a.click()
            }
            x.send();
        }
    },
    props: ['ruleForm']
}
</script>

<style lang="scss" scoped>
.baseInfoTitle,
.contractTypeTitle,
.isBondTitle,
.payInfoTitle,
.accessoryTitle,
.othersTitle {
    text-align: left;
    margin-top: 20px;
    font-weight: bolder;
    font-size: larger;
}

// .container {
//     background-color: #fff;
// }

.form .table .el-form-item__content {
    margin-left: 50px !important;
}

// .tableItem {
//     margin-top: 15px
// }

// .main {
//     padding: 20px;
// }

// .requiredError .el-form-item__error {
//     font-size: 16px;
//     width: max-content;
//     margin-top: 24px;
// }
</style>>
