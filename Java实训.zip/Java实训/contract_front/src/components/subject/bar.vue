<template>
  <el-container>
    <el-aside width="200px">
      <div class="topdiv">
        <span>销售视角</span>
      </div>
      <el-divider />
      <el-menu default-active="2" class="el-menu-vertical-demo">
        <el-menu-item index="2" @click="data.contractStatus = 1;clean(); clear() ">
          <span>在途合同</span>
        </el-menu-item>

        <el-menu-item index="3" @click="data.contractStatus = 2;clean(); clear()">
          <span>已验收合同</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-main>
      <span>
        合同汇总
      </span>
      <span>
        <el-alert title="默认载入数据为空" type="info" show-icon :closable="false" />
      </span>
      <div class="mid">
        <div class="mid-top">
          <span>BG:</span>
          <el-select v-model="data.valueBG" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsBG" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>

          <span>BU:</span>
          <el-select v-model="data.valueBU" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsBU" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <span>省份:</span>
          <el-select v-model="data.valueProvince" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsProvince" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <br><br>
          <span>区域:</span>
          <el-select v-model="data.valueRegion" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsRegion" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>

          <span>所属行业:</span>
          <el-select v-model="data.valueIndustry" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsIndustry" :key="item.value" :label="item.label" :value="item.value" />
          </el-select>
          <span>所属子行业:</span>
          <el-select v-model="data.valueIndustryChild" class="m-2" placeholder="请选择">
            <el-option v-for="item in data.optionsIndustryChild" :key="item.value" :label="item.label"
              :value="item.value" />
          </el-select>
          <div class="d-button">
            <el-button type="primary" @click="select">
              <el-icon>
                <Search />
              </el-icon>查询&nbsp;&nbsp;&nbsp;
            </el-button>
            <el-button type="info" @click="clean">
              <el-icon>
                <Refresh />
              </el-icon>还原默认&nbsp;&nbsp;&nbsp;
            </el-button>
          </div>
        </div>

        <div class="mid-bottom">
          <el-table :data="data.testDatas"  border style="overflow:auto; height: 390px;"> 
            <el-table-column fixed type="index" label="" :width="50"></el-table-column>
            <el-table-column fixed v-for="col in data.columnList" :prop="col.prop" :label="col.label" :key="col.prop"></el-table-column>
         
            <template v-slot:empty v-if="data.empty">
              <el-empty description="当前数据为空" />
            </template>
          </el-table>
          <!-- <el-pagination
              background
              layout="prev, pager, next"
              hide-on-single-page
              :total=data.total
              :current-page = data.current
              @current-change="handleCurrentChange"
              class="mt-4"
            ></el-pagination> -->
             <div class="div_pag"><el-pagination  :current-page="data.current"
                hide-on-single-page    @current-change="handleCurrentChange" :total="data.total" :page-count="data.pages"  /></div> 
          </div>
      </div>

    </el-main>
  </el-container>
        
</template>

<script>
import { reactive } from "vue";
import $constant from "@/constant";
import $api from "@/server/api"
import dayjs from 'dayjs'


export default {
  name: 'bar',

  setup() {
    let data = reactive({
      columnList: [
        { prop: "customer", label: '客户名称' },
        { prop: "name", label: '合同名称' },
        { prop: "contractTotalMoney", label: '合同金额' },
        { prop: "createTime", label: '签订时间' }
      ],
      testDatas: [],
      total:10,
      current:1,
      empty:1,
      pages:0,

      contractStatus: 1,
      optionsBG: $constant.BG,
      optionsBU: $constant.BU,
      optionsProvince: $constant.province,
      optionsRegion: $constant.region,
      optionsIndustry: $constant.industry,
      optionsIndustryChild: $constant.industryChild,
      valueBG: '',
      valueBU: '',
      valueProvince: '',
      valueRegion: '',
      valueIndustry: '',
      valueIndustryChild: '',
    })

    async function clean() {
      data.valueBG = '',
      data.valueBU = '',
      data.valueProvince = '',
      data.valueRegion = '',
      data.valueIndustry = '',
      data.valueIndustryChild = ''
    }
    
    let storeValue = ''

    async function submit(value) {
      storeValue = value
      await $api.selectContract(data.current, value, true).then(res => {
        console.log("res", res);
        if (res.code == 200) {
            if(res.data.length == 0){
            data.empty = 1
          }else{
            data.empty = 0,
            data.total = res.data.total;
            data.pages = res.data.pages;
            data.current = res.data.current;
            data.testDatas = []
            console.log("rse.info", data.total)
            for (var i = 0; i < res.data.records.length; i++) {
              res.data.records[i].createTime = dayjs(String(res.data.records[i].createTime)).format('YYYY/MM/DD')
              data.testDatas.push(res.data.records[i])
            }
            console.log("res", data.testDatas);
          }
        }else{
          ElMessage.error("获取失败")
        }
      })
    }
    
    function handleCurrentChange(val){
      data.current = val;
      submit(storeValue)
    }

    function select(){
      data.current = 1;
      let value = {
        contractStatus: data.contractStatus,
        bg: data.valueBG,
        bu: data.valueBU,
        province: data.valueProvince,
        region: data.valueRegion,
        industry: data.valueIndustry,
        industryChild: data.valueIndustryChild,
      }
      submit(value)
    } 
    function clear(){
      data.testDatas = [],
      data.total = 10,
      data.current = 1,
      data.empty = 1
    }

    return {
      data,
      clean,
      submit,
      handleCurrentChange,
      select,
      clear
    };
  }
}
</script>

<style lang="scss" scoped>
.el-aside {
  height: 650px;
  margin-top: 5px;
  margin-left: 2px;
  border: 1px solid;
  border-color: rgba(113, 107, 104, 0.331);

  .topdiv {
    margin-left: 25px;
    margin-top: 30px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 20px;
    font-weight: bold;
  }

  ;

  .el-divider {
    margin-top: 20px;
    margin-bottom: 20px;
    width: 160px;
    margin-left: 20px;
  }

  .el-menu {
    border-right: 0px;
    border-left: 5px;

    .el-menu-item {
      border-left: 5px;
    }

    .el-menu-item.is-active {
      //设置字体颜色
      color: #3a9e64;
      border-left: 5px solid;
    }
  }

}

.el-main {
  margin-left: 40px;
  margin-top: 20px;
  font-family: 'Courier New', Courier, monospace;
  font-size: 18px;
  font-weight: bold;
  span {
    display: inline-table;
  }

  .el-alert {
    background-color: #0000;
    color: rgb(239, 18, 18);
    margin-bottom: 0px;
    border-bottom: 0px;
    height: 20px;
    width: 220px;

    span {
      margin-top: 8px;
    }
  }

  .mid {
    border: 1px solid;
    border-color: rgb(182, 194, 204);
    font-family: 'Times New Roman', Times, serif;
    font-weight: normal;
    font-size: 16px;
    margin-top: 16px;
    
    span {
      width: 88px;
    }

    .mid-top {
      margin-top: 10px;
      margin-left: 20px;

      .el-select {
        margin-left: 60px;
        margin-right: 2%;
      }

      .d-button {
        display: block;
        text-align: center;
        margin-top: 15px;

        .el-icon {
          margin-right: 8px;
        }
      }
    }

    .mid-bottom {
      margin-top: 10px;
      width: 100%;
    }
    
  }
  .div_pag {
    margin-top: 25px;
    display: flex;
    justify-content: flex-end;
    background-color: #fff;
}

}

</style>