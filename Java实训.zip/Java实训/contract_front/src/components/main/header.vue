<template>
  <!--头部导航栏-->
  <div class="centerBox">
    <div class="top">
      <div class="topleft">
        <h2>
          <img src="/logol.jpg" />
          <span>科大国创合同管理系统</span>
        </h2>
      </div>
      <div class="middle">
        <nav>
          <router-link index="1" active-class="active" to="/contractBoard"
            >合同管理</router-link
          >
          <router-link index="2" active-class="active" to="/bar" v-if="add.userId != 2"
            >专题分析</router-link
          >
          <el-link disabled v-if="add.userId == 2">专题分析</el-link>
          <router-link index="3" active-class="active" to="weekly"
            >周报管理</router-link
          >
        </nav>
      </div>
      <!-- 右侧头像部分 -->
      <div class="topright">
        <div class="avatar">
          <el-dropdown>
            <span class="el-dropdown-link">
              <el-avatar :size="40" :src="data.headurl"></el-avatar>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="getUserInfo();dialogVisible1 = true">
                  修改信息
                </el-dropdown-item>
                <el-dropdown-item  v-if="adduserDialog" @click="log();dialogVisible2 = true;">添加用户</el-dropdown-item
                >
                <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </div>
      <!-- 修改信息 -->
      <el-dialog  v-model="dialogVisible1"  title="修改个人信息"   width="50%">
        <div class="updateinfo">
          <div class="left">
            <el-form-item label="用户头像">
              <el-upload class="upload-demo" :action="urlConfig.fileUploadUrl" :on-success="handle_success" :limit="1">
                  <el-avatar
                    :size="30"
                    :src="form.avatar"
                    @click=""
                  ></el-avatar>
              </el-upload>
            </el-form-item>
            <el-form-item label="出生日期" prop="birthday">
              <el-date-picker
                v-model="form.birthday"
                value-format="YYYY-MM-DD"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
            <el-form-item label="所在部门" prop="department">
              <el-select v-model="form.valueDepartments" disabled="true" clearable placeholder="请选择">
                <el-option
                  v-for="item in form.departments"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="用户邮箱" prop="email">
              <el-input v-model="form.email"></el-input>
            </el-form-item>
          </div>
          <div class="right">
            <el-form-item label="用户性别" prop="gender">
              <el-select v-model="form.valueGenders" clearable placeholder="请选择">
                <el-option
                  v-for="item in form.genders"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="入职日期" prop="hiredate">
              <el-date-picker
                v-model="form.hiredate"
                value-format="YYYY-MM-DD"
                type="date"
                placeholder="选择日期"
              ></el-date-picker>
            </el-form-item>
            <el-form-item label="用户账号" prop="id">
              <el-input v-model="form.id" disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="用户姓名" prop="name">
              <el-input v-model="form.name"></el-input>
            </el-form-item>
        <el-form-item label="用户身份" prop="role">
          <el-select v-model="form.valueRole" disabled="true" clearable placeholder="请选择">
            <el-option
              v-for="item in form.role"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
          </div>
        </div>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible1 = false">取消</el-button>
            <el-button type="primary" @click="updateUserInfo"> 确定 </el-button>
          </span>
        </template>
      </el-dialog>


      <!-- 添加用户 -->
      <el-dialog
        v-model="dialogVisible2"
        title="添加用户："
        width="20%"
      >
        <el-form-item label="选择部门">
          <el-select v-model="form.valueDepartments" clearable placeholder="请选择" >
            <el-option
              v-for="item in form.departments"
              :disabled="departmentMenu"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户身份" prop="role">
          <el-select v-model="add.valueRole" clearable placeholder="请选择">
            <el-option
              v-for="item in add.role"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户姓名" prop="role">
          <el-input v-model="add.name"></el-input>
        </el-form-item>

        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible2 = false">取消</el-button>
            <el-button type="primary" @click="adduser">确定</el-button>
          </span>
        </template>
      </el-dialog>
          <!--返回成功信息-->
    <el-dialog
        v-model="dialogVisible3"
        title="添加用户成功："
        width="20%"
      >
        <el-form-item label="用户姓名" prop="role">
          <el-input v-model="added.name" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="用户账号" prop="role">
          <el-input v-model="added.account" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="用户部门">
          <el-select v-model="added.valueDepartments" :disabled="true" clearable >
            <el-option
              v-for="item in added.departments"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户身份" prop="role">
          <el-select v-model="added.valueRole" :disabled="true" clearable >
            <el-option
              v-for="item in added.role"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible3 = false">确定</el-button>
          </span>
        </template>

      </el-dialog>
    </div>
  </div>
</template>

<script>
import { ref, reactive, defineComponent,onBeforeMount,onMounted } from "vue";
import {useRouter} from "vue-router";
import $constant from "@/constant/index";
import $api from '@/server/api'
import { urlConfig } from "@/config";
import $utils from "@/utils/help";
import { ElMessage } from "element-plus";

export default defineComponent({
  name: "main",

  setup() {
    const data = reactive({
      headurl:
        "https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png",
    });
    const router = useRouter();

    // 退出登录
    const logout = ({ commit }) => {
      // commit("setToken", "");
      localStorage.clear();
      router.push("/login/login_in");
    };

    //添加用户
    const add = reactive({
      account: "",
      password: "",
      departments: $constant.BG,
      valueDepartments: '',
      department:"",
      role: $constant.role,
      valueRole:"",
      name:"",
      userId:"",
    });
    let adduserDialog = ref(true);
    let dialogVisible2 = ref(false);
    let departmentMenu = ref(false);
    let dialogVisible3 = ref(false);

    onBeforeMount(() => {
      add.userId = $utils.str2obj(localStorage.getItem("role")).role;
      if(add.userId == 2){
        adduserDialog.value = false;
      }else if(add.userId == 1){
        //
        add.valueDepartments = form.valueDepartments;
        departmentMenu.value = true;
      }
    });
    
    const added = reactive({
      account: "",
      departments: $constant.BG,
      valueDepartments: '',
      role: $constant.role,
      valueRole:"",
      name:"",
    });
    async function adduser(){
      if(form.valueDepartments == 0) ElMessage.warning("部门未选择")
      // dialogVisible2 = false;
      else await $api.addUser({
        department: form.valueDepartments,
        name: add.name,
        role: add.valueRole,
      }).then(res=>{
        if(res.code == 200){
          console.log(res);
          dialogVisible2.value = false;

          dialogVisible3.value = true;     
          added.account = res.data.id;
          added.valueDepartments = res.data.department;
          added.name = res.data.name;
          added.valueRole = res.data.role;


          console.log(added);
          ElMessage.success("创建用户成功id:"+res.data.id);
        }else{
          ElMessage.error("添加用户错误！");
        }
      })
    };

    //修改个人信息
    const form = reactive({
      departments: $constant.BG,
      valueDepartments: '2',
      genders: $constant.gender,
      valueGenders: '',
      avatar: "",
      birthday: "",
      department: "",
      email: "",
      gender: "",
      hiredate: "",
      id: "",
      name: "",
      role: $constant.role,
      valueRole:"",
    });
    const dialogVisible1 = ref(false);

    onMounted(() => {
      getUserInfo();
    });

    function  handle_success(res) {
            console.log(res.data);
            form.avatar = res.data.url;

    };
    //得到个人信息
    async function getUserInfo(){
      await $api.getUserInfo().then(res=>{
        if(res.code == 200){
          form.avatar = res.data.avatar;
          form.birthday = res.data.birthday;
          form.valueDepartments = res.data.department;
          form.email = res.data.email;
          form.valueGenders = res.data.gender;
          form.hiredate = res.data.hiredate;
          form.id = res.data.id;//
          form.name = res.data.name;
          form.valueRole = parseInt(res.data.role);//
          //更新导航栏的头像
          data.headurl = res.data.avatar;
        }else{
          ElMessage.error("获取用户信息错误！");
        }
      })
    }
    function log(){
      console.log(add);
      
    }
    //更新用户信息
    async function updateUserInfo(){
      dialogVisible1.value = false;
      await $api.updateUserInfo({
        avatar:form.avatar,
        birthday:form.birthday,
        dapartment:form.valueDepartments,
        email:form.email,
        gender:form.valueGenders,
        hiredate:form.hiredate,
        id:parseInt(form.id),
        name:form.name,
        role:form.valueRole,
      }).then(res=>{
        if(res.code == 200){
          ElMessage.success("修改信息成功!");
          //更新导航栏的头像和localStorage
          // data.headurl = res.data.url;
          data.headurl = res.data.avatar;
          // add.valueDepartments = form.valueDepartments;
          localStorage.setItem("role", $utils.obj2str({
              id: parseInt(form.id),
              role: form.valueRole,
              avatar: form.avatar,
              name: form.name
          }));
        }else{
          ElMessage.error("修改信息失败!")
        }
      })
    }
    return {
      data,
      activeIndex: "1",
      dialogVisible1,
      dialogVisible2,
      dialogVisible3,
      form,
      add,
      logout,
      updateUserInfo,
      getUserInfo,
      open,
      adduser,
      adduserDialog,
      urlConfig,
      handle_success,
      added,
      departmentMenu,
      log
    };
  },
});
</script>

<style lang="scss" scoped>
// 导航栏
.centerBox {
  // width: 1950px;
  align-items: center;
  justify-content: space-between;
}
.top {
  display: flex;
  align-items: center;
  // justify-content:center;
  // justify-content: space-between;
  height: 50px;
  background-color: #ffffff;
  color: #292c2f;
  border-bottom: #acaeb1 solid 2px;
  .middle{
    // align-items: center;
    // padding-right: 500px;
    width: 65%;
  }
  .topleft {
    display: flex;
    align-items: center;
    width: 35%;
    h2 {
      display: flex;
      width: 100%;
      align-items: center;
      font: normal 20px Cookie, Arial, Helvetica, sans-serif;
      padding: 0px ;
      padding-right: 270px;
    }
  }
  .topright{
  position: relative;
  right: 0;
}
}
img {
  width: 50px;
  height: 50px;
}
nav {
  display: flex;
  align-items: center;
  margin: 0px 40px;
  // padding-top: 30px;
  font: 16px Arial, Helvetica, sans-serif;
}
nav a {
  padding: 0 15px;
  width: 90px;
  height: 50px;
  line-height: 50px;
  text-align:center;
  text-decoration: none;
  color: #050505;
  font-size: 16px;
  font-weight: normal;
  opacity: 0.9;
}
nav a:hover {
  opacity: 1;
}
.active {
  color: #f8f9fa;
  background-color: #409EFF;
  pointer-events: none;
  opacity: 1;
}

.contents {
  display: flex;
  justify-content: center;
  text-align: center;
}
.avatar {
  display: flex;
  flex: 1;
  align-items: center;
  justify-content: flex-end;
}
.dialog-footer{
  display: flex;
  justify-content: space-around;
}
// 修改信息
// .dialog-footer button:first-child {

//   // margin-right: 10px;
// }
// ::v-deep .el-dialog{
//   width: fit-content;
// }
// ::v-deep .el-form-item{
//   width: 70%;
// }
// :v-deep .el-button{
//   width: 30%;
// }
// .updateinfo {
//   height: 270px;
//   // width: 700px; 
//   // overflow: auto;
//   display: flex;

//   .left {
//     // float: left;
//   }
//   .right {
//     // overflow: hidden;
//     // padding-right: 20px;
//     // padding-left: 20px;
//   }
// }
.dialog-footer button:first-child {
  margin-right: 10px;
}
.updateinfo {
  height: 270px;
  overflow: auto;
  .left {
    float: left;
  }
  .right {
    overflow: hidden;
    padding-right: 40px;
    padding-left: 40px;
  }
}
</style>
