import { createRouter, createWebHashHistory, createWebHistory } from "vue-router"

/**
 * 合同管理
 */
 const contractModel = [
    {
        path: 'contractBoard',
        name: 'contractBoard',
        meta: { title: "合同看板" },
        component: () => import('@/components/contract/contractBoard')
    },
    {
        path: 'newContract',
        name: 'newContract',
        meta: { title: "新建合同" },
        component: () => import('@/components/contract/newContract')
    },
    {
        path: 'contractList',
        name: 'contractList',
        meta: { title: "合同列表" },
        component: () => import('@/components/contract/contractList')
    },
    {
        path: 'newCustomer',
        name: 'newCustomer',
        meta: { title: "新增客户" },
        component: () => import('@/components/contract/newCustomer')
    }
];

/**
 * 周报管理
 */
const weeklyModel = [
    {
        path: '/weekly',
        name: 'weekly',
        component: () => import('@/views/weekly.vue'),
    },
    {
        path: '/personform',
        name: 'personform',
        component: () => import('@/views/personform.vue')
    },
    {
        path: '/writeWeekly',
        name: 'writeWeekly',
        component: () => import('@/views/writeWeekly.vue')
    },  
];


/**
 * 专题分析
 */
const subjectModel = [
    {
        path: '/bar',
        name: 'bar',
        component: () => import('@/components/subject/bar.vue')
    }
];

/**
 * 主界面
 */
const mainModel = [
    ...contractModel,
    ...weeklyModel,
    ...subjectModel,

];


/**
 * 其他路由
 */
const commonModel = [
    {
        path: '/login',
        name: 'login',
        component: () => import('@/views/login.vue'),
        children:[
            {
                path:'login_in',
                name:'login_in',
                component: () => import('@/components/login/login_in.vue')
            },
            {
                path:'forget',
                name:'forget',
                component: () => import('@/components/login/forget.vue')
            },
            {
                path:'first',
                name:'first',
                component: () => import('@/components/login/first.vue')
            }
        ]
    },
];

const routes = [
    {
        path: '/',
        name: 'main',
        component: () => import('@/views/main.vue'),
        children: mainModel
    },
    ...commonModel
];

const router = createRouter({
    history: createWebHashHistory(),
    routes,
});

// router.beforeEach((to, from, next) => {
//     next();
// });

// router.afterEach((to, from, next) => {
//     next();
// });

export default router