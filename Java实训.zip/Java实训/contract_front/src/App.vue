<template>
  <router-view v-slot="{ Component }">
    <keep-alive>
      <component :is="Component" />
    </keep-alive>
  </router-view>
</template>

<script>
import { defineComponent, onMounted } from "vue";
import { useRouter } from "vue-router";

export default defineComponent({
  setup() {
    const router = useRouter();
    
    onMounted(() => {
      if(localStorage.getItem("token") == null) {
        router.push("/login/first");
      }
    })
    return {
    };
  },
});
</script>

<style lang="scss" scoped>


</style>
