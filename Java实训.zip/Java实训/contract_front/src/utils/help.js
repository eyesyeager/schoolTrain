import CryptoJS from 'crypto-js';

let key = CryptoJS.enc.Utf8.parse('1538663015386630');
let iv = CryptoJS.enc.Utf8.parse('sdaefascvfelk392');

export default {
    // 加密密码
    encryption: req => {
        let pwd = CryptoJS.enc.Utf8.parse(req);
        let encrypted = CryptoJS.AES.encrypt(pwd, key, {
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
            iv: iv
        })
        return encrypted.toString();
    },

    // 对象加密
    obj2str: req => {
        let encrypted = "";
        const data = JSON.stringify(req);
        const srcs = CryptoJS.enc.Utf8.parse(data);
        encrypted = CryptoJS.AES.encrypt(srcs, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        return encrypted.ciphertext.toString();
    },

    // 对象解密
    str2obj: str => {
        const encryptedHexStr = CryptoJS.enc.Hex.parse(str);
        const srcs = CryptoJS.enc.Base64.stringify(encryptedHexStr);
        const decrypt = CryptoJS.AES.decrypt(srcs, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });
        const decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
        return JSON.parse(decryptedStr.toString());
    },

    // 构建 [{label: "", value: ""}] 类型数据
    buildLabVal: (labArr, valArr) => {
        if (labArr.length !== valArr.length || labArr.length === 0) return false;
        let res = [];
        for (let i = 0; i < labArr.length; i++) {
            res.push({
                label: labArr[i],
                value: valArr[i]
            });
        }
        return res;
    },

};