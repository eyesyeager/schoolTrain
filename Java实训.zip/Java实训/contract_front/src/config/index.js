/**
 * 链接配置
 */
const urlConfig = {
    testUrl: "http://rap2api.taobao.org/app/mock/304180",
    proUrl: "/api",
    fileUploadUrl: "/api/user/upload",
};

/**
 * 加密密钥
 */
const key = "contract management";
const tokenKey = 'admin-token';

export { urlConfig, key, tokenKey };




