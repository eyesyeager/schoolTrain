<template>
  <div>
    <div>
      <centerBox></centerBox>
    </div>
    <div class="contents">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import centerBox from "@/components/main/header";

export default {
  name: "FirstMain",
  components: {
    centerBox,
  },

  data() {
    return {};
  },

  mounted() {
  },

  methods: {
  },
};
</script>

<style scoped>
</style>
