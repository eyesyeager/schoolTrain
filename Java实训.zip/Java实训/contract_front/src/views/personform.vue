<template>
  <div class="person">
    <div class="form1">
      <div class="top">
        <h1>{{ name }} 周报推送</h1>
        <p>创建时间：{{ date }}</p>
      </div>
      <p class="title">出勤地点</p>
      <el-table
        :header-cell-style="{
          background: '#eef1f6',
          color: '#606266',
          'text-align': 'center',
        }"
        :cell-style="{ 'text-align': 'center' }"
        class="addr"
        :data="attendance"
        border
        style="width: 100%"
      >
        <el-table-column
          prop="date1"
          label="周一"
          min-width="70%"
        ></el-table-column>
        <el-table-column
          prop="date2"
          label="周二"
          min-width="70%"
        ></el-table-column>
        <el-table-column
          prop="date3"
          label="周三"
          min-width="70%"
        ></el-table-column>
        <el-table-column
          prop="date4"
          label="周四"
          min-width="70%"
        ></el-table-column>
        <el-table-column
          prop="date5"
          label="周五"
          min-width="70%"
        ></el-table-column>
        <el-table-column
          prop="date6"
          label="周六"
          min-width="70%"
        ></el-table-column>
        <el-table-column prop="date7" label="周日"></el-table-column>
      </el-table>

      <p class="title">本周签单</p>
      <div class="box">{{ signature }}</div>

      <p class="title">本周回款</p>
      <div class="box">{{ money }}</div>

      <p class="title">本周项目跟踪</p>
      <div class="box">{{ project }}</div>

      <p class="title">其他相关工作内容</p>
      <div class="box">{{ otherContent }}</div>

      <p class="title">下周工作计划</p>
      <div class="box">{{ nextWeekWork }}</div>

      <p class="title">问题和思考</p>
      <div class="box">{{ problemAndThink }}</div>

      <p class="title">备注</p>
      <div class="box">{{ remarks }}</div>

      <div class="blank"></div>
      <el-button class="btn" @click="clicktrue">展示历史点评</el-button>
      <div class="blank"></div>
      <!--展示评论-->
      <div class="box" v-show="show">
        <div v-for="(item,i) in comments" :key="i" class="commentBox">
          <div class="commentTop">
            <el-avatar :src="item.userAvatar"></el-avatar>
            <div class="author-info">
              <div class="author-name">
                <span>{{ item.userName }}</span>
              </div>
              <div>
               <span class="author-time">{{ item.commentTime }}</span>  
              </div>
            </div>
          </div>
          <div class="commentContent">
            <p>
              <span class="comment">{{item.comment}}</span>
            </p>
          </div>
        </div>
      </div>

      <div class="blank"></div>
      <el-input
        type="textarea"
        :rows="5"
        placeholder="请输入点评"
        v-model="commenting"
      ></el-input>
      <el-button class="btn" @click="onSubmit">发布</el-button>
    </div>

    <div class="imge">
      <div class="head">
        <el-row class="demo-avatar">
          <el-col :span="12">
            <div class="demo-basic--circle">
              <div class="block">
                <el-avatar
                  class="tu"
                  shape="square"
                  :size="100"
                  :src="avatar"
                ></el-avatar>
                <p>{{ name }}</p>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import $api from "@/server/api.js";
import $utils from "@/utils/help";

export default {
  data() {
    return {
      show: false,
      name: "",
      date: "",
      avatar:
        "https://cube.elemecdn.com/9/c2/f0ee8a3c7c9638a54940382568c9dpng.png",

      signature: "",
      money: 0.0,
      project: "",
      otherContent: "",
      nextWeekWork: "",
      problemAndThink: "",
      remarks: "",
      historyComment: "",
      commenting:"",
      comments: [
        {
          id: "", //点评id
          userId: '',
          userName: "",
          userAvatar: "",
          commentTime: "",
          comment: "",
        },
      ],
      attendance: [],
    };
  },
  mounted() {
    this.getform();
  },
  methods: {
    //获取周报点评
    async clicktrue() {
      this.show = !this.show;
      if (this.show == true) {
        await $api.getWeeklyComments({
          id: parseInt(this.$route.query.id)
        }).then((res) => {
          if (res.code == 200) {
            this.comments = res.data;
            console.log(res);
          } else {
            ElMessage.error("请求错误，错误原因：" + res.msg);
          }
        });
      } else {
      }
    },
    //发送点评
    async onSubmit() {
      if (this.commenting.trim().length === 0) {
        ElMessage.warning("点评的内容不能为空！！！");
      }
      else{
      const sendcomments = {
        weeklyId: parseInt(this.$route.query.id), //周报id
        userId: $utils.str2obj(localStorage.getItem("role")).id, //评论人id
        comment: this.commenting,
      };
      await $api.addWeeklyComment(sendcomments).then((res) => {
        if (res.code == 200) {
          this.clicktrue();
          ElMessage.success("发布成功！");
          // console.log("submit!");
        } else {
          ElMessage.error("请求错误，错误原因：" + res.msg);
        }
      });        
      }

    },

    //查看周报
    async getform() {
      console.log(this.$route.query);
      await $api
        .getWeekly({
          id: this.$route.query.id,
        })
        .then((res) => {
          if (res.code == 200) {
            this.name = res.data.name;
            this.date = res.data.date;
            this.avatar = res.data.avatar;
            this.signature = res.data.signature;
            this.money = res.data.money;
            this.project = res.data.project;
            this.otherContent = res.data.otherContent;
            this.nextWeekWork = res.data.nextWeekWork;
            this.problemAndThink = res.data.problemAndThink;
            this.remarks = res.data.remarks;
            this.historyComment = res.data.historyComment;
            this.attendance = [this.array2Object(res.data.attendance)];
            console.log(res);
          } else {
            ElMessage.error("请求错误，错误原因：" + res.msg);
          }
        });
    },

    array2Object(arr) {
      let res = new Object();
      arr.forEach((v, i) => {
        res["date" + (i + 1)] = v
      });
      return res;
    },
  },
};
</script>

<style lang="scss" scoped>
.form1 {
  width: 66%;
  display: inline-block;
  margin-left: 4%;
  .top {
    width: 100%;
    display: table;
    text-align: center;
  }
}
.imge {
  width: 26%;
  display: inline-block;
  float: right;
  margin-right: 4%;
  margin-top: 8%;
}
.block {
  width: 400px;
  text-align: center;
}
.title {
  width: 100%;
  height: 25px;
  border-left: 4px solid #409EFF;
}
.box {
  min-height: 50px;
  width: 100%;
  border: 2px solid #c0c0c0;
  border-radius: 5px;
  color: #606266;
  font-size: 16px;
  padding: 10px;
}
.blank {
  height: 20px;
}
.btn {
  background: #409EFF;
  color: white;
}
// li {
//   font-size: 15px;
//   color: #606266;
// }
.commentBox{
  .commentTop{
    .author-info{
      display: inline-block;
      margin-left: 15px;
      .author-name{
        color:#606266;       
      }
      .author-time{
        font-size:5px;
        color:#606266;
      }
    }
  }
  .commentContent{
    margin-left:55px;
    color:#606266;
  }
  // border-bottom: 2px solid #606266;
  // margin-bottom: 10px;
}

</style>
