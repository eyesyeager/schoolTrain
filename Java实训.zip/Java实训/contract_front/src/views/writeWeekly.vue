<template>
  <div class="person">
    <div class="form1">
        <div class="top">
            <h1>{{ weekly.name }} 创建周报</h1>
        </div>

        <span class="title">创建的时间: </span>
        <el-date-picker
          v-model="weekly.date"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择日期"
          :disabled-date="pickerOptions.disabledDate"
        ></el-date-picker>
       <div class="blank"></div>

        <span class="title">周起始日期: </span>
        <el-date-picker
          v-model="weekly.weekFlag"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择日期"
          :disabled-date="pickerOptions.disabledDate"
        ></el-date-picker>

        <p class="title">出勤地点</p>
            <el-table
                :header-cell-style="{
                background: '#eef1f6',
                color: '#606266',
                'text-align': 'center',
                }"
                :cell-style="{ 'text-align': 'center' }"
                class="addr"
                :data="attendance"
                border
                style="width: 100%"
            >
                <el-table-column  prop="date1" label="周一" min-width="70%">
                    <el-input class="rule-input" v-model="attendance[0].date1" placeholder="请输入内容" ></el-input>              
                </el-table-column>

                <el-table-column prop="date2" label="周二" min-width="70%">
                    <el-input v-model="attendance[0].date2" placeholder="请输入内容" ></el-input>
                </el-table-column>

                <el-table-column prop="date3" label="周三" min-width="70%" >
                    <el-input v-model="attendance[0].date3" placeholder="请输入内容" ></el-input>
                </el-table-column>

                <el-table-column prop="date4" label="周四" min-width="70%" >
                    <el-input v-model="attendance[0].date4" placeholder="请输入内容" ></el-input>
                </el-table-column>

                <el-table-column prop="date5" label="周五" min-width="70%">
                    <el-input v-model="attendance[0].date5" placeholder="请输入内容" ></el-input>
                </el-table-column>

                <el-table-column prop="date6" label="周六" min-width="70%">
                    <el-input v-model="attendance[0].date6" placeholder="请输入内容" ></el-input>
                </el-table-column>

                <el-table-column prop="date7" label="周日">
                    <el-input v-model="attendance[0].date7" placeholder="请输入内容" ></el-input>
                </el-table-column>
            </el-table>  


        <p class="title">所属部门</p>
        <el-select v-model="weekly.valueDepartment" clearable placeholder="请选择">
          <el-option
            v-for="item in weekly.departments"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>

        <p class="title">本周签单</p>
        <el-input type="textarea" :rows="2" prop="signature" v-model="weekly.signature"></el-input>

        <p class="title">本周回款</p>
        <el-input type="textarea" :rows="2" prop="money" v-model="weekly.money" ></el-input>

        <p class="title">本周项目跟踪</p>
        <el-input type="textarea" :rows="2" prop="project" v-model="weekly.project" ></el-input>

        <p class="title">其他相关工作内容</p>
        <el-input type="textarea" :rows="2" prop="otherContents" v-model="weekly.otherContent" ></el-input>

        <p class="title">下周工作计划</p>
        <el-input type="textarea" :rows="2" prop="nextWeekWork" v-model="weekly.nextWeekWork" ></el-input>

        <p class="title">问题和思考</p>
        <el-input type="textarea" :rows="2" prop="problemAndThink" v-model="weekly.problemAndThink" ></el-input>

        <p class="title">备注</p>
        <el-input type="textarea" :rows="2" prop="remarks" v-model="weekly.remarks" ></el-input>


        <div class="blank"></div>
        <el-button class="btn" @click="addWeekly">发送周报</el-button>
        <div class="blank"></div>
        <div class="blank"></div>

    </div>
    <!--右侧头像和姓名-->
    <div class="imge">
      <div class="head">
        <el-row class="demo-avatar">
          <el-col :span="12">
            <div class="demo-basic--circle">
              <div class="block">
                <el-avatar
                  class="tu"
                  shape="square"
                  :size="100"
                  :src="weekly.avatar"
                ></el-avatar>
                <p>{{ weekly.name }}</p>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
    </div>

  </div>
</template>

<script>
import $api from "@/server/api.js";
// import { Role, Weekly }  from "@/module/store.js";
import $constant from "@/constant/index";
import $utils from "@/utils/help";

export default {
  data() {
    return {
    pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
    weekly:{
      departments: $constant.BG,
      valueDepartment: "",
      department:"",
      name: "",
      date: "",
      weekFlag:"",
      avatar:
        "https://cube.elemecdn.com/9/c2/f0ee8a3c7c9638a54940382568c9dpng.png",

      signature: "",
      money: "",
      project: "",
      otherContent: "",
      nextWeekWork: "",
      problemAndThink: "",
      remarks: "",
    },
      attendance:[{
        date1:"",
        date2:"",
        date3:"",
        date4:"",
        date5:"",
        date6:"",
        date7:"",
      }],
    };
  },
  created() {
    this.getInfo();
  },
  methods: {
    //     array2Object(arr) {
    //   let res = new Object();
    //   arr.forEach((v, i) => {
    //     res["date" + (i + 1)] = v
    //   });
    //   return res;
    // },
    //发送周报
    async addWeekly() {
      if (this.weekly.signature.trim().length === 0) {
        ElMessage.warning("本周签单的内容不能为空！！！");
      }else if(this.weekly.money.trim().length === 0){
        ElMessage.warning("本周回款的内容不能为空！！！");
      }else if(this.weekly.project.trim().length === 0){
        ElMessage.warning("本周项目跟踪的内容不能为空！！！");
      }else if(this.weekly.otherContent.trim().length === 0){
        ElMessage.warning("其他相关工作内容的内容不能为空！！！");
      }else if(this.weekly.nextWeekWork.trim().length === 0){
        ElMessage.warning("下周工作计划的内容不能为空！！！");
      }else if(this.weekly.problemAndThink.trim().length === 0){
        ElMessage.warning("问题和思考的内容不能为空！！！");
      }else{
        const week = {
            department:this.weekly.valueDepartment,
            name:this.weekly.name, 
            date:this.weekly.date , 
            avatar:this.weekly.avatar , 
            signature:this.weekly.signature,
            money:parseInt(this.weekly.money) , 
            project:this.weekly.project , 
            otherContext:this.weekly.otherContent, 
            nextWeekWork:this.weekly.nextWeekWork ,
            problemAndThink:this.weekly.problemAndThink , 
            remarks:this.weekly.remarks , 
            weekFlag:this.weekly.weekFlag,        
        }
        await $api
          .addWeekly({
            weekly:week,
            attendance:Object.values(this.attendance[0]),
            // attendance:this.object2Array(this.attendance),
          })
          .then((res) => {
              console.log(res);          
          if (res.code == 200) {
            ElMessage.success("发送成功！");
            this.$router.push("/weekly")
          } else {
            ElMessage.error("请求错误，错误原因：" + res.msg);
          }
        });
      }

    },
    //初始化周报信息
    getInfo(){
        // this.weekly.name = "test"
        // this.weekly.avatar = "test"
        this.weekly.name = $utils.str2obj(localStorage.getItem("role")).name;
        this.weekly.avatar = $utils.str2obj(localStorage.getItem("role")).avatar;
    }
  },
};
</script>

<style lang="scss" scoped>
// .rule-input ::v-deep {
//     .el-input__inner {
//         border: 0;
//     }
// }
a {
  text-decoration: none;
}
 
.router-link-active {
  text-decoration: none;
}
.form1 {
  width: 66%;
  display: inline-block;
  margin-left: 4%;
  .top {
    width: 100%;
    display: table;
    text-align: center;
  }
}
.imge {
  width: 26%;
  display: inline-block;
  float: right;
  margin-right: 4%;
  margin-top: 8%;
}
.block {
  width: 400px;
  text-align: center;
}
.title {
  width: 100%;
  height: 25px;
  border-left: 4px solid #409EFF;
}
.box {
  min-height: 50px;
  width: 100%;
  border: 2px solid #c0c0c0;
  border-radius: 5px;
  color: #606266;
  font-size: 16px;
  padding: 10px;
}
.blank {
  height: 20px;
}
.btn {
  background: #409EFF;
  color: white;
}

</style>
