<template>
  <!--这个界面是周报管理的列表-->
  <div class="box">
    <h3>团队周报</h3>
    <el-form :inline="true" :model="queryParams" class="demo-form-inline">
      <!-- <span>共 {{ queryParams.totalNum }} 条数据</span> -->
      <el-form-item>
        <span class="littletitle"> 共 {{ queryParams.totalNum }} 条数据 </span>
      </el-form-item>
      <el-form-item label="编写人:">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入编写人"
        ></el-input>
      </el-form-item>
      <el-form-item label="选择部门:">
        <el-select v-model="value" clearable placeholder="请选择">
          <el-option
            v-for="item in departments"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="选择日期:">
        <!-- <el-date-picker
          v-model="queryParams.date"
          type="week"
          format="yyyy 第 WW 周"
          placeholder="选择周">
        </el-date-picker> -->

        <el-date-picker
          v-model="queryParams.date"
          value-format="YYYY-MM-DD"
          type="date"
          placeholder="选择日期"
          :disabled-date="pickerOptions.disabledDate"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleQuery">搜索</el-button>
        <!-- icon="el-icon-search" -->
        <!-- <el-button type="primary" :icon="Search">Search</el-button>  -->
      </el-form-item>
      <el-form-item>
        <!-- <router-link to="/writeWeekly"> -->
          <el-button type="primary" @click="pushAdd">新增周报</el-button>        
        <!-- </router-link>         -->
      </el-form-item>
    </el-form>
    <div class="divtable">
      <el-table
        v-loading="loading"
        :data="content"
        :border="true"
        ref="refList"
        stripe
      >
        <el-table-column type="index" label="序号" width="60" align="center" />
        <el-table-column
          label="时间"
          align="center"
          prop="date"
          :show-overflow-tooltip="true"
        />
        <el-table-column
          label="编写人"
          align="center"
          prop="name"
          :show-overflow-tooltip="true"
        />
        <el-table-column
          label="本周签单"
          align="center"
          prop="signature"
          :show-overflow-tooltip="true"
        />
        <el-table-column
          label="本周回款"
          align="center"
          prop="money"
          :show-overflow-tooltip="true"
        />
        <el-table-column
          label="本周项目跟踪"
          width="280"
          align="center"
          prop="project"
          :show-overflow-tooltip="true"
        />
        <el-table-column
          label="其他相关工作"
          align="center"
          prop="otherContent"
          :show-overflow-tooltip="true"
        />
        <el-table-column label="操作" align="center">
          <template  #default="scope">
            <el-button
                :text="true"
                style="color: #409eff"
                >
                  <router-link :to="`/personform?id=${scope.row.id}`">查看</router-link>
                </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="div_pag">
        <el-pagination
          v-model:currentPage="queryParams.pageNum"
          v-model:page-size="queryParams.pageSize"
          :page-sizes="[5, 10, 15, 20]"
          :background="true"
          layout="total, sizes, prev, pager, next, jumper"
          :total="queryParams.totalNum"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import $api from "@/server/api";
import $constant from "@/constant/index";
import router from '../router';

export default {
  name: "box",

  data() {
    let id;
    return {
      loading: false,
      queryParams: {
        //默认打开第一页
        pageNum: 1,
        pageSize: 10,
        totalNum: 0,
        name: "",
        department: "",
        date: "",
      },

      departments: $constant.BG,
      value: "",
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
      },
      content: [
        {
          date: "",
          name: "",
          signature: "",
          money: "",
          project: "",
          otherContent: "",
        },
      ],
    };
  },
  created() {
    this.gettable();
  },
  methods: {


    //获取周报列表
    async handleQuery() {
      const queryObj = {
        date: this.queryParams.date,
        name: this.queryParams.name,
        department: this.value || null,
        page: this.queryParams.pageNum,
        pageSize: this.queryParams.pageSize,
      };
      console.log(queryObj);

      await $api.weekly(queryObj).then((res) => {
        console.log(res,1254);
        if (res.code == 200) {
          this.content = res.data.content;
          this.queryParams.totalNum = res.data.totalNum;
          console.log(this.content,this.queryParams.totalNum);
        } else {
          ElMessage.error("请求错误，错误原因：" + res.msg);
        }
      });
    },
    //初始化页面获取列表
    async gettable() {
      this.loading = true;
      const querypage = {
        page: this.queryParams.pageNum,
        pageSize: this.queryParams.pageSize,
      };
      await $api.weekly(querypage).then((res) => {
        if (res.code == 200) {
          this.loading = false;
          this.content = res.data.content;
          this.queryParams.totalNum = res.data.totalNum;
        } else {
          ElMessage.error("请求错误，错误原因：" + res.msg);
        }
      });
    },
    // 选择一页显示多少条数据
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pageSize = val;
      this.gettable();
    },
    // 选择当前页是第几页
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.pageNum = val;
      this.gettable();
    },
    pushAdd(){
      router.push('/writeWeekly');
    }
  },
};
</script>

<style lang="scss" scoped>
.box {
  margin: 30px;
  width: 1400px;
  margin-top: 40px;
  // el-form{
  //   padding-left: 50px;
  // }
}
.div_pag {
  margin-top: 25px;
  display: flex;
  justify-content: flex-end;
}
.littletitle {
  font-size: 15px;
  color: #606266;
}
</style>
