<template>
  <div class="loginBackground">
    <router-view></router-view>
  </div>
</template>

<script>

import { defineComponent} from "vue";
import { useRouter } from "vue-router";


export default defineComponent({
  name:'login',
  setup() {
    const router = useRouter();
    router.push("/login/login_in");
    return {
      
    };
  }
});
</script>


<style lang="scss" scoped>

</style>