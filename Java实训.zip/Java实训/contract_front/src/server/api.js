import { get, post, put, del } from "./ajax"

/**
 * 测试接口
 */
const testModel = {
    test: () => {
        return get('/test/test1');
    }
}

/**
 * 通用接口
 */
const commonModel = {


}

/**
 * 主界面接口
 */
const mainModel = {
    getUserInfo: () => {
        return get ('/user/getUserInfo', true);
    },
    updateUserInfo: (req) => {
        return put ('/user/updateUserInfo',req, true);
    },
    addUser: (req) => {
        return post ('/user/addUser',req, true);
    },
    
}

/**
 * 合同管理
 */
const contractModel = {
    findCustomer: () => {//
        return post('/contract/findCustomer', null, true)
    },
    findByTime: (req) => {
        return get('/contract/findByTime' + req, true)
    },
    findContractPay: (req) => {
        return get('/contract/findContractPay' + req, true)
    },
    previewContract: (req) => {
        return get('/contract/previewContract' + req, true)
    },
    addContract: (req) => {
        return post('/contract/saveContract', req, true)
    },
    closeContract: (req) => {
        return get('/contract/closeContract' + req, true)
    },
    enterContract: (req) => {
        return get('/contract/enterContract' + req, true)
    },
    findByName: (req) => {
        return get('/contract/findByName' + req, true)
    },
    addCustomer: (req) => {
        return post('/contract/saveCustomer', req, true)
    },
    uploadFile: (req) => {
        return post('/uploadFile', req, true)
    }

}


/**
 * 周报管理
 */
const weeklyModel = {
    weekly: (req) => {
        return post('/weekly/getWeeklys', req, true);
    },
    getWeekly: (req) => {
        return post('/weekly/getWeekly', req, true);
    },
    addWeeklyComment: (req) => {
        return post('/WeeklyComment/addWeeklyComment', req, true);
    },
    getWeeklyComments: (req) => {
        return post('/WeeklyComment/getWeeklyComments', req, true);
    },
    addWeekly:(req) => {
        return post ('/weekly/addWeekly',req,true);
    }

}

/**
 * 专题分析
 */
const subjectModel = {
    selectContract: (current,req, isBaseUrl) => {
        return post('/contract/findByCondition'+"?current="+current, req, isBaseUrl);
    }
}
/**
 * 登录注册
 */
const loginModel = {
    check: (req) => {
        return post('/user/getVeriCode', req, true);
    },

    submitForm: (req) => {
        return post('/user/login', req, true);
    },

    getMailCode: (req) => {
        return post('/user/getMailCode', req, true);
    },

    submitpassword: (req) => {
        return post('/user/firstLogin', req, true);
    },

    updatePsd: (req) => {
        return put('/user/updatePsd', req, true);
    }
}

export default {
    ...testModel,
    ...commonModel,
    ...mainModel,
    ...contractModel,
    ...weeklyModel,
    ...subjectModel,
    ...loginModel
};