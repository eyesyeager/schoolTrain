import axios from "axios";
import { urlConfig } from "@/config";
import router from "@/router";

const service = axios.create({
    timeout: 60 * 1000,
    withCredentials: true
});

service.interceptors.request.use(
    config => {
        let anon = ["/user/getMailCode", "/user/firstLogin", "/user/updatePsd", "/user/login", "/user/getVeriCode"];
        if(!anon.includes(config.url.replace(urlConfig.proUrl, ""))) {
            config.headers.Authorization = localStorage.getItem("token");
        }
        return config;
    },
    error => {
        return Promise.reject(error);
    }
);

service.interceptors.response.use(
    response => {
        if (response.headers.authorization != null) {
            localStorage.setItem("token", response.headers.authorization);
        }
        return response.data;
    },
    error => {
        console.log("response error", error);
        if (error.response.data.code == 444) {
            localStorage.removeItem("token");
            router.push("/login/login_in");
        }
        return Promise.reject(error);
    }
);

export function get(url, isBaseUrl) {
    return service.get((isBaseUrl ? urlConfig.proUrl : urlConfig.testUrl) + url)
}

export function post(url, req, isBaseUrl) {
    return service.post((isBaseUrl ? urlConfig.proUrl : urlConfig.testUrl) + url, req)
}

export function put(url, req, isBaseUrl) {
    return service.put((isBaseUrl ? urlConfig.proUrl : urlConfig.testUrl) + url, req)
}

export function del(url, req, isBaseUrl) {
    return service.delete((isBaseUrl ? urlConfig.proUrl : urlConfig.testUrl), url, req)
}