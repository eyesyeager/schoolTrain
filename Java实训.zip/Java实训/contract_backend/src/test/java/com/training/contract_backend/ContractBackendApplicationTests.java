package com.training.contract_backend;

import com.training.contract_backend.model.Dto.LoginDto;
import com.training.contract_backend.service.UserService;
import com.training.contract_backend.utils.EncryptionUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractBackendApplicationTests {

    @Autowired
    private UserService userService;

    @Test
    void contextLoads() {
        System.out.println(EncryptionUtils.oneWayHash("rootroot", "rootroot"));
    }

    @Test
    void test1() throws Exception {
        LoginDto loginDto = new LoginDto();
        loginDto.setId(2020214633);
        loginDto.setPassword("123");
        loginDto.setKey("9b3f4516f13f3a4ab9b005895e0de8670c5c3a2econtractGr4Hqhc5U5aqqWiJYGtDrQ==");
        loginDto.setCode("0b84");
        userService.doLogin(loginDto);
    }

    @Test
    void test2() throws Exception {
        System.out.println(EncryptionUtils.decrypt("EwE72Blw29viC1gLx+hSeA=="));
    }

    @Test
    void test3() {
        System.out.println(userService.getUserInfo(20220001));
    }
}
