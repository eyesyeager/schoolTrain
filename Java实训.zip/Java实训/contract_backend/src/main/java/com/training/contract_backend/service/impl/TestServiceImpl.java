package com.training.contract_backend.service.impl;

import com.training.contract_backend.service.TestService;
import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {
}
