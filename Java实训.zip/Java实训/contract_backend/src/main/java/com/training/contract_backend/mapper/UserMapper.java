package com.training.contract_backend.mapper;

import com.training.contract_backend.model.Dto.LoginEmailDto;
import com.training.contract_backend.model.Dto.UserAddDto;
import com.training.contract_backend.model.Dto.UserInfoDto;
import com.training.contract_backend.model.Po.UserPartInfoDo;
import com.training.contract_backend.model.Po.UserRolePo;
import com.training.contract_backend.model.bean.UserBean;
import org.apache.ibatis.annotations.*;

import java.util.Set;

@Mapper
public interface UserMapper{
    @Select("select password from user where id = #{id}")
    String getUserPassword(Integer id);

    @Update("update user set password = #{password} where id = #{id}")
    Integer updatePsd(Integer id, String password);

    @Select("select email from user where id = #{id}")
    String getEmailById(Integer id);

    @Select("SELECT 1 FROM user WHERE email = #{email} LIMIT 1")
    Integer isExistEmail(String email);

    @Update("update user set password = #{password} , email = #{email} where id = #{id}")
    Integer firstLogin(LoginEmailDto loginEmailDto);

    @Select("select name, avatar, role from user where id = #{id}")
    UserPartInfoDo getNameAndAvatarById(Integer id);

    @Select("select id, password, email, role, status from user where id = #{id}")
    UserBean getUserBean(Integer id);

    @Select("select role from role where user_id = #{id}")
    Set<String> getUserRoles(Integer id);

    @Select("select id, name, role, department from user where id = #{id}")
    UserRolePo getUserRole(Integer id);

    @Select("select id, name, avatar, gender, birthday, hiredate, email, department, role from user where id = #{id}")
    UserInfoDto getUserInfo(Integer id);

    @Update("update user set name = #{name}, avatar = #{avatar}, gender = #{gender}, birthday = #{birthday}, email = #{email} where id = #{id}")
    void updateUserInfo(UserInfoDto userInfoDto);

    @Insert("insert into user (name, department, role, hiredate) values(#{name}, #{department}, #{role}, now())")
    @Options(useGeneratedKeys=true, keyProperty="id", keyColumn="id")
    void register(UserAddDto userAddDto);

    @Insert("insert into role (user_id, role) values(#{id}, #{role})")
    void addRole(Integer id, String role);
}
