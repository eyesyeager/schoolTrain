package com.training.contract_backend.model.Do;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@ApiModel("合同实体类")
public class ContractDo {

    // 查询条件
    // 签单状态
    @ApiModelProperty("签单状态")
    private int contractStatus;
    // BG
    @ApiModelProperty("BG")
    private int BG;
    // BU
    @ApiModelProperty("BU")
    private int BU;
    // 省份
    @ApiModelProperty("省份")
    private int province;
    // 区域
    @ApiModelProperty("区域")
    private int region;
    // 所属行业
    @ApiModelProperty("所属行业")
    private int industry;
    // 所属子行业
    @ApiModelProperty("所属子行业")
    private int industryChild;

    // 返回结果
    // 合同名称
    @ApiModelProperty("合同名称")
    private String name;
    // 客户名称
    @ApiModelProperty("客户名称")
    private String customer;
    // 合同金额
    @ApiModelProperty("合同金额")
    private double contractTotalMoney;
    // 签订时间
    @ApiModelProperty("签订时间")
    private Date createTime;

    public int getContractStatus() {
        return contractStatus;
    }

    public void setContractStatus(int contractStatus) {
        this.contractStatus = contractStatus;
    }

    public int getBG() {
        return BG;
    }

    public void setBG(int BG) {
        this.BG = BG;
    }

    public int getBU() {
        return BU;
    }

    public void setBU(int BU) {
        this.BU = BU;
    }

    public int getProvince() {
        return province;
    }

    public void setProvince(int province) {
        this.province = province;
    }

    public int getRegion() {
        return region;
    }

    public void setRegion(int region) {
        this.region = region;
    }

    public int getIndustry() {
        return industry;
    }

    public void setIndustry(int industry) {
        this.industry = industry;
    }

    public int getIndustryChild() {
        return industryChild;
    }

    public void setIndustryChild(int industryChild) {
        this.industryChild = industryChild;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public double getContractTotalMoney() {
        return contractTotalMoney;
    }

    public void setContractTotalMoney(double contractTotalMoney) {
        this.contractTotalMoney = contractTotalMoney;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }


    // 合同唯一标识
    @ApiModelProperty("合同唯一标识")
    private int id;
    // 合同编号
    @ApiModelProperty("合同编号")
    private String identifier;
    // 项目类型
    @ApiModelProperty("项目类型")
    private int projectType;
    // 机构
    @ApiModelProperty("机构")
    private int organization;
    // 乙方单位
    @ApiModelProperty("乙方单位")
    private int customerOrgan;
    // 客户经理
    @ApiModelProperty("客户经理")
    private String accountManager;
    // 产品线
    @ApiModelProperty("产品线")
    private int productLine;
    // 维保期
    @ApiModelProperty("维保期")
    private int protectionTime;
    // 约定货币
    @ApiModelProperty("约定货币")
    private int currency;
    // 履约保证金
    @ApiModelProperty("履约保证金")
    private int isBond;
    // 付款方式
    @ApiModelProperty("付款方式")
    private int payType;
    // 合同正文
    @ApiModelProperty("合同正文")
    private String contractBody;
    // 毛利率分析表
    @ApiModelProperty("毛利率分析表")
    private String grossProfitTable;
    // 价格清单表
    @ApiModelProperty("价格清单表")
    private String schedulePricesTable;
    // 其他
    @ApiModelProperty("其他")
    private String otherInfo;
    // 合同类型
    @ApiModelProperty("合同类型")
    private int contractTypeNum;
    // 税率总额
    @ApiModelProperty("税率总额")
    private double contractTotalTax;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public int getProjectType() {
        return projectType;
    }

    public void setProjectType(int projectType) {
        this.projectType = projectType;
    }

    public int getOrganization() {
        return organization;
    }

    public void setOrganization(int organization) {
        this.organization = organization;
    }

    public int getCustomerOrgan() {
        return customerOrgan;
    }

    public void setCustomerOrgan(int customerOrgan) {
        this.customerOrgan = customerOrgan;
    }

    public String getAccountManager() {
        return accountManager;
    }

    public void setAccountManager(String accountManager) {
        this.accountManager = accountManager;
    }

    public int getProductLine() {
        return productLine;
    }

    public void setProductLine(int productLine) {
        this.productLine = productLine;
    }

    public int getProtectionTime() {
        return protectionTime;
    }

    public void setProtectionTime(int protectionTime) {
        this.protectionTime = protectionTime;
    }

    public int getCurrency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int getIsBond() {
        return isBond;
    }

    public void setIsBond(int isBond) {
        this.isBond = isBond;
    }

    public int getPayType() {
        return payType;
    }

    public void setPayType(int payType) {
        this.payType = payType;
    }

    public String getContractBody() {
        return contractBody;
    }

    public void setContractBody(String contractBody) {
        this.contractBody = contractBody;
    }

    public String getGrossProfitTable() {
        return grossProfitTable;
    }

    public void setGrossProfitTable(String grossProfitTable) {
        this.grossProfitTable = grossProfitTable;
    }

    public String getSchedulePricesTable() {
        return schedulePricesTable;
    }

    public void setSchedulePricesTable(String schedulePricesTable) {
        this.schedulePricesTable = schedulePricesTable;
    }

    public String getOtherInfo() {
        return otherInfo;
    }

    public void setOtherInfo(String otherInfo) {
        this.otherInfo = otherInfo;
    }

    public int getContractTypeNum() {
        return contractTypeNum;
    }

    public void setContractTypeNum(int contractTypeNum) {
        this.contractTypeNum = contractTypeNum;
    }

    public double getContractTotalTax() {
        return contractTotalTax;
    }

    public void setContractTotalTax(double contractTotalTax) {
        this.contractTotalTax = contractTotalTax;
    }

    // 当前合同有哪些支付信息
    @ApiModelProperty("支付信息数组")
    private List<ContractPayDo> contractPayDoList;
    // 当前合同有哪些合同类型
    @ApiModelProperty("合同类型数组")
    private List<ContractTypeDo> contractTypeDoList;

    public List<ContractPayDo> getContractPayDoList() {
        return contractPayDoList;
    }

    public void setContractPayDoList(List<ContractPayDo> contractPayDoList) {
        this.contractPayDoList = contractPayDoList;
    }

    public List<ContractTypeDo> getContractTypeDoList() {
        return contractTypeDoList;
    }

    public void setContractTypeDoList(List<ContractTypeDo> contractTypeDoList) {
        this.contractTypeDoList = contractTypeDoList;
    }

    @Override
    public String toString() {
        return "ContractDo{" +
                "contractStatus=" + contractStatus +
                ", BG=" + BG +
                ", BU=" + BU +
                ", province=" + province +
                ", region=" + region +
                ", industry=" + industry +
                ", industryChild=" + industryChild +
                ", name='" + name + '\'' +
                ", customer=" + customer +
                ", contractTotalMoney=" + contractTotalMoney +
                ", createTime=" + createTime +
                ", id=" + id +
                ", identifier='" + identifier + '\'' +
                ", projectType=" + projectType +
                ", organization=" + organization +
                ", customerOrgan=" + customerOrgan +
                ", accountManager='" + accountManager + '\'' +
                ", productLine=" + productLine +
                ", protectionTime=" + protectionTime +
                ", currency=" + currency +
                ", isBond=" + isBond +
                ", payType=" + payType +
                ", contractBody='" + contractBody + '\'' +
                ", grossProfitTable='" + grossProfitTable + '\'' +
                ", schedulePricesTable='" + schedulePricesTable + '\'' +
                ", otherInfo='" + otherInfo + '\'' +
                ", contractTypeNum=" + contractTypeNum +
                ", contractTotalTax=" + contractTotalTax +
                ", contractPayDoList=" + contractPayDoList +
                ", contractTypeDoList=" + contractTypeDoList +
                '}';
    }
}
