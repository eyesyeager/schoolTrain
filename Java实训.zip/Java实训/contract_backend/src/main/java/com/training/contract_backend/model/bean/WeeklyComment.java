package com.training.contract_backend.model.bean;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Timestamp;

@Data
@ApiModel(description = "新增评论")
public class WeeklyComment {

    @TableId(type = IdType.AUTO)
    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("周报id")
    private Integer weeklyId;

    @ApiModelProperty("用户id")
    private Integer userId;

    @ApiModelProperty("评论内容")
    private String comment;

    @ApiModelProperty("评论状态")
    private Integer status;

    @ApiModelProperty("创建时间")
    private Timestamp createTime;

    @ApiModelProperty("删除时间")
    private Timestamp deleteTime;

    @ApiModelProperty("修改时间")
    private Timestamp updateTime;
}
