package com.training.contract_backend.model.bean;

import lombok.Data;

@Data
public class WeeklyAttendance {

    private Integer id;

    private Integer weeklyId;

    private Integer weekday;

    private String attendance;
}
