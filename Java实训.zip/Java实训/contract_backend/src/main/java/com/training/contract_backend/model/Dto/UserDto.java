package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ApiModel(description = "用户信息")
public class UserDto {
    @ApiModelProperty("token")
    private String token;

    @ApiModelProperty("用户角色")
    private Integer role;

    @ApiModelProperty("用户名")
    private String name;

    @ApiModelProperty("用户头像")
    private String avatar;
}
