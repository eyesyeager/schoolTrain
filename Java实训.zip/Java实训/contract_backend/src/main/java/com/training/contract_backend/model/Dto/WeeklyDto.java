package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Date;

@Data
@ApiModel(description = "周报详情")
public class WeeklyDto {
    @ApiModelProperty("周报id")
    private Integer id;

    @ApiModelProperty("周报日期")
    private Date date;

    @ApiModelProperty("周报人")
    private String name;

    @ApiModelProperty("签单")
    private String signature;

    @ApiModelProperty("回款")
    private Double money;

    @ApiModelProperty("项目进度")
    private String project;

    @ApiModelProperty("其他内容")
    private String otherContent;
}
