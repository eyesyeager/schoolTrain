package com.training.contract_backend.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.training.contract_backend.mapper.WeeklyAddMapper;
import com.training.contract_backend.mapper.WeeklyMapper;
import com.training.contract_backend.model.Dto.ShowWeeklyDto;
import com.training.contract_backend.model.Dto.WeeklyDto;
import com.training.contract_backend.model.bean.Weekly;
import com.training.contract_backend.module.RoleModule;
import com.training.contract_backend.service.IWeeklyService;
import org.springframework.stereotype.Service;
import java.sql.Date;
import java.util.List;

@Service
public class WeeklyServiceImpl extends ServiceImpl<WeeklyMapper, Weekly> implements IWeeklyService {

    private final WeeklyAddMapper weeklyAddMapper;

    public WeeklyServiceImpl(WeeklyAddMapper weeklyAddMapper) {
        this.weeklyAddMapper = weeklyAddMapper;
    }

    @Override
    public Page<WeeklyDto> selectWeeklys(Integer page, Integer pageSize, Date date, Integer department, String name) {
        Integer role = RoleModule.getRole();
        System.out.println(role);
        Integer userDepartment = RoleModule.getDepartment();
        Integer limitId = RoleModule.getId();
        return (Page<WeeklyDto>) baseMapper.selectByCondition(new Page<>(page,pageSize), date, department, name,role,userDepartment,limitId);
    }

    @Override
    public ShowWeeklyDto weeklycheck(Integer id){
        ShowWeeklyDto weeklycheck = baseMapper.weeklycheck(id);
        weeklycheck.setAttendance(baseMapper.weeklyAttendance(id));
        return weeklycheck;
    }

    @Override
    public void weeklyAdd(Weekly weekly, List<String> attendance){
        System.out.println(weekly);
        System.out.println(attendance);
        weekly.setUserId(RoleModule.getId());
        weeklyAddMapper.WeeklyAdd(weekly);
        for (int i = 1; i <= 7; i++) {
            weeklyAddMapper.addWeekly(weekly.getId(), i, attendance.get(i - 1));
        }
    }


}
