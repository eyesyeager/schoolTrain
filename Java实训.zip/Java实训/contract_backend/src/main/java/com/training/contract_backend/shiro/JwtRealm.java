package com.training.contract_backend.shiro;

import com.auth0.jwt.exceptions.TokenExpiredException;
import com.training.contract_backend.mapper.UserMapper;
import com.training.contract_backend.model.bean.UserBean;
import com.training.contract_backend.utils.JwtUtils;
import com.training.contract_backend.utils.SpringContextUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import java.util.Set;

public class JwtRealm extends AuthorizingRealm {

    /**
     * 限定这个 Realm 只处理我们自定义的 JwtToken
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof JwtToken;
    }

    /**
     * token校验走该逻辑
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
        JwtToken jwtToken = (JwtToken) authcToken;
        if (jwtToken.getPrincipal() == null) {
            throw new AccountException("JWT token参数异常！");
        }
        // 从 JwtToken 中获取当前用户
        String username = jwtToken.getPrincipal().toString();
        // 查询数据库获取用户信息，此处使用 Map 来模拟数据库
        UserMapper userMapper = SpringContextUtils.getBean(UserMapper.class);
        UserBean user = userMapper.getUserBean(Integer.valueOf(username));
        // 用户不存在
        if (user == null) throw new UnknownAccountException("用户不存在！");
        // 用户被锁定
        if (user.getStatus() == 0) throw new LockedAccountException("该用户已被锁定,暂时无法登录！");
        return new SimpleAuthenticationInfo(username, user.getPassword(), getName());
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        // 获取当前用户
        String currentUser = (String)SecurityUtils.getSubject().getPrincipal();
        // 查询数据库，获取用户的角色信息
        UserMapper userMapper = SpringContextUtils.getBean(UserMapper.class);
        Set<String> roles = userMapper.getUserRoles(Integer.valueOf(currentUser));
        // 查询数据库，获取用户的权限信息
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.setRoles(roles);
        return info;
    }
}