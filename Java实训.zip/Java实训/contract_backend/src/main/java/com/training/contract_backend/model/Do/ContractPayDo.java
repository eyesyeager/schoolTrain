package com.training.contract_backend.model.Do;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("合同支付实体类")
public class ContractPayDo {

    // 合同编号
    @ApiModelProperty("合同编号")
    private int contractId;
    // 支付类型
    @ApiModelProperty("支付类型")
    private int timeNode;
    // 支付额
    @ApiModelProperty("支付额")
    private double payMoney;
    // 占合同额
    @ApiModelProperty("占合同额")
    private double payRate;
    // 支付结点
    @ApiModelProperty("支付结点")
    private double payNode;
    // 付款条件
    @ApiModelProperty("付款条件")
    private String payCondition;

    public int getContractId() {
        return contractId;
    }

    public void setContractId(int contractId) {
        this.contractId = contractId;
    }

    public int getTimeNode() {
        return timeNode;
    }

    public void setTimeNode(int timeNode) {
        this.timeNode = timeNode;
    }

    public double getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(double payMoney) {
        this.payMoney = payMoney;
    }

    public double getPayRate() {
        return payRate;
    }

    public void setPayRate(double payRate) {
        this.payRate = payRate;
    }

    public double getPayNode() {
        return payNode;
    }

    public void setPayNode(double payNode) {
        this.payNode = payNode;
    }

    public String getPayCondition() {
        return payCondition;
    }

    public void setPayCondition(String payCondition) {
        this.payCondition = payCondition;
    }

    @Override
    public String toString() {
        return "ContractPayDo{" +
                "contractId=" + contractId +
                ", timeNode=" + timeNode +
                ", payMoney=" + payMoney +
                ", payRate=" + payRate +
                ", payNode=" + payNode +
                ", payCondition='" + payCondition + '\'' +
                '}';
    }
}

