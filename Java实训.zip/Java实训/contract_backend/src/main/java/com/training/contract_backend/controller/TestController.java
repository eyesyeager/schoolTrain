package com.training.contract_backend.controller;

import com.training.contract_backend.module.RoleModule;
import com.training.contract_backend.result.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("test")
@Api(tags = "测试模块")
public class TestController {

    @ApiOperation("测试操作")
    @RequestMapping("/test1")
    @RequiresRoles(value = { "admin" })
    public Result<Void> test1() {
        System.out.println(RoleModule.getId());
        System.out.println(RoleModule.getRole());
        System.out.println(RoleModule.getDepartment());
        System.out.println(RoleModule.getName());
        return Result.success();
    }
}
