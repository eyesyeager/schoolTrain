package com.training.contract_backend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.training.contract_backend.model.Dto.WeeklyCommentDto;
import com.training.contract_backend.model.bean.WeeklyComment;

import java.util.List;

public interface IWeeklyCommentService extends IService<WeeklyComment> {
    List<WeeklyCommentDto> weeklyCommentCheck(Integer id);

}
