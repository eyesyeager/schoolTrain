package com.training.contract_backend.exception;

import com.training.contract_backend.result.ResultCode;

/**
 * 自定义异常类
 */
public class CustomException extends Exception {

    protected Integer errorCode;

    protected String errorMsg;

    public CustomException() {
        this.errorCode = ResultCode.FAILURE.getCode();
        this.errorMsg = ResultCode.FAILURE.getMessage();
    }

    public CustomException(ResultCode resultCode) {
        this.errorCode = resultCode.getCode();
        this.errorMsg = resultCode.getMessage();
    }

    public CustomException(Integer errorCode) {
        this.errorCode = errorCode;
        this.errorMsg = ResultCode.FAILURE.getMessage();
    }

    public CustomException(String errorMsg) {
        this.errorCode = ResultCode.FAILURE.getCode();
        this.errorMsg = errorMsg;
    }

    public CustomException(Integer errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    @Override
    public String toString() {
        return "CustomException{" +
                "errorCode=" + errorCode +
                ", errorMsg='" + errorMsg + '\'' +
                '}';
    }
}