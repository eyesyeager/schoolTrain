package com.training.contract_backend.service;

import com.training.contract_backend.exception.CustomException;
import com.training.contract_backend.model.Dto.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import java.lang.reflect.InvocationTargetException;

public interface UserService {
    /**
     * 返回图形验证码
     * @return VeriCodeDto
     * @param id
     */
    VeriCodeDto getVeriCode(Integer id) throws Exception;

    /**
     * 发送邮箱验证码
     * @param emailVeriCodeDto
     * @return VerCodeDto
     * @throws Exception
     */
    EmailResponseDto getEmailVeriCode(EmailVeriCodeDto emailVeriCodeDto) throws Exception;

    /**
     * 文件上传
     * @param multipartFile
     * @return
     */
    FileDto upload(MultipartFile multipartFile) throws CustomException;

    /**
     * 登录操作
     * @param loginDto
     * @return
     * @throws Exception
     */
    UserDto doLogin(LoginDto loginDto) throws Exception;

    /**
     * 修改密码
     * @param loginEmailDto
     * @return
     */
    void updatePsd(LoginEmailDto loginEmailDto) throws Exception;

    /**
     * 首次登录，绑定邮箱并修改密码
     * @param loginEmailDto
     */
    void firstLogin(LoginEmailDto loginEmailDto) throws Exception;

    /**
     * 用户注册
     * @param userAddDto
     * @return
     */
    UserInitDto register(UserAddDto userAddDto) throws CustomException, InvocationTargetException, IllegalAccessException;

    /**
     * 获取用户信息
     * @param id
     * @return
     */
    UserInfoDto getUserInfo(Integer id);

    /**
     * 修改用户信息
     * @param userInfoDto
     * @return
     */
    void updateUserInfo(UserInfoDto userInfoDto);
}
