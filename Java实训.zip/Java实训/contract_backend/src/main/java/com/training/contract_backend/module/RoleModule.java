package com.training.contract_backend.module;

public class RoleModule {
    private static Integer id;

    private static String name;

    private static Integer department;

    private static Integer role;

    public synchronized static Integer getId() {
        return id;
    }

    public synchronized static void setId(Integer id) {
        RoleModule.id = id;
    }

    public synchronized static String getName() {
        return name;
    }

    public synchronized static void setName(String name) {
        RoleModule.name = name;
    }

    public synchronized static Integer getDepartment() {
        return department;
    }

    public synchronized static void setDepartment(Integer department) {
        RoleModule.department = department;
    }

    public synchronized static Integer getRole() {
        return role;
    }

    public synchronized static void setRole(Integer role) {
        RoleModule.role = role;
    }
}
