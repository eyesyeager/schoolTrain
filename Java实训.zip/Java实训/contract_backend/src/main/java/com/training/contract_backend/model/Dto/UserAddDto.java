package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("新增用户提交信息")
public class UserAddDto {
    @ApiModelProperty(value = "添加成功后的返回id", hidden = true)
    private Integer id;

    @ApiModelProperty("用户姓名")
    private String name;

    @ApiModelProperty("用户部门")
    private Integer department;

    @ApiModelProperty("用户身份")
    private Integer role;
}
