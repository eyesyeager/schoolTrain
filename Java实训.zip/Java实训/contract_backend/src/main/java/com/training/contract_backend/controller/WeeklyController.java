package com.training.contract_backend.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.training.contract_backend.model.Dto.ShowWeeklyDto;
import com.training.contract_backend.model.Dto.WeeklyAddDto;
import com.training.contract_backend.model.Dto.WeeklyDto;
import com.training.contract_backend.model.bean.Weekly;
import com.training.contract_backend.result.Result;
import com.training.contract_backend.service.IWeeklyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/weekly")
@Api("周报模块")
public class WeeklyController {

    @Autowired
    private IWeeklyService weeklyService;

    @PostMapping ("/getWeeklys")
    public Result<Map<String, Object>> getWeeklys(@RequestBody Map<String, Object> map) throws ParseException {
        if(!map.containsKey("date")) map.put("date", null);
        if(map.get("date") == "") map.put("date", null);
        else if(map.get("date") != null) map.put("date", new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse((String) map.get("date")).getTime()));
        if(!map.containsKey("department")) map.put("department", null);
        if(!map.containsKey("name")) map.put("name", null);
        System.out.println(map);

        Page<WeeklyDto> content = weeklyService.selectWeeklys(
                (Integer) map.get("page"),
                (Integer) map.get("pageSize"),
                (Date) map.get("date"),
                (Integer) map.get("department"),
                (String) map.get("name")
        );
        Map<String,Object> resultMap = new HashMap<>();
        resultMap.put("totalNum",content.getTotal());
        resultMap.put("content",content.getRecords());
        return  Result.success(resultMap);
    }

    @PostMapping("/getWeekly")
    @ApiOperation("获取周报详情")
    public Result<ShowWeeklyDto> getWeekly(@RequestBody Map<String, Integer> map){
        return Result.success(weeklyService.weeklycheck(map.get("id")));
    }

    @PostMapping("/addWeekly")
    @ApiOperation("新增周报")
    public Result<Void> addWeekly(
            @RequestBody WeeklyAddDto weeklyAddDto
            ){
        System.out.println(weeklyAddDto);
        weeklyService.weeklyAdd(weeklyAddDto.getWeekly(), weeklyAddDto.getAttendance());
        return Result.success();
    }
}
