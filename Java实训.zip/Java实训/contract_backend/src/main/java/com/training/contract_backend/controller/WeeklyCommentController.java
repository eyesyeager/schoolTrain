package com.training.contract_backend.controller;

import com.training.contract_backend.model.Dto.WeeklyCommentDto;
import com.training.contract_backend.model.bean.WeeklyComment;
import com.training.contract_backend.result.Result;
import com.training.contract_backend.service.IWeeklyCommentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("WeeklyComment")
@Api(tags = "历史评论模块")
public class WeeklyCommentController {

    @Autowired
    private IWeeklyCommentService weeklyCommentService;


    @PostMapping("/getWeeklyComments")
    @ApiOperation("获取历史评论详情")
    public Result<List<WeeklyCommentDto>> getWeeklyComment(@RequestBody Map<String, Integer> map) {
        return Result.success(weeklyCommentService.weeklyCommentCheck(map.get("id")));
    }


    @PostMapping("/addWeeklyComment")
    @ApiOperation("新增评论")
    public Result<Void> addWeeklyComment(
            @RequestBody WeeklyComment weeklyComment
    ) {
        weeklyComment.setId(null);
        weeklyComment.setStatus(0);
        weeklyComment.setDeleteTime(null);
        weeklyComment.setUpdateTime(null);
        Timestamp now = new Timestamp(System.currentTimeMillis());
        weeklyComment.setCreateTime(now);
        weeklyCommentService.save(weeklyComment);
        return Result.success();
    }



}
