package com.training.contract_backend.model.Do;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("客户实体类")
public class CustomerDo {

    // 客户名称
    @ApiModelProperty("客户名称")
    private String name;
    // 客户级别
    @ApiModelProperty("客户级别")
    private int level;
    // 行业
    @ApiModelProperty("行业")
    private int industry;
    // 邮政编码
    @ApiModelProperty("邮政编码")
    private String postalCode;
    // 所在省
    @ApiModelProperty("所在省")
    private int province;
    // 所在市
    @ApiModelProperty("所在市")
    private int city;
    // 所在县
    @ApiModelProperty("所在县")
    private int county;
    // 地址
    @ApiModelProperty("地址")
    private String address;
    // 单位
    @ApiModelProperty("单位")
    private String invoiceOrganization;
    // 税号
    @ApiModelProperty("税号")
    private String invoiceTaxNumber;
    // 电话
    @ApiModelProperty("电话")
    private String invoicePhone;
    // 发票地址
    @ApiModelProperty("发票地址")
    private String invoiceAddress;
    // 开户行
    @ApiModelProperty("开户行")
    private String invoiceBank;
    // 账号
    @ApiModelProperty("账号")
    private String invoiceAccount;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getIndustry() {
        return industry;
    }

    public void setIndustry(int industry) {
        this.industry = industry;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public int getProvince() {
        return province;
    }

    public void setProvince(int province) {
        this.province = province;
    }

    public int getCity() {
        return city;
    }

    public void setCity(int city) {
        this.city = city;
    }

    public int getCounty() {
        return county;
    }

    public void setCounty(int county) {
        this.county = county;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInvoiceOrganization() {
        return invoiceOrganization;
    }

    public void setInvoiceOrganization(String invoiceOrganization) {
        this.invoiceOrganization = invoiceOrganization;
    }

    public String getInvoiceTaxNumber() {
        return invoiceTaxNumber;
    }

    public void setInvoiceTaxNumber(String invoiceTaxNumber) {
        this.invoiceTaxNumber = invoiceTaxNumber;
    }

    public String getInvoicePhone() {
        return invoicePhone;
    }

    public void setInvoicePhone(String invoicePhone) {
        this.invoicePhone = invoicePhone;
    }

    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    public String getInvoiceBank() {
        return invoiceBank;
    }

    public void setInvoiceBank(String invoiceBank) {
        this.invoiceBank = invoiceBank;
    }

    public String getInvoiceAccount() {
        return invoiceAccount;
    }

    public void setInvoiceAccount(String invoiceAccount) {
        this.invoiceAccount = invoiceAccount;
    }

    @Override
    public String toString() {
        return "CustomerDo{" +
                "name='" + name + '\'' +
                ", level=" + level +
                ", industry=" + industry +
                ", postalCode='" + postalCode + '\'' +
                ", province=" + province +
                ", city=" + city +
                ", county=" + county +
                ", address='" + address + '\'' +
                ", invoiceOrganization='" + invoiceOrganization + '\'' +
                ", invoiceTaxNumber='" + invoiceTaxNumber + '\'' +
                ", invoicePhone='" + invoicePhone + '\'' +
                ", invoiceAddress='" + invoiceAddress + '\'' +
                ", invoiceBank='" + invoiceBank + '\'' +
                ", invoiceAccount='" + invoiceAccount + '\'' +
                '}';
    }
}
