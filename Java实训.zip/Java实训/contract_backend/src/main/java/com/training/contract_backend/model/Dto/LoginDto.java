package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "登录")
public class LoginDto {
    @ApiModelProperty(value = "账号", example = "0")
    private Integer id;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("key")
    private String key;

    @ApiModelProperty("验证码")
    private String code;
}