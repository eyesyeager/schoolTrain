package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ApiModel(description = "文件")
public class FileDto {
    @ApiModelProperty("文件链接")
    private String url;
}
