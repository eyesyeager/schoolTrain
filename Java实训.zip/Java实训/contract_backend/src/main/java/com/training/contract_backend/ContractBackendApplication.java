package com.training.contract_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContractBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContractBackendApplication.class, args);
    }

}
