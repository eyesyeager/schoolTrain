package com.training.contract_backend.exception;

import com.auth0.jwt.exceptions.TokenExpiredException;
import com.training.contract_backend.result.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

/**
 * 全局异常处理类
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 自定义异常
     * @param e CustomException
     * @return Result<Void>
     */
    @ExceptionHandler(value = CustomException.class)
    @ResponseBody
    public Result<Void> error(CustomException e, HttpServletRequest request) {
        logger.warn("请求地址：{}，出现异常：{}", request.getRequestURL(), e.toString());
        return Result.failure(e.getErrorCode(), e.getErrorMsg());
    }

    /**
     * 未知异常
     * @param e Exception
     * @return Result<Void>
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Result<Void> error(Exception e, HttpServletRequest request) {
        logger.error("请求地址：{},出现异常：{}", request.getRequestURL(), e.toString());
        return Result.failure(e.getMessage());
    }

    @ExceptionHandler(value = TokenExpiredException.class)
    @ResponseBody
    public Result<Void> error(TokenExpiredException e, HttpServletRequest request) {
        logger.error("请求地址：{},出现异常：{}", request.getRequestURL(), e.toString());
        return Result.failure(444, "权限错误！");
    }
}