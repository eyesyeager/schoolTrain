package com.training.contract_backend.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.training.contract_backend.model.Dto.ShowWeeklyDto;
import com.training.contract_backend.model.Dto.WeeklyAddDto;
import com.training.contract_backend.model.Dto.WeeklyDto;
import com.training.contract_backend.model.bean.Weekly;
import java.sql.Date;
import java.util.List;

public interface IWeeklyService extends IService<Weekly> {
    ShowWeeklyDto weeklycheck(Integer id);

    Page<WeeklyDto> selectWeeklys(Integer page, Integer pageSize, Date date, Integer department, String name);

    void weeklyAdd(Weekly weekly, List<String> attendance);

}
