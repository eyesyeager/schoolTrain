package com.training.contract_backend.model.Po;

import lombok.Data;

@Data
public class UserPartInfoDo {
    private String name;

    private String avatar;

    private Integer role;
}
