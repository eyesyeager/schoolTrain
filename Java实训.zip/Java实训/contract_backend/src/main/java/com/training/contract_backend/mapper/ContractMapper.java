package com.training.contract_backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.training.contract_backend.model.Do.ContractDo;
import com.training.contract_backend.model.Do.ContractPayDo;
import com.training.contract_backend.model.Do.CustomerDo;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ContractMapper extends BaseMapper {

//    // 专题分析 根据签单状态和条件查询结果
//    public List<ContractDo> findByCondition(ContractDo contractDo);

    // 专题分析 根据签单状态和条件查询结果 分页查询 权限管理
    public Page<ContractDo> findByCondition(@Param("page") Page<ContractDo> page,
                                            @Param("contractDo") ContractDo contractDo,
                                            @Param("role") int role,
                                            @Param("limitDepartment") int limitDepartment);

//    // 合同首页 根据时间查询结果
//    public List<ContractDo> findByTime(@Param("time") int time,@Param("status") int status);

    // 合同首页 根据时间查询结果 分页查询 权限管理
    public Page<ContractDo> findByTime(@Param("page") Page<ContractDo> page,
                                       @Param("time") int time,
                                       @Param("status") int status,
                                       @Param("role") int role,
                                       @Param("limitUser") int limitUser,
                                       @Param("limitDepartment") int limitDepartment);

    // 合同首页 预览合同
    public ContractDo previewContract(String name);

    // 合同首页 付款节点
    public List<ContractPayDo> findContractPay(String name);

//    // 合同看板 搜索合同
//    public List<ContractDo> findByName(@Param("name")String name,@Param("status") int status);

    // 合同看板 搜索合同 分页查询 权限管理
    public Page<ContractDo> findByName(@Param("page") Page<ContractDo> page,
                                       @Param("name") String name,
                                       @Param("status") int status,
                                       @Param("role") int role,
                                       @Param("limitUser") int limitUser,
                                       @Param("limitDepartment") int limitDepartment);

    // 合同看板 关闭合同
    public void closeContract(String name);

    // 合同看板 进入合同
    public ContractDo enterContract(String name);

    // 增加合同 权限管理
    public ContractDo judgeContract(ContractDo contractDo);
    public void saveContract(@Param("contractDo") ContractDo contractDo,
                             @Param("limitUser") int limitUser,
                             @Param("limitDepartment") int limitDepartment);
    public void saveContractInfo(ContractDo contractDo);

    // 新增客户
    public CustomerDo judgeCustomer(CustomerDo customerDo);
    public void saveCustomer(CustomerDo customerDo);

    // 所有客户
    public List<CustomerDo> findCustomer();

}
