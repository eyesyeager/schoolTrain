package com.training.contract_backend.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserBean {
    private Integer id;

    private String password;

    private String email;

    private Integer role;

    private Integer status;
}
