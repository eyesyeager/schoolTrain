package com.training.contract_backend.model.Po;

import lombok.Data;

@Data
public class UserRolePo {
    private Integer id;

    private String name;

    private Integer department;

    private Integer role;
}
