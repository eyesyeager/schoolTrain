package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Date;
import java.util.List;

@Data
@ApiModel(description = "周报详情")
public class ShowWeeklyDto {
    @ApiModelProperty("周报日期")
    private Date date;

    @ApiModelProperty("汇报人")
    private String name;

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("签单")
    private String signature;

    @ApiModelProperty("回款")
    private Double money;

    @ApiModelProperty("项目进度")
    private String project;

    @ApiModelProperty("其他项目说明")
    private String otherContent;

    @ApiModelProperty("下周工作计划")
    private String nextWeekWork;

    @ApiModelProperty("问题与思考")
    private String problemAndThink;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("出勤地点")
    private List<String> attendance;
}
