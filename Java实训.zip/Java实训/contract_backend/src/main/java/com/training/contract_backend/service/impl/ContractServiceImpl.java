package com.training.contract_backend.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.training.contract_backend.model.Do.ContractDo;
import com.training.contract_backend.model.Do.ContractPayDo;
import com.training.contract_backend.model.Do.CustomerDo;
import com.training.contract_backend.mapper.ContractMapper;
import com.training.contract_backend.module.RoleModule;
import com.training.contract_backend.service.ContractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("contractService")
public class ContractServiceImpl implements ContractService {

    @Autowired
    private ContractMapper contractMapper;

//    // 专题分析 根据签单状态和条件查询结果
//    public List<ContractDo> findByCondition(ContractDo contractDo) {
//        List<ContractDo> contractDoList = contractMapper.findByCondition(contractDo);
//        return contractDoList;
//    }

    // 专题分析 根据签单状态和条件查询结果 分页查询 权限管理
    public Page<ContractDo> findByCondition(Page<ContractDo> page,ContractDo contractDo) {
        Integer role = RoleModule.getRole();
        Integer department = RoleModule.getDepartment();
        Page<ContractDo> contractDoPage = contractMapper.findByCondition(page,contractDo,role,department);
        return contractDoPage;
    }

//    // 合同首页 根据时间查询结果
//    public List<ContractDo> findByTime(int time, int status) {
//        List<ContractDo> contractDoList = contractMapper.findByTime(time,status);
//        return contractDoList;
//    }

    // 合同首页 根据时间查询结果 分页查询 权限管理
    public Page<ContractDo> findByTime(Page<ContractDo> page,int time, int status) {
        Integer role = RoleModule.getRole();
        System.out.println(role);
        Integer department = RoleModule.getDepartment();
        Integer id = RoleModule.getId();
        Page<ContractDo> contractDoPage = contractMapper.findByTime(page,time,status,role,id,department);
        return contractDoPage;
    }

    // 合同首页 预览合同
    public ContractDo previewContract(String name) {
        ContractDo contractDo = contractMapper.previewContract(name);
        return contractDo;
    }

    // 合同首页 付款节点
    public List<ContractPayDo> findContractPay(String name) {
        List<ContractPayDo> contractPayDoList = contractMapper.findContractPay(name);
        return contractPayDoList;
    }

//    // 合同看板 搜索合同
//    public List<ContractDo> findByName(String name,int status) {
//        List<ContractDo> contractDoList = contractMapper.findByName(name,status);
//        return contractDoList;
//    }

    // 合同看板 搜索合同 分页查询 权限管理
    public Page<ContractDo> findByName(Page<ContractDo> page,String name,int status) {
        Integer role = RoleModule.getRole();
        Integer department = RoleModule.getDepartment();
        Integer id = RoleModule.getId();
        Page<ContractDo> contractDoPage = contractMapper.findByName(page,name,status,role,id,department);
        return contractDoPage;
    }

    // 合同看板 关闭合同
    public void closeContract(String name) {
        contractMapper.closeContract(name);
    }

    // 合同看板 进入合同
    public ContractDo enterContract(String name) {
        ContractDo contractDo = contractMapper.enterContract(name);
        return contractDo;
    }

    // 增加合同 权限管理
    public ContractDo judgeContract(ContractDo contractDo) {
        return contractMapper.judgeContract(contractDo);
    }
    public void saveContract(ContractDo contractDo){
        Integer department = RoleModule.getDepartment();
        Integer id = RoleModule.getId();
        contractMapper.saveContract(contractDo,id,department);
        contractMapper.saveContractInfo(contractDo);
    }

    // 新增客户
    public CustomerDo judgeCustomer(CustomerDo customerDo) {
        return contractMapper.judgeCustomer(customerDo);
    }
    public void saveCustomer(CustomerDo customerDo){
        contractMapper.saveCustomer(customerDo);
    }

    // 所有客户
    public List<CustomerDo> findCustomer() {
        List<CustomerDo> customerDoList = contractMapper.findCustomer();
        return customerDoList;
    }

}
