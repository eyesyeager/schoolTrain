package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "新增用户返回")
public class UserInitDto {
    @ApiModelProperty("用户id")
    private Integer id;

    @ApiModelProperty("用户姓名")
    private String name;

    @ApiModelProperty("用户部门")
    private Integer department;

    @ApiModelProperty("用户身份")
    private Integer role;
}
