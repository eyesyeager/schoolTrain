package com.training.contract_backend.advice;

import com.alibaba.fastjson.JSON;
import com.training.contract_backend.utils.BrowserUtils;
import com.training.contract_backend.utils.IpUtils;
import com.training.contract_backend.utils.OSUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Arrays;

@Aspect
@Component
@Order
public class WebLogAdvice {

    private final Logger logger = LoggerFactory.getLogger(WebLogAdvice.class);

    private final HttpServletRequest httpServletRequest;

    public WebLogAdvice(HttpServletRequest httpServletRequest) {
        this.httpServletRequest = httpServletRequest;
    }

    @Pointcut(value = "execution (* com.training.contract_backend.controller..*.*(..))")
    public void controllerPointCut() {
    }

    /**
     * 打印日志,包括请求参数、返回结果、所耗时间
     * @param pjp ProceedingJoinPoint
     * @return Object
     */
    @Around(value = "controllerPointCut()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();
        logger.info("Ip: " + IpUtils.getIpAddr(httpServletRequest) + "OS: " + OSUtils.osName(httpServletRequest) + " hostName: " + IpUtils.getHostName() + " browserName：" + BrowserUtils.browserName(httpServletRequest) + " method:" + method.getDeclaringClass() + "." + method.getName());

        Object[] args = pjp.getArgs();
        logger.info("paras: " + Arrays.toString(args));

        long start = System.currentTimeMillis();
        Object result = pjp.proceed();
        long timeConsuming = System.currentTimeMillis() - start;
        logger.info("result: {} \n耗时: {}ms", JSON.toJSON(result), timeConsuming);

        return result;
    }

    @AfterThrowing(value = "controllerPointCut()", throwing = "error")
    public void afterThrowingAdvice(JoinPoint jp, Exception error) {
        logger.error("Method Signature: " + jp.getSignature());
        logger.error("Exception: " + error);
    }
}
