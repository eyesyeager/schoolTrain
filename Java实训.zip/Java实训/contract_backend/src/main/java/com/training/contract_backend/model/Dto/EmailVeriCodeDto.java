package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ApiModel(description = "邮件验证码参数")
public class EmailVeriCodeDto {
    @ApiModelProperty(value = "账号", example="0")
    private Integer id;

    @ApiModelProperty("邮箱")
    private String email;
}
