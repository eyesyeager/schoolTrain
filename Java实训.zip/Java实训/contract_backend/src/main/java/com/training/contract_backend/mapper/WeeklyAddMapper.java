package com.training.contract_backend.mapper;

import com.training.contract_backend.model.bean.Weekly;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WeeklyAddMapper {
    void WeeklyAdd(Weekly weekly);

    @Insert("insert into weekly_attendance (weekly_id, weekday, attendance) values (#{id}, #{weekday}, #{item})")
    void addWeekly(Integer id, Integer weekday, String item);
}
