package com.training.contract_backend.result;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 状态码类
 */
@Getter
@AllArgsConstructor
public enum ResultCode {
    // 默认成功提示
    SUCCESS(200, "success"),

    // 默认失败提示
    FAILURE(400, "fail"),

    /*
     * 非运行时异常（1000 - 1999）
     */

    PROGRAM_INSIDE_EXCEPTION(1000, "程序内部异常"),

    PERMISSION_EXPIRED(1001, "身份过期"),

    /*
     * 运行时异常——操作异常（2000 - 5999）
     */

    ILLEGAL_REQUEST_PARAMETER(2000, "非法请求参数"),

    ILLEGAL_AUTHENTICATION(2001, "身份认证失败"),


    /*
     * 运行时异常——风险异常（6000 - 9999）
     */

    ILLEGAL_REQUEST_ROUTE(6000, "非法路由请求"),

    AUTHORITY_AUTHENTICATION_FAILED(6001, "权限认证失败！");

    private final Integer code;

    private final String message;
}