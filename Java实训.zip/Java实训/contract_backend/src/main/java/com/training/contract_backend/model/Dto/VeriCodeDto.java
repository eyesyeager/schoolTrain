package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@ApiModel(description = "获取图形验证码")
public class VeriCodeDto {
    @ApiModelProperty("加密验证码")
    private String code;

    @ApiModelProperty("base64编码验证图片")
    private String img;
}
