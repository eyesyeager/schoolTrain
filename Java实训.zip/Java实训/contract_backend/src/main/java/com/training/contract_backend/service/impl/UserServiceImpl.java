package com.training.contract_backend.service.impl;

import com.training.contract_backend.exception.CustomException;
import com.training.contract_backend.mapper.UserMapper;
import com.training.contract_backend.model.Dto.*;
import com.training.contract_backend.module.RoleModule;
import com.training.contract_backend.service.UserService;
import com.training.contract_backend.utils.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    private final EmailUtils emailUtils;

    private final UserMapper userMapper;

    private final String fileBaseUrl = "http://remz9wszw.hn-bkt.clouddn.com/";

    private final Map<Integer, String> roleMap = new HashMap<>();

    public UserServiceImpl(EmailUtils emailUtils, UserMapper userMapper) {
        this.emailUtils = emailUtils;
        this.userMapper = userMapper;
        roleMap.put(0, "admin");
        roleMap.put(1, "manager");
        roleMap.put(2, "user");
    }

    @Override
    public VeriCodeDto getVeriCode(Integer id) throws Exception {
        Map<String, String> strMap;
        do { strMap = encryptStr(Integer.toString(id)); }
        while (
                strMap.get("encryptedStr").indexOf("contract") != strMap.get("encryptedStr").lastIndexOf("contract")
        );

        return new VeriCodeDto(
                strMap.get("encryptedStr")
                        + "contract"
                        + EncryptionUtils.symmetricEncrypt(String.valueOf(System.currentTimeMillis() / 1000)),
                Base64ImgUtils.getBase64Img(strMap.get("code"))
        );
    }

    @Override
    public EmailResponseDto getEmailVeriCode(EmailVeriCodeDto emailVeriCodeDto) throws Exception {
        // 生成验证码
        Map<String, String> strMap;
        do { strMap = encryptStr(Integer.toString(emailVeriCodeDto.getId())); } while (
                strMap.get("encryptedStr").indexOf("contract") != strMap.get("encryptedStr").lastIndexOf("contract")
        );

        // 发送邮件
        emailUtils.sendHtmlMail(emailVeriCodeDto.getEmail(), "合同管理系统邮箱验证码", EmailUtils.veriCodeTemplate(strMap.get("code")));

        return new EmailResponseDto(
                strMap.get("encryptedStr") +
                "contract" +
                EncryptionUtils.symmetricEncrypt(String.valueOf(System.currentTimeMillis() / 1000))
        );
    }

    @Override
    public FileDto upload(MultipartFile multipartFile) throws CustomException {
        try{
            String originalFilename = multipartFile.getOriginalFilename();
            assert originalFilename != null;
            int lastIndexOf = originalFilename.lastIndexOf(".");
            String suffix = originalFilename.substring(lastIndexOf - 1);
            //使用UUID随机产生文件名称，防止同名文件覆盖
            String fileName = UUID.randomUUID() + suffix;
            QiniuUtils.upload2Qiniu(multipartFile.getBytes(), fileName);
            return new FileDto(fileBaseUrl + fileName);
        } catch (Exception e){
            throw new CustomException("文件上传失败");
        }
    }

    @Override
    public UserDto doLogin(LoginDto loginDto) throws Exception {
        // 检查验证
        isValidVeriCode(loginDto);

        // 验证密码
        loginDto.setPassword(EncryptionUtils.decrypt(loginDto.getPassword()));
        String enteredPsd = EncryptionUtils.oneWayHash(loginDto.getPassword(), loginDto.getPassword());
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(Integer.toString(loginDto.getId()), enteredPsd);
        try {
            subject.login(token);
            if (EncryptionUtils.oneWayHash("123456", "123456").equals(enteredPsd)) {
                throw new Exception("首次登录，需修改邮箱");
            }

            // 签发token
            String jwtToken = JwtUtils.sign(Integer.toString(loginDto.getId()), JwtUtils.SECRET);
            return new UserDto(
                    jwtToken,
                    userMapper.getNameAndAvatarById(loginDto.getId()).getRole(),
                    userMapper.getNameAndAvatarById(loginDto.getId()).getName(),
                    userMapper.getNameAndAvatarById(loginDto.getId()).getAvatar()
            );
        } catch (UnknownAccountException | IncorrectCredentialsException uae) { // 账号不存在或账号被封
            throw new CustomException("用户名与密码不匹配，请检查后重新输入！");
        } catch (AuthenticationException ae) {
            ae.printStackTrace();
            throw new CustomException("登录异常，请联系管理员！");
        }
    }

    @Override
    public void updatePsd(LoginEmailDto loginEmailDto) throws Exception {
        // 检查邮箱与用户是否对应
        if(!userMapper.getEmailById(loginEmailDto.getId()).equals(loginEmailDto.getEmail())) {
            throw new Exception("邮箱有误！");
        };
        // 检查验证
        LoginDto loginDto = new LoginDto();
        BeanUtils.copyProperties(loginDto, loginEmailDto);
        isValidVeriCode(loginDto);
        // 修改密码
        loginEmailDto.setPassword(EncryptionUtils.decrypt(loginEmailDto.getPassword()));
        String psd = EncryptionUtils.oneWayHash(loginEmailDto.getPassword(), loginEmailDto.getPassword());
        if (userMapper.updatePsd(loginEmailDto.getId(), psd) != 1) {
            throw new Exception("修改失败！");
        }
    }

    @Override
    public void firstLogin(LoginEmailDto loginEmailDto) throws Exception {
        // 检查验证
        LoginDto loginDto = new LoginDto();
        BeanUtils.copyProperties(loginDto, loginEmailDto);
        isValidVeriCode(loginDto);

        // 查看邮箱是否已注册
        if(userMapper.isExistEmail(loginEmailDto.getEmail()) != null) {
            throw new Exception("邮箱已注册");
        }

        // 绑定邮箱并修改密码
        loginEmailDto.setPassword(EncryptionUtils.decrypt(loginEmailDto.getPassword()));
        String enteredPsd = EncryptionUtils.oneWayHash(loginEmailDto.getPassword(), loginEmailDto.getPassword());
        loginEmailDto.setPassword(enteredPsd);
        if(userMapper.firstLogin(loginEmailDto) != 1) {
            throw new Exception("操作失败!请联系管理员！");
        }
    }

    @Override
    public UserInitDto register(UserAddDto userAddDto) throws CustomException, InvocationTargetException, IllegalAccessException {
        // 权限校验
        if(RoleModule.getId() == 1) {
            if(userAddDto.getRole() == 1) {
                throw new CustomException("权限不足！");
            } else if (!userAddDto.getDepartment().equals(RoleModule.getDepartment())) {
                throw new CustomException("权限不足！无法创建其他部门员工");
            }
        }
        if(userAddDto.getRole() == 0) {
            throw new CustomException("不允许创建超级用户！");
        }

        // 注册用户
        userMapper.register(userAddDto);

        // 添加用户角色
        for (int i = 2; i >= userAddDto.getRole(); i--) {
            userMapper.addRole(userAddDto.getId(), roleMap.get(i));
        }

        // 构建返回信息
        UserInitDto userInitDto = new UserInitDto();
        BeanUtils.copyProperties(userInitDto, userAddDto);
        return userInitDto;
    }

    @Override
    public UserInfoDto getUserInfo(Integer id) {
        return userMapper.getUserInfo(id);
    }

    @Override
    public void updateUserInfo(UserInfoDto userInfoDto) {
        userMapper.updateUserInfo(userInfoDto);
    }

    /**
     * 检查是否是有效验证码
     *
     * @param loginDto LoginDto
     * @return
     */
    private void isValidVeriCode(LoginDto loginDto) throws Exception {
        if (!loginDto.getKey().contains("contract")) throw new Exception("key值不规范");
        isVeriCodeExpired(loginDto.getKey().split("contract")[1]);
        isRightCode(Integer.toString(loginDto.getId()), loginDto.getCode(), loginDto.getKey().split("contract")[0]);
    }

    /**
     * 检查验证码是否过期
     *
     * @param str
     * @return
     */
    private void isVeriCodeExpired(String str) throws Exception {
        Long nowTime = System.currentTimeMillis() / 1000;
        Long emitTime = Integer.valueOf(EncryptionUtils.symmetricDecrypt(str)).longValue();
        if(nowTime - emitTime > 5 * 60) throw new Exception("验证码失效");
    }

    /**
     * 判断验证码是否错误
     *
     * @return
     */
    public void isRightCode(String identity, String code, String encryptedStr) throws Exception {
        if (!encryptedStr.equals(EncryptionUtils.oneWayHash(identity, code))) throw new Exception("验证码错误");
    }

    /**
     * 生成密码字符密文和salt密文
     * @param str
     * @return Map<String, String>
     */
    public static Map<String, String> encryptStr(String str) {
        Map<String, String> map = new HashMap<>();
        String salt = EncryptionUtils.generateSalt(2);
        String encryptedStr = EncryptionUtils.oneWayHash(str, salt);
        map.put("code", salt);
        map.put("encryptedStr", encryptedStr);
        return map;
    }
}
