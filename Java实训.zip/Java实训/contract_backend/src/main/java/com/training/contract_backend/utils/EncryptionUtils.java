package com.training.contract_backend.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.crypto.hash.SimpleHash;
import sun.misc.BASE64Decoder;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

public class EncryptionUtils {
    /*
     * *************************************************************************
     *                                  单向加密
     * *************************************************************************
     */

    // 散列方式
    private static final String method = "SHA1";

    // 单向散列次数
    private static final Integer ITERATIONS = 5;

    /**
     * 单向散列加密
     * @param input 需要散列字符串
     * @param salt 盐字符串
     * @return
     */
    public static String oneWayHash(String input, String salt) {
        return new SimpleHash(method, input, salt, ITERATIONS).toString();
    }

    /*
     * *************************************************************************
     *                                  对称加密
     * *************************************************************************
     */

    // 对称加密算法
    private static final String SYMMETRIC_ALGORITHM = "DES";

    // 密钥必须是八个字符
    private static final String SYMMETRIC_SECRET_KEY = "abcdabcd";

    private static final String key = "1538663015386630";
    private static final String IV = "sdaefascvfelk392";


    /**
     * 对称加密字符串
     * @return
     * @throws Exception
     */
    public static String symmetricEncrypt(String str) throws Exception {
        SecretKeySpec key = new SecretKeySpec(SYMMETRIC_SECRET_KEY.getBytes(), SYMMETRIC_ALGORITHM);
        Cipher cipher = Cipher.getInstance(SYMMETRIC_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encipherByte = cipher.doFinal(str.getBytes());

        // 防止乱码，使用Base64编码
        return Base64.encodeBase64String(encipherByte);
    }

    /**
     * 对称解密
     * @return
     */
    public static String symmetricDecrypt(String str) throws Exception{
        SecretKeySpec key = new SecretKeySpec(SYMMETRIC_SECRET_KEY.getBytes(), SYMMETRIC_ALGORITHM);
        Cipher cipher = Cipher.getInstance(SYMMETRIC_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decode = Base64.decodeBase64(str);
        byte[] decipherByte = cipher.doFinal(decode);
        return new String(decipherByte);
    }

    public static String decrypt(String cipherStr) {
        // 对于前端的密文要先base64解密
        BASE64Decoder decoder = new BASE64Decoder();
        IvParameterSpec iv = new IvParameterSpec(IV.getBytes());
        SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "AES");
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            return new String(cipher.doFinal(decoder.decodeBuffer(cipherStr)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
     * *************************************************************************
     *                                  辅助函数
     * *************************************************************************
     */

    /**
     * 随机获得salt字符串
     * @return
     */
    public static String generateSalt(int n){
        SecureRandomNumberGenerator randomNumberGenerator = new SecureRandomNumberGenerator();
        return randomNumberGenerator.nextBytes(n).toHex();
    }

}
