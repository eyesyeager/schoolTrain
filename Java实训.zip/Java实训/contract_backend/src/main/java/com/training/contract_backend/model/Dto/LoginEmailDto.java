package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "邮箱登录相关")
public class LoginEmailDto {
    @ApiModelProperty(value = "账号", example = "0")
    private Integer id;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("key")
    private String key;

    @ApiModelProperty("验证码")
    private String code;
}