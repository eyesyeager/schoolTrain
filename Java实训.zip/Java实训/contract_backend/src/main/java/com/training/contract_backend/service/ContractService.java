package com.training.contract_backend.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.training.contract_backend.model.Do.ContractDo;
import com.training.contract_backend.model.Do.ContractPayDo;
import com.training.contract_backend.model.Do.CustomerDo;

import java.util.List;

public interface ContractService {

//    // 专题分析 根据签单状态和条件查询结果
//    public List<ContractDo> findByCondition(ContractDo contractDo);

    // 专题分析 根据签单状态和条件查询结果 分页查询 权限管理
    public Page<ContractDo> findByCondition(Page<ContractDo> page,ContractDo contractDo);

//    // 合同首页 根据时间查询结果
//    public List<ContractDo> findByTime(int time, int status);

    // 合同首页 根据时间查询结果 分页查询 权限管理
    public Page<ContractDo> findByTime(Page<ContractDo> page,int time, int status);

    // 合同首页 预览合同
    public ContractDo previewContract(String name);

    // 合同首页 付款节点
    public List<ContractPayDo> findContractPay(String name);

//    // 合同看板 搜索合同
//    public List<ContractDo> findByName(String name,int status);

    // 合同看板 搜索合同 分页查询 权限管理
    public Page<ContractDo> findByName(Page<ContractDo> page,String name,int status);

    // 合同看板 关闭合同
    public void closeContract(String name);

    // 合同看板 进入合同
    public ContractDo enterContract(String name);

    // 增加合同 权限管理
    public ContractDo judgeContract(ContractDo contractDo);
    public void saveContract(ContractDo contractDo);

    // 新增客户
    public CustomerDo judgeCustomer(CustomerDo customerDo);
    public void saveCustomer(CustomerDo customerDo);

    // 所有客户
    public List<CustomerDo> findCustomer();

}
