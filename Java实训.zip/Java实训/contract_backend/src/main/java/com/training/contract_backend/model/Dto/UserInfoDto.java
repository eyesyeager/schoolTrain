package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Date;

@Data
@ApiModel(description = "用户个人信息")
public class UserInfoDto {
    @ApiModelProperty("用户id")
    private Integer id;

    @ApiModelProperty("名字")
    private String name;

    @ApiModelProperty("用户头像")
    private String avatar;

    @ApiModelProperty("用户邮箱")
    private String email;

    @ApiModelProperty("用户角色")
    private String role;

    @ApiModelProperty("用户部门")
    private Integer department;

    @ApiModelProperty("用户性别")
    private Integer gender;

    @ApiModelProperty("生日")
    private Date birthday;

    @ApiModelProperty("入职日期")
    private Date hiredate;
}
