package com.training.contract_backend.service;

/**
 * 测试接口
 */
public interface TestService {
}
