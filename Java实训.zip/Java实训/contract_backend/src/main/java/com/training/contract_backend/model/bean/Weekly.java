package com.training.contract_backend.model.bean;

import lombok.Data;

import java.sql.Date;
import java.sql.Timestamp;

@Data
public class Weekly {

    private Integer id;

    private Integer userId;

    private String signature;

    private Double money;

    private String project;

    private String otherContext;

    private String nextWeekWork;

    private String problemAndThink;

    private String remarks;

    private Date createTime;

    private Timestamp updateTime;

    private Date weekFlag;
}
