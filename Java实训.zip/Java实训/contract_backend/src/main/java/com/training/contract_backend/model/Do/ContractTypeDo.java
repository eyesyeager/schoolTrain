package com.training.contract_backend.model.Do;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("合同类型实体类")
public class ContractTypeDo {

    // 合同编号
    @ApiModelProperty("合同编号")
    private int contractId;
    // 合同类型
    @ApiModelProperty("合同类型")
    private int type;
    // 合同金额
    @ApiModelProperty("合同金额")
    private double money;
    // 税率
    @ApiModelProperty("税率")
    private int taxRate;
    // 税率额
    @ApiModelProperty("税率额")
    private double taxMoney;

    public int getContractId() {
        return contractId;
    }

    public void setContractId(int contractId) {
        this.contractId = contractId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public int getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(int taxRate) {
        this.taxRate = taxRate;
    }

    public double getTaxMoney() {
        return taxMoney;
    }

    public void setTaxMoney(double taxMoney) {
        this.taxMoney = taxMoney;
    }

    @Override
    public String toString() {
        return "ContractTypeDo{" +
                "contractId=" + contractId +
                ", type=" + type +
                ", money=" + money +
                ", taxRate=" + taxRate +
                ", taxMoney=" + taxMoney +
                '}';
    }
}
