package com.training.contract_backend.model.Dto;

import com.training.contract_backend.model.bean.Weekly;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;
@Data
@ApiModel(description = "新建周报")
public class WeeklyAddDto {

     private Weekly weekly;

     private List<String> attendance;

}
