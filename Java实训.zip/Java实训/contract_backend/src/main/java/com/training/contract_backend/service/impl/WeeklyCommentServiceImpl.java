package com.training.contract_backend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.training.contract_backend.mapper.WeeklyCommentMapper;
import com.training.contract_backend.model.Dto.WeeklyCommentDto;
import com.training.contract_backend.model.bean.WeeklyComment;
import com.training.contract_backend.service.IWeeklyCommentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeeklyCommentServiceImpl extends ServiceImpl<WeeklyCommentMapper, WeeklyComment> implements IWeeklyCommentService {

    @Override
    public List<WeeklyCommentDto> weeklyCommentCheck(Integer id){
        return baseMapper.weeklyCommentCheck(id);
    }


    }



