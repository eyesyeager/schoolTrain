package com.training.contract_backend.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.training.contract_backend.model.Do.ContractDo;
import com.training.contract_backend.model.Do.ContractPayDo;
import com.training.contract_backend.model.Do.CustomerDo;
import com.training.contract_backend.result.Result;
import com.training.contract_backend.service.ContractService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contract")
@Api(tags = "合同模块接口")
public class ContractController {

    @Autowired
    private ContractService contractService;

//    // 专题分析 根据签单状态和条件查询结果
//    @PostMapping("/findByCondition")
//    @ApiOperation("专题分析")
//    public Result<List<ContractDo>> findByCondition(@RequestBody ContractDo contractDo) {
//        System.out.println(contractDo);
//        List<ContractDo> contractDoList = contractService.findByCondition(contractDo);
//        System.out.println(contractDoList);
//        return Result.success(contractDoList);
//    }

    //    专题分析 根据签单状态和条件查询结果 分页查询 权限控制
    @PostMapping("/findByCondition")
    @ApiOperation("专题分析")
    public Result<Page<ContractDo>> findByCondition(@RequestBody ContractDo contractDo,Integer current) {
        System.out.println(contractDo);
        Page<ContractDo> page = new Page<>(current,3);
        Page<ContractDo> contractDoPage = contractService.findByCondition(page,contractDo);
        System.out.println(contractDoPage);
        return Result.success(contractDoPage);
    }

//    // 合同首页 根据时间查询结果
//    @GetMapping("/findByTime")
//    @ApiOperation("查询时间")
//    public Result<List<ContractDo>> findByTime(int time, int status) {
//        List<ContractDo> contractDoList = contractService.findByTime(time, status);
//        System.out.println(contractDoList);
//        return Result.success(contractDoList);
//    }

    // 合同首页 根据时间查询结果 分页查询 权限控制
    @GetMapping("/findByTime")
    @ApiOperation("查询时间")
    public Result<Page<ContractDo>> findByTime(int time, int status,int current) {
        Page<ContractDo> page = new Page<>(current,2);
        Page<ContractDo> contractDoPage = contractService.findByTime(page,time, status);
        System.out.println(contractDoPage);
        return Result.success(contractDoPage);
    }

    // 合同首页 预览合同
    @GetMapping("/previewContract")
    @ApiOperation("预览合同")
    public Result<ContractDo> previewContract(String name) {
        ContractDo contractDo = contractService.previewContract(name);
        System.out.println(contractDo);
        return Result.success(contractDo);
    }

    // 合同首页 付款节点
    @GetMapping("/findContractPay")
    @ApiOperation("付款节点")
    public Result<List<ContractPayDo>> findContractPay(String name) {
        List<ContractPayDo> contractPayDoList = contractService.findContractPay(name);
        System.out.println(contractPayDoList);
        return Result.success(contractPayDoList);
    }

//    // 合同看板 搜索合同
//    @GetMapping("/findByName")
//    @ApiOperation("搜索合同")
//    public Result<List<ContractDo>> findByName(String name,int status) {
//        List<ContractDo> contractDoList = contractService.findByName(name,status);
//        System.out.println(contractDoList);
//        return Result.success(contractDoList);
//    }

    // 合同看板 搜索合同 分页查询 权限控制
    @GetMapping("/findByName")
    @ApiOperation("搜索合同")
    public Result<Page<ContractDo>> findByName(String name,int status,int current) {
        Page<ContractDo> page = new Page<>(current,2);
        Page<ContractDo> contractDoPage = contractService.findByName(page,name,status);
        System.out.println(contractDoPage);
        return Result.success(contractDoPage);
    }

    // 合同看板 关闭合同
    @GetMapping("/closeContract")
    @ApiOperation("关闭合同")
    public Result<Void> closeContract(String name) {
        contractService.closeContract(name);
        return Result.success();
    }


    // 合同看板 进入合同
    @GetMapping("/enterContract")
    @ApiOperation("进入合同")
    public Result<ContractDo> enterContract(String name) {
        ContractDo contractDo = contractService.enterContract(name);
        System.out.println(contractDo);
        return Result.success(contractDo);
    }


    // 添加合同 权限控制
    @PostMapping(value = "/saveContract")
    @ApiOperation("添加合同")
    public Result<Void> saveContract(@RequestBody ContractDo contractDo) {
        ContractDo judgeContract = contractService.judgeContract(contractDo);
        if(judgeContract != null){
            return Result.failure(401,"合同名重复");
        }
        else {
            contractService.saveContract(contractDo);
            return Result.success();
        }
    }

    // 新增客户
    @PostMapping(value = "/saveCustomer")
    @ApiOperation("新增客户")
    public Result<Void> saveCustomer(@RequestBody CustomerDo customerDo) {
        CustomerDo judgeCustomer = contractService.judgeCustomer(customerDo);
        if(judgeCustomer != null){
            return Result.failure(401,"客户名重复");
        }
        else {
            contractService.saveCustomer(customerDo);
            return Result.success();
        }
    }

    // 所有客户
    @PostMapping("/findCustomer")
    @ApiOperation("搜索客户")
    public Result<List<CustomerDo>> findCustomer(){
        List<CustomerDo> customerDoList = contractService.findCustomer();
        System.out.println(customerDoList);
        return Result.success(customerDoList);
    }

}
