package com.training.contract_backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.training.contract_backend.model.Dto.ShowWeeklyDto;
import com.training.contract_backend.model.Dto.WeeklyAddDto;
import com.training.contract_backend.model.Dto.WeeklyDto;
import com.training.contract_backend.model.bean.Weekly;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.util.List;

@Mapper
public interface WeeklyMapper extends BaseMapper<Weekly> {

    IPage<WeeklyDto> selectByCondition(
            IPage<Weekly> pg,
            @Param("date") Date date,
            @Param("department") Integer department,
            @Param("name") String name,
            @Param("role") Integer role,
            @Param("userDepartment") Integer userDepartment,
            @Param("limitId") Integer limitId
    );

    ShowWeeklyDto weeklycheck(
            @Param("id") Integer id
    );

    List<String> weeklyAttendance(Integer id);


}
