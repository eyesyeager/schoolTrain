package com.training.contract_backend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.training.contract_backend.model.Dto.WeeklyCommentDto;
import com.training.contract_backend.model.bean.WeeklyComment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface WeeklyCommentMapper extends BaseMapper<WeeklyComment> {

    List<WeeklyCommentDto> weeklyCommentCheck(
            @Param("id") Integer id
    );


}
