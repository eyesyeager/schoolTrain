package com.training.contract_backend.controller;

import com.training.contract_backend.exception.CustomException;
import com.training.contract_backend.model.Dto.*;
import com.training.contract_backend.module.RoleModule;
import com.training.contract_backend.result.Result;
import com.training.contract_backend.service.UserService;
import com.training.contract_backend.utils.QiniuUtils;
import io.swagger.annotations.*;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("user")
@Api(tags = "用户模块接口")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @ApiOperation("获取图形验证码")
    @PostMapping("/getVeriCode")
    public Result<VeriCodeDto> getVeriCode(@RequestBody Map<String, Object> map) throws Exception {
        if (map.get("id") == null) throw new CustomException(400, "请输入用户账号");
        return Result.success(userService.getVeriCode((Integer)map.get("id")));
    }

    @ApiOperation("发送邮箱验证码")
    @PostMapping("/getMailCode")
    public Result<EmailResponseDto> getEmailVeriCode(@RequestBody EmailVeriCodeDto emailVeriCodeDto) throws Exception {
        return Result.success(userService.getEmailVeriCode(emailVeriCodeDto));
    }

    @ApiOperation("文件上传操作")
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Result<FileDto> upload(@RequestPart("file") MultipartFile multipartFile) throws CustomException {
        return Result.success(userService.upload(multipartFile));
    }

    @ApiOperation("登录")
    @PostMapping("/login")
    public Result<UserDto> login(@RequestBody LoginDto loginDto) throws Exception {
        return Result.success(userService.doLogin(loginDto));
    }

    @ApiOperation("首次登录")
    @PostMapping("/firstLogin")
    public Result<Void> firstLogin(@RequestBody LoginEmailDto loginEmailDto) throws Exception {
        System.out.println(loginEmailDto);
        userService.firstLogin(loginEmailDto);
        return Result.success();
    }

    @ApiOperation("修改密码")
    @PutMapping("/updatePsd")
    public Result<Void> updatePsd(@RequestBody LoginEmailDto loginEmailDto) throws Exception {
        userService.updatePsd(loginEmailDto);
        return Result.success();
    }

    @ApiOperation("获取用户信息")
    @GetMapping("/getUserInfo")
    public Result<UserInfoDto> getUserInfo() {
        return Result.success(userService.getUserInfo(RoleModule.getId()));
    }

    @ApiOperation("修改用户信息")
    @PutMapping("/updateUserInfo")
    public Result<Void> updateUserInfo(@RequestBody UserInfoDto userInfoDto) {
        userInfoDto.setId(RoleModule.getId());
        userService.updateUserInfo(userInfoDto);
        return Result.success();
    }

    @ApiOperation("注册")
    @PostMapping("/addUser")
    public Result<UserInitDto> addUser(@RequestBody UserAddDto userAddDto) throws CustomException, InvocationTargetException, IllegalAccessException {
        return Result.success(userService.register(userAddDto));
    }
}