package com.training.contract_backend.model.Dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.sql.Date;

@Data
@ApiModel(description = "评论详情")
public class WeeklyCommentDto {
    @ApiModelProperty("点评人Id")
    private Integer userId;

    @ApiModelProperty("点评人名称")
    private String userName;

    @ApiModelProperty("点评人头像")
    private String userAvatar;

    @ApiModelProperty("点评时间")
    private Date commentTime;

    @ApiModelProperty("点评内容")
    private String comment;
}

