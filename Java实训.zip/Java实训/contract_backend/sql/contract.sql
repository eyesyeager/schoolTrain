/*
 Navicat Premium Data Transfer

 Source Server         : dell
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : cn-zz-bgp-1.natfrp.cloud:63092
 Source Schema         : contract

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 17/07/2022 10:18:43
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for contract
-- ----------------------------
DROP TABLE IF EXISTS `contract`;
CREATE TABLE `contract`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `identifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `customer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `BG` smallint NOT NULL,
  `BU` smallint NOT NULL,
  `industry` int NOT NULL,
  `industry_child` int NOT NULL,
  `project_type` int NOT NULL,
  `region` int NOT NULL,
  `organization` int NOT NULL,
  `province` int NOT NULL,
  `account_manager` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `product_line` int NOT NULL,
  `customer_organ` int NOT NULL,
  `create_time` date NOT NULL,
  `contract_status` int NOT NULL COMMENT '1：在途，2：已完成',
  `protection_time` int NOT NULL,
  `currency` int NOT NULL COMMENT '1：人民币，2：美元，3：日元，4：英镑',
  `is_bond` int NOT NULL COMMENT '1：不存在、2：存在',
  `pay_type` int NOT NULL COMMENT '1：支票，2：电汇，3：银行承兑汇票，4：商业承兑汇票，5：转账',
  `contract_body` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gross_profit_table` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `schedule_prices_table` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `other_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `contract_type_num` int NOT NULL,
  `contract_total_money` double NOT NULL,
  `contract_total_tax` double NOT NULL,
  `limit_department` int NULL DEFAULT NULL,
  `limit_user` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `contract_name_uindex`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 76 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contract
-- ----------------------------
INSERT INTO `contract` VALUES (42, '测试合同1', '010123456', '测试客户1', 1, 2, 2, 3, 2, 1, 2, 1, '李华', 2, 1, '2022-07-05', 2, 1, 1, 1, 1, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/bc6335c4-20d9-4067-a459-473c5e107a13明.md', 'http://remz9wszw.hn-bkt.clouddn.com/dc232c1e-f5ee-4d77-881a-cd52856fa96e明.md', '这是测试合同1', 1, 20000, 600, 2, 20220003);
INSERT INTO `contract` VALUES (45, '测试合同2', '020132456', '测试客户2', 2, 8, 2, 1, 1, 1, 1, 4, '黎明', 3, 2, '2022-07-04', 2, 2, 1, 1, 1, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/8829a38d-46db-4704-a5e7-345292e6d15fE.md', 'http://remz9wszw.hn-bkt.clouddn.com/4b25fc4b-f6f7-497d-928d-4d8521cf3e9dE.md', '这是测试合同2', 2, 30000, 1100, 2, 20220003);
INSERT INTO `contract` VALUES (46, '测试合同3', '020132456', '测试客户2', 2, 8, 2, 1, 1, 1, 1, 4, '黎明', 3, 2, '2022-07-04', 2, 2, 1, 1, 1, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/8829a38d-46db-4704-a5e7-345292e6d15fE.md', 'http://remz9wszw.hn-bkt.clouddn.com/4b25fc4b-f6f7-497d-928d-4d8521cf3e9dE.md', '这是测试合同2', 2, 30000, 1100, 2, 20220003);
INSERT INTO `contract` VALUES (48, '测试合同4', '', '测试客户2', 1, 6, 2, 1, 1, 1, 1, 4, '李四', 3, 1, '2022-07-07', 2, 2, 1, 2, 5, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 1, 20200, 606, 2, 20220003);
INSERT INTO `contract` VALUES (49, '测试合同5——这个名字很长', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2022-07-01', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, 2, 20220003);
INSERT INTO `contract` VALUES (51, '测试合同6', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2021-07-02', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, 3, 20220009);
INSERT INTO `contract` VALUES (52, '测试合同7', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2021-07-02', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, 3, 20220009);
INSERT INTO `contract` VALUES (53, '测试合同8', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2021-07-02', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, 3, 20220009);
INSERT INTO `contract` VALUES (54, '测试合同9', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2020-07-03', 1, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, NULL, NULL);
INSERT INTO `contract` VALUES (55, '测试合同10', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2020-07-03', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, NULL, NULL);
INSERT INTO `contract` VALUES (56, '测试合同11', '023132', '测试客户1', 2, 7, 1, 5, 2, 2, 1, 2, '丽丽', 3, 1, '2020-07-03', 2, 1, 2, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', '', 2, 6800, 260, NULL, NULL);
INSERT INTO `contract` VALUES (57, '测试合同12', '010123456', '测试客户1', 1, 2, 2, 3, 2, 1, 2, 1, '李华', 2, 1, '2019-07-06', 2, 1, 1, 2, 1, 'http://remz9wszw.hn-bkt.clouddn.com/9559ee19-9a68-4d42-b709-505b2ae154cc明.md', 'http://remz9wszw.hn-bkt.clouddn.com/bc6335c4-20d9-4067-a459-473c5e107a13明.md', 'http://remz9wszw.hn-bkt.clouddn.com/dc232c1e-f5ee-4d77-881a-cd52856fa96e明.md', '这是测试合同1', 1, 20000, 600, 3, 20220009);
INSERT INTO `contract` VALUES (58, '测试合同13', '020132456', '测试客户2', 2, 8, 2, 1, 1, 1, 1, 4, '黎明', 3, 2, '2019-07-06', 1, 2, 1, 1, 1, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/8829a38d-46db-4704-a5e7-345292e6d15fE.md', 'http://remz9wszw.hn-bkt.clouddn.com/4b25fc4b-f6f7-497d-928d-4d8521cf3e9dE.md', '这是测试合同2', 2, 30000, 1100, NULL, NULL);
INSERT INTO `contract` VALUES (59, '测试合同14', '020132456', '测试客户2', 2, 8, 2, 1, 1, 1, 1, 4, '黎明', 3, 2, '2019-07-06', 1, 2, 1, 1, 1, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/8829a38d-46db-4704-a5e7-345292e6d15fE.md', 'http://remz9wszw.hn-bkt.clouddn.com/4b25fc4b-f6f7-497d-928d-4d8521cf3e9dE.md', '这是测试合同2', 2, 30000, 1100, NULL, NULL);
INSERT INTO `contract` VALUES (60, '测试合同20', '20212', '测试客户3', 2, 7, 1, 2, 2, 1, 1, 4, '莉莉', 2, 1, '2020-07-08', 1, 2, 2, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', '这是测试20', 2, 50000, 1500, 3, 20220009);
INSERT INTO `contract` VALUES (61, '测试合同21', '', '测试客户3', 1, 5, 2, 3, 2, 2, 2, 3, '理理', 2, 1, '2018-07-04', 1, 3, 4, 1, 5, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', '', 2, 230000, 6000, NULL, NULL);
INSERT INTO `contract` VALUES (62, '测试合同22', '2021213', '测试客户3', 1, 7, 1, 2, 1, 1, 1, 4, '李立', 3, 1, '2019-04-10', 1, 3, 3, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', '这是测试22', 1, 20000, 600, NULL, NULL);
INSERT INTO `contract` VALUES (65, '测试合同23', '', '测试客户3', 3, 5, 3, 1, 1, 2, 1, 3, 'Lilith', 1, 2, '2019-07-11', 1, 3, 3, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/d2953c34-b10d-4286-b3af-c032200a7ea6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/8eb6b31c-d96b-4167-b35d-17d3d8d3ead5t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/78e227c1-ad11-4c4a-be6f-2e7535960ca0t.txt', '', 2, 50000, 900, 3, 20220009);
INSERT INTO `contract` VALUES (66, '测试合同15', '', '测试客户3', 1, 7, 2, 3, 2, 1, 1, 4, '李磊', 2, 1, '2022-07-05', 1, 3, 4, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/fa1d715e-379d-47af-ae52-5651892c7f6at.txt', 'http://remz9wszw.hn-bkt.clouddn.com/723eaeb2-7d91-4abd-b2dc-418f81d77a3dt.txt', 'http://remz9wszw.hn-bkt.clouddn.com/fb92529b-b23a-474d-b7f3-6858ac832a35t.txt', '这是测试15', 2, 30000, 1100, 2, 20220003);
INSERT INTO `contract` VALUES (67, '测试合同16', '20214516', '测试客户3', 1, 6, 2, 3, 1, 1, 2, 3, '李雷', 3, 1, '2022-07-05', 2, 2, 1, 2, 4, 'http://remz9wszw.hn-bkt.clouddn.com/0d5f4aa8-07dc-439c-af28-3dc5d6c6ad06].txt', 'http://remz9wszw.hn-bkt.clouddn.com/3836773a-216f-410a-b386-02b2d30c149ct.txt', 'http://remz9wszw.hn-bkt.clouddn.com/838803dd-021b-4806-900b-54f1f18c9afct.txt', '这是测试16', 2, 35000, 750, 2, 20220003);
INSERT INTO `contract` VALUES (68, '测试合同17', '', '测试客户3', 3, 6, 3, 3, 1, 2, 1, 3, '李蕾', 1, 1, '2022-06-07', 1, 3, 3, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/2ebb997c-98ff-4330-b411-3b400c5556cd].txt', 'http://remz9wszw.hn-bkt.clouddn.com/71d2afd8-d347-4eae-ba1e-a395b68f4015t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/5eac762a-3c28-45fb-9d50-809cf7778da2].txt', '', 2, 61000, 1030, 3, 20220009);
INSERT INTO `contract` VALUES (70, '测试合同40', '', '测试客户10', 2, 5, 2, 3, 2, 2, 2, 3, '金潇', 2, 2, '2022-07-09', 1, 2, 3, 1, 4, 'http://remz9wszw.hn-bkt.clouddn.com/0bd995b7-ace3-404d-bff0-590d676cc2eft.txt', 'http://remz9wszw.hn-bkt.clouddn.com/90a53805-f53a-4dfe-b0fc-3defec44dd07t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/533f8698-0f33-439c-9f6a-f6bc4b8223a7t.txt', '', 2, 900000, 27000, 3, 20220009);
INSERT INTO `contract` VALUES (71, '测试合同24', '', '测试客户10', 2, 6, 3, 3, 1, 2, 1, 4, '李罍', 3, 1, '2021-07-14', 1, 2, 2, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/ae1450f2-52c3-4737-8b21-e88645202cc7t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/8852e58d-cf43-48e7-8a76-72fd6629ded6t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/430d39b3-f510-4543-aaac-4321a49cf117x.txt', '这是测试24', 3, 60000, 1400, 3, 20220009);
INSERT INTO `contract` VALUES (72, '测试合同25', '12456', '测试客户10', 1, 7, 2, 2, 2, 1, 1, 4, '李黎', 3, 2, '2021-07-21', 2, 2, 3, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/9dff30bd-e5be-462e-8f8a-5c91a8667061t.txt', 'http://remz9wszw.hn-bkt.clouddn.com/6a5eb659-9d77-4685-b8de-e3331f0b46a9].txt', 'http://remz9wszw.hn-bkt.clouddn.com/7526d9f9-c5fb-4652-ab5b-042507b14ef6t.txt', '', 2, 60000, 1800, 3, 20220009);
INSERT INTO `contract` VALUES (73, '测试合同26', '', '测试客户5', 1, 6, 2, 2, 1, 1, 2, 3, '李垒', 1, 1, '2020-07-13', 1, 2, 2, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/026dd230-148d-46c1-ad88-ff5eddf6c1ebt.txt', 'http://remz9wszw.hn-bkt.clouddn.com/0aa54751-2b80-4711-8f5e-32a1450650c8].txt', 'http://remz9wszw.hn-bkt.clouddn.com/a36c60ff-90c6-4748-943b-18ce0bcf30bax.txt', '这是测试25', 2, 60000, 1800, 3, 20220009);
INSERT INTO `contract` VALUES (74, '测试30', '', '测试客户50', 0, 3, 2, 3, 2, 2, 2, 2, '丽丽', 1, 1, '2021-07-13', 1, 1, 2, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/48a80200-4acf-407b-8e58-726224d17b43g.js', 'http://remz9wszw.hn-bkt.clouddn.com/f499ea6a-c429-4334-b506-f470383fc3a3E.md', 'http://remz9wszw.hn-bkt.clouddn.com/83052df6-2cb2-41a5-9a34-7be558360e65g.js', '', 1, 30000, 900, 3, 20220009);
INSERT INTO `contract` VALUES (75, '测试合同1422442', '', '测试客户1', 2, 3, 2, 2, 2, 2, 2, 2, 'gfw', 2, 2, '2022-07-12', 2, 2, 1, 2, 3, 'http://remz9wszw.hn-bkt.clouddn.com/90df24a9-a984-49e8-b87d-1112c653a5001.png', 'http://remz9wszw.hn-bkt.clouddn.com/651d0a4c-c949-4ae1-b1e6-54cebafc7e142.png', 'http://remz9wszw.hn-bkt.clouddn.com/96eb1703-2f3b-4990-b1c7-7d9f5a913d5e3.png', '', 1, 1000, 10, 0, 20220001);

-- ----------------------------
-- Table structure for contract_pay
-- ----------------------------
DROP TABLE IF EXISTS `contract_pay`;
CREATE TABLE `contract_pay`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `time_node` int NULL DEFAULT NULL COMMENT '1：首付款、2：上线款、3：初验款、4：终验款、5：尾款',
  `pay_money` double NULL DEFAULT NULL,
  `pay_rate` double NULL DEFAULT NULL,
  `pay_node` double NULL DEFAULT NULL,
  `pay_condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contract_pay
-- ----------------------------
INSERT INTO `contract_pay` VALUES (26, 48, 1, 2000, 10, 0, '');
INSERT INTO `contract_pay` VALUES (27, 48, 5, 18000, 90, 100, '完成项目');
INSERT INTO `contract_pay` VALUES (28, 49, 1, 20000, 40, 0, '');
INSERT INTO `contract_pay` VALUES (29, 49, 4, 30000, 60, 90, '');
INSERT INTO `contract_pay` VALUES (30, 60, 1, 30000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (31, 60, 5, 20000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (32, 65, 1, 20000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (33, 65, 3, 30000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (34, 66, 1, 20000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (35, 66, 3, 10000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (36, 67, 1, 25000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (37, 67, 4, 10000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (38, 68, 1, 41000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (39, 68, 4, 20000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (40, 70, 1, 300000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (41, 70, 4, 600000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (42, 71, 1, 12000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (43, 71, 2, 12000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (44, 71, 3, 12000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (45, 71, 4, 12000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (46, 71, 5, 12000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (47, 72, 1, 60000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (48, 73, 1, 30000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (49, 73, 4, 30000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (50, 74, 1, 30000, 0, 0, '');
INSERT INTO `contract_pay` VALUES (51, 75, 1, 1000, 0, 0, '');

-- ----------------------------
-- Table structure for contract_type
-- ----------------------------
DROP TABLE IF EXISTS `contract_type`;
CREATE TABLE `contract_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `contract_id` int NOT NULL,
  `type` int NOT NULL COMMENT '1：软件开发、2：第三方软件、3：第三方硬件、4：系统集成、5：维护保障、6：技术服务',
  `money` double NOT NULL,
  `tax_rate` int NOT NULL COMMENT '1：无税、2：1%、3：3%、4:5%',
  `tax_money` double NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 60 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contract_type
-- ----------------------------
INSERT INTO `contract_type` VALUES (17, 42, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (20, 48, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (21, 49, 1, 10000, 2, 0);
INSERT INTO `contract_type` VALUES (22, 49, 4, 40000, 4, 0);
INSERT INTO `contract_type` VALUES (23, 60, 1, 20000, 1, 0);
INSERT INTO `contract_type` VALUES (24, 60, 6, 30000, 4, 0);
INSERT INTO `contract_type` VALUES (25, 61, 1, 200000, 3, 0);
INSERT INTO `contract_type` VALUES (26, 61, 5, 30000, 1, 0);
INSERT INTO `contract_type` VALUES (27, 62, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (28, 65, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (29, 65, 3, 30000, 2, 0);
INSERT INTO `contract_type` VALUES (30, 66, 1, 10000, 2, 0);
INSERT INTO `contract_type` VALUES (31, 66, 3, 20000, 4, 0);
INSERT INTO `contract_type` VALUES (32, 67, 1, 15000, 2, 0);
INSERT INTO `contract_type` VALUES (33, 67, 5, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (34, 68, 1, 21000, 3, 0);
INSERT INTO `contract_type` VALUES (35, 68, 3, 40000, 2, 0);
INSERT INTO `contract_type` VALUES (36, 70, 4, 200000, 3, 0);
INSERT INTO `contract_type` VALUES (37, 70, 5, 700000, 3, 0);
INSERT INTO `contract_type` VALUES (38, 71, 1, 30000, 2, 0);
INSERT INTO `contract_type` VALUES (39, 71, 3, 20000, 4, 0);
INSERT INTO `contract_type` VALUES (40, 71, 5, 10000, 2, 0);
INSERT INTO `contract_type` VALUES (41, 72, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (42, 72, 4, 40000, 3, 0);
INSERT INTO `contract_type` VALUES (43, 73, 1, 20000, 3, 0);
INSERT INTO `contract_type` VALUES (44, 73, 5, 40000, 3, 0);
INSERT INTO `contract_type` VALUES (45, 45, 2, 20000, 2, NULL);
INSERT INTO `contract_type` VALUES (46, 45, 3, 50000, 3, NULL);
INSERT INTO `contract_type` VALUES (47, 46, 4, 40000, 1, NULL);
INSERT INTO `contract_type` VALUES (48, 46, 5, 40000, 2, NULL);
INSERT INTO `contract_type` VALUES (49, 51, 1, 20000, 3, NULL);
INSERT INTO `contract_type` VALUES (50, 52, 5, 40000, 3, NULL);
INSERT INTO `contract_type` VALUES (51, 53, 1, 30000, 2, NULL);
INSERT INTO `contract_type` VALUES (52, 54, 3, 20000, 4, NULL);
INSERT INTO `contract_type` VALUES (53, 55, 5, 700000, 3, NULL);
INSERT INTO `contract_type` VALUES (54, 56, 3, 30000, 2, NULL);
INSERT INTO `contract_type` VALUES (55, 57, 3, 20000, 4, NULL);
INSERT INTO `contract_type` VALUES (56, 58, 5, 10000, 2, NULL);
INSERT INTO `contract_type` VALUES (57, 59, 4, 200000, 3, NULL);
INSERT INTO `contract_type` VALUES (58, 74, 1, 30000, 3, 0);
INSERT INTO `contract_type` VALUES (59, 75, 1, 1000, 2, 0);

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `level` smallint NULL DEFAULT NULL,
  `industry` int NULL DEFAULT NULL,
  `postal_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `province` int NULL DEFAULT NULL,
  `city` int NULL DEFAULT NULL,
  `county` int NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_organization` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_tax_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_bank` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `invoice_account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (14, '测试客户1', 1, 1, '230031', 1, 1, 1, '蜀山区合肥工业大学翡翠湖校区', '合肥工业大学', '010123', '16655032814', '蜀山区合肥工业大学翡翠湖校区', '中国银行', '123456');
INSERT INTO `customer` VALUES (15, '测试客户2', 1, 2, '', 0, 1, 2, '合肥市', '', '', '123456', '', '', '');
INSERT INTO `customer` VALUES (17, '测试客户3', 2, 3, '', 1, 2, 1, '合肥工业大学', '', '', '', '', '', '');
INSERT INTO `customer` VALUES (18, '测试客户4', 1, 3, '123456', 1, 1, 1, '合肥工业大学', '', '', '', '', '', '');
INSERT INTO `customer` VALUES (19, '测试客户10', 2, 2, '200001', 3, 2, 1, '合肥工业大学', '合肥工业大学', '', '', '', '', '');
INSERT INTO `customer` VALUES (20, '测试客户20', 0, 0, '', 0, 0, 0, '', '', '', '', '', '', '');
INSERT INTO `customer` VALUES (21, '测试客户5', 1, 2, '', 1, 1, 1, '', '', '', '', '', '', '');
INSERT INTO `customer` VALUES (22, '测试客户50', 1, 0, '', 1, 1, 1, '', '', '', '', '', '', '');
INSERT INTO `customer` VALUES (23, '123', 0, 0, '', 0, 0, 0, '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `manager_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (0, '超级管理员', 0);
INSERT INTO `department` VALUES (1, '运营商事业部', 1);
INSERT INTO `department` VALUES (2, '消费者事业群', 2);

-- ----------------------------
-- Table structure for login_log
-- ----------------------------
DROP TABLE IF EXISTS `login_log`;
CREATE TABLE `login_log`  (
  `id` int NOT NULL,
  `account` int NOT NULL,
  `time` timestamp NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `result` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '登录状态（0：成功、1：失败）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of login_log
-- ----------------------------

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 20220001, 'manager');
INSERT INTO `role` VALUES (2, 20220001, 'user');
INSERT INTO `role` VALUES (3, 20220002, 'manager');
INSERT INTO `role` VALUES (4, 20220002, 'user');
INSERT INTO `role` VALUES (5, 20220003, 'manager');
INSERT INTO `role` VALUES (6, 20220003, 'user');
INSERT INTO `role` VALUES (7, 20220004, 'user');
INSERT INTO `role` VALUES (8, 20220001, 'admin');
INSERT INTO `role` VALUES (9, 20220008, 'user');
INSERT INTO `role` VALUES (10, 20220008, 'manager');
INSERT INTO `role` VALUES (11, 20220009, 'user');
INSERT INTO `role` VALUES (12, 20220010, 'user');
INSERT INTO `role` VALUES (13, 20220011, 'user');
INSERT INTO `role` VALUES (14, 20220011, 'manager');
INSERT INTO `role` VALUES (15, 20220012, 'user');
INSERT INTO `role` VALUES (16, 20220012, 'manager');
INSERT INTO `role` VALUES (17, 20220013, 'user');
INSERT INTO `role` VALUES (18, 20220013, 'manager');
INSERT INTO `role` VALUES (19, 20220014, 'user');
INSERT INTO `role` VALUES (20, 20220015, 'user');
INSERT INTO `role` VALUES (21, 20220016, 'user');
INSERT INTO `role` VALUES (22, 20220017, 'user');
INSERT INTO `role` VALUES (23, 20220018, 'user');
INSERT INTO `role` VALUES (24, 20220019, 'user');
INSERT INTO `role` VALUES (25, 20220020, 'user');
INSERT INTO `role` VALUES (26, 20220021, 'user');
INSERT INTO `role` VALUES (27, 20220022, 'user');
INSERT INTO `role` VALUES (28, 20220023, 'user');
INSERT INTO `role` VALUES (29, 20220024, 'user');
INSERT INTO `role` VALUES (30, 20220025, 'user');
INSERT INTO `role` VALUES (31, 20220026, 'user');
INSERT INTO `role` VALUES (32, 20220027, 'user');
INSERT INTO `role` VALUES (33, 20220028, 'user');
INSERT INTO `role` VALUES (34, 20220029, 'user');
INSERT INTO `role` VALUES (35, 20220030, 'user');
INSERT INTO `role` VALUES (36, 20220031, 'user');
INSERT INTO `role` VALUES (37, 20220032, 'user');
INSERT INTO `role` VALUES (38, 20220033, 'user');
INSERT INTO `role` VALUES (39, 20220033, 'manager');
INSERT INTO `role` VALUES (40, 20220034, 'user');
INSERT INTO `role` VALUES (41, 20220035, 'user');
INSERT INTO `role` VALUES (42, 20220036, 'user');
INSERT INTO `role` VALUES (43, 20220037, 'user');
INSERT INTO `role` VALUES (44, 20220038, 'user');
INSERT INTO `role` VALUES (45, 20220038, 'manager');
INSERT INTO `role` VALUES (46, 20220039, 'user');
INSERT INTO `role` VALUES (47, 20220040, 'user');
INSERT INTO `role` VALUES (48, 20220040, 'manager');
INSERT INTO `role` VALUES (49, 20220041, 'user');
INSERT INTO `role` VALUES (50, 20220042, 'user');
INSERT INTO `role` VALUES (51, 20220042, 'manager');

-- ----------------------------
-- Table structure for role_authority
-- ----------------------------
DROP TABLE IF EXISTS `role_authority`;
CREATE TABLE `role_authority`  (
  `id` int NOT NULL,
  `role` smallint NOT NULL,
  `authority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_authority
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'a593bdcc9de7175ecb106c7428c97191f1509fb5',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `role` smallint NOT NULL,
  `department` smallint NULL DEFAULT NULL,
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '1' COMMENT '0：未入职，1：在职，2：离职',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` smallint NOT NULL DEFAULT 2 COMMENT '0：男，1：女, 2: 未知',
  `birthday` date NULL DEFAULT NULL,
  `hiredate` date NULL DEFAULT NULL COMMENT '入职时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20220043 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (20220001, 'a0c5d6d657ee80c1d009ab9c9286920022c38e2a', '792734338@qq.com', 0, 0, '1', 'http://remz9wszw.hn-bkt.clouddn.com/1268e97f-140d-4714-a959-fd4955d37a649.jpg', '蔡文姬', 0, '2022-07-06', '2008-07-23');
INSERT INTO `user` VALUES (20220002, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', '', 1, 1, '1', 'https://img1.imgtp.com/2022/06/28/tTyUjdi1.png', '貂蝉', 1, '1998-07-23', '2009-10-01');
INSERT INTO `user` VALUES (20220003, 'a0c5d6d657ee80c1d009ab9c9286920022c38e2a', '792734338@qq.com', 1, 2, '1', 'http://remz9wszw.hn-bkt.clouddn.com/ecc9d952-1d3d-4111-9802-b4b38b7aaa231.jpg', '孙膑', 1, '1991-07-10', '2020-04-24');
INSERT INTO `user` VALUES (20220004, 'a0c5d6d657ee80c1d009ab9c9286920022c38e2a', 'eyesyeager@163.com', 2, 1, '1', 'https://img1.imgtp.com/2022/06/28/Ez1kKMFb.png', '露娜', 1, '2001-02-22', '2020-10-23');
INSERT INTO `user` VALUES (20220008, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '武则天', 2, NULL, '2022-07-10');
INSERT INTO `user` VALUES (20220009, 'a0c5d6d657ee80c1d009ab9c9286920022c38e2a', '704885156@qq.com', 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '猪八戒', 1, '2022-06-01', '2022-07-10');
INSERT INTO `user` VALUES (20220010, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '廉颇', 2, NULL, '2022-07-10');
INSERT INTO `user` VALUES (20220011, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 1, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '小乔', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220012, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 1, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '张华', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220013, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 1, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '肖梦', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220014, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 1, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '赵六', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220015, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '万九', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220016, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 0, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '黄忠', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220017, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '关羽', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220018, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '刘备', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220019, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '司马懿', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220020, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '曹操', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220021, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 4, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '孙权', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220022, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 4, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '孙坚', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220023, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '王明', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220024, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '吴无', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220025, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '武松', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220026, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '宋江', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220027, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '武大郎', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220028, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '孙维', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220029, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 0, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '苏敏', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220030, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 4, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '张伟丽', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220031, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, NULL, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '嘎子', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220032, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '夏洛特', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220033, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, NULL, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '司空震', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220034, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, NULL, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '宇文骏', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220035, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '李华', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220036, '6092f112979950c9f165d08689205e4675861528', '3274333659@qq.com', 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '李元霸', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220037, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 0, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '李世民', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220038, '851a9b47842998375605e5489e0e4d041a7b60b1', '691008314@qq.com', 1, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '朱元璋', 1, '2022-07-12', '2022-07-13');
INSERT INTO `user` VALUES (20220039, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 3, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '郑和', 2, NULL, '2022-07-13');
INSERT INTO `user` VALUES (20220040, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 1, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '王明', 2, NULL, '2022-07-14');
INSERT INTO `user` VALUES (20220041, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 2, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '小', 2, NULL, '2022-07-14');
INSERT INTO `user` VALUES (20220042, 'a593bdcc9de7175ecb106c7428c97191f1509fb5', NULL, 1, 2, '1', 'https://img1.imgtp.com/2022/06/28/Clyhp5rj.png', '李强', 2, NULL, '2022-07-14');

-- ----------------------------
-- Table structure for weekly
-- ----------------------------
DROP TABLE IF EXISTS `weekly`;
CREATE TABLE `weekly`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `signature` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '本周签单',
  `money` double NULL DEFAULT NULL COMMENT '本周回款',
  `project` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '本周项目跟踪',
  `other_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '其他相关工作内容',
  `next_week_work` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '下周工作内容',
  `problem_and_think` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '问题与思考',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `create_time` date NOT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `week_flag` date NOT NULL COMMENT '哪一周',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10000023 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of weekly
-- ----------------------------
INSERT INTO `weekly` VALUES (10000000, 20220001, '签单数量一', 10000, '进度80%', '项目收尾阶段', '与科大国创公司合作事宜', '暂无', '绩效B', '2022-07-04', '2022-07-07 10:20:47', '2022-01-03');
INSERT INTO `weekly` VALUES (10000001, 20220002, '签单数量二', 20000, '进度75.5%', '项目需加快进度', '继续上周工作', '暂无', '绩效C', '2022-07-08', '2022-07-09 15:00:25', '2022-07-08');
INSERT INTO `weekly` VALUES (10000002, 20220003, '签单数量三', 254000, '进度30%', '项目进度良好', '与科大国创公司进行相关技术对接', '有关后端go语言的开发环境不兼容问题', '绩效A+', '2022-06-09', '2022-06-11 15:16:34', '2022-06-06');
INSERT INTO `weekly` VALUES (10000003, 20220004, '签单数量四', 380000, '进度100%', '项目已完成', '暂无', '暂无', '绩效A', '2022-05-04', '2022-05-06 15:18:46', '2022-05-02');
INSERT INTO `weekly` VALUES (10000004, 20220001, '签单数量二', 120000, '进度60%', '项目正常进行', '继续该项目', '客户需更改需要，要采用新的技术栈', '绩效B', '2022-04-14', '2022-04-15 15:31:54', '2022-04-11');
INSERT INTO `weekly` VALUES (10000005, 20220003, '签单数量零', 600000, '进度80%', '项目正常进行', '截至下周五完成该项目', '与思科下周签订合同', '绩效A+', '2022-05-26', '2022-05-27 15:34:32', '2022-05-23');
INSERT INTO `weekly` VALUES (10000006, 20220002, '签单数量五', 320000, '项目进度5%', '项目起步阶段', '继续项目开发', '关注新项目的开发技术问题', '绩效A+', '2022-06-28', '2022-07-01 15:37:41', '2022-06-27');
INSERT INTO `weekly` VALUES (10000007, 20220003, '签单数量一', 10000000, '项目进度50%', '项目开发周期中', '继续该项目开发任务', '暂无', '绩效A', '2022-03-14', '2022-03-18 15:39:32', '2022-03-14');
INSERT INTO `weekly` VALUES (10000008, 20220004, '签单数量三', 2000000, '项目进度100%', '项目已完成', '与客户做好产品对接', '暂无', '绩效B', '2022-05-03', '2022-05-06 15:41:16', '2022-05-02');
INSERT INTO `weekly` VALUES (10000009, 20220003, '签单数量一', 30000, '项目进度20%', '项目开发阶段', '继续该项目开发任务', '暂无', '绩效C', '2022-02-09', '2022-02-11 15:42:56', '2022-02-07');
INSERT INTO `weekly` VALUES (10000010, 20220004, '签单数量零', 400000, '项目进度90%', '项目收尾阶段', '尽快完成项目收尾', '产品与部分手机型号不兼容问题', '绩效B+', '2022-05-18', '2022-05-20 15:44:58', '2022-05-16');
INSERT INTO `weekly` VALUES (10000014, 20220001, '签单数量一', 32400, '项目进度85%', '项目进度良好', '开始项目收尾工作', '暂无', '绩效B+', '2022-07-13', NULL, '2022-05-30');
INSERT INTO `weekly` VALUES (10000015, 20220003, '签单数量四', 400000, '项目进度40%', '项目进度良好', '继续项目开发工作', '暂无', '绩效A', '2022-07-13', NULL, '2022-07-05');
INSERT INTO `weekly` VALUES (10000016, 20220038, '签单数量二', 270000, '项目进度75%', '项目进度正常', '项目开始收尾', '尽快完成产品上线', '绩效B', '2022-07-13', NULL, '2022-07-04');
INSERT INTO `weekly` VALUES (10000017, 20220038, '签单数量零', 90000, '项目进度65%', '项目进度过慢', '尽快解决项目bug', '截止下周完成项目调试', '绩效C', '2022-07-13', NULL, '2022-07-04');
INSERT INTO `weekly` VALUES (10000018, 20220038, '签单数量三', 340000, '项目进度30%', '项目进度正常', '继续本周未完成的项目开发工作', '开始项目的黑盒测试', '', '2022-07-13', NULL, '2022-07-12');
INSERT INTO `weekly` VALUES (10000019, 20220009, '签单数量一', 340000, '项目进度90%', '项目收尾阶段', '尽快完成项目收尾', '暂无', '绩效B', '2022-07-08', NULL, '2022-07-04');
INSERT INTO `weekly` VALUES (10000020, 20220009, '签单数量三', 200000, '项目进度50%', '项目正常进行', '继续该项目开发任务', '暂无', '绩效A', '2022-06-14', '2022-06-16 11:08:43', '2022-06-13');
INSERT INTO `weekly` VALUES (10000021, 20220001, '0', 0, '无', '无', '无', '无', '', '2022-07-14', NULL, '2022-07-05');
INSERT INTO `weekly` VALUES (10000022, 20220001, '0', 0, '无', '无', '无', '无', '', '2022-07-14', NULL, '2022-07-05');

-- ----------------------------
-- Table structure for weekly_attendance
-- ----------------------------
DROP TABLE IF EXISTS `weekly_attendance`;
CREATE TABLE `weekly_attendance`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `weekly_id` int NOT NULL,
  `weekday` int NOT NULL COMMENT '周几',
  `attendance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20220173 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of weekly_attendance
-- ----------------------------
INSERT INTO `weekly_attendance` VALUES (20220103, 10000000, 1, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220104, 10000000, 2, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220105, 10000000, 3, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220106, 10000000, 4, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220107, 10000000, 5, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220108, 10000000, 6, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220109, 10000000, 7, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220124, 10000014, 1, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220125, 10000014, 2, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220126, 10000014, 3, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220127, 10000014, 4, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220128, 10000014, 5, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220129, 10000014, 6, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220130, 10000014, 7, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220131, 10000015, 1, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220132, 10000015, 2, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220133, 10000015, 3, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220134, 10000015, 4, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220135, 10000015, 5, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220136, 10000015, 6, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220137, 10000015, 7, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220138, 10000016, 1, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220139, 10000016, 2, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220140, 10000016, 3, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220141, 10000016, 4, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220142, 10000016, 5, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220143, 10000016, 6, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220144, 10000016, 7, '武汉分公司');
INSERT INTO `weekly_attendance` VALUES (20220145, 10000017, 1, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220146, 10000017, 2, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220147, 10000017, 3, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220148, 10000017, 4, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220149, 10000017, 5, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220150, 10000017, 6, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220151, 10000017, 7, '上海分公司');
INSERT INTO `weekly_attendance` VALUES (20220152, 10000001, 1, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220153, 10000001, 2, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220154, 10000001, 3, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220155, 10000001, 4, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220156, 10000001, 5, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220157, 10000001, 6, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220158, 10000001, 7, '总部公司大厦');
INSERT INTO `weekly_attendance` VALUES (20220159, 10000021, 1, '1');
INSERT INTO `weekly_attendance` VALUES (20220160, 10000021, 2, '');
INSERT INTO `weekly_attendance` VALUES (20220161, 10000021, 3, '');
INSERT INTO `weekly_attendance` VALUES (20220162, 10000021, 4, '');
INSERT INTO `weekly_attendance` VALUES (20220163, 10000021, 5, '');
INSERT INTO `weekly_attendance` VALUES (20220164, 10000021, 6, '');
INSERT INTO `weekly_attendance` VALUES (20220165, 10000021, 7, '');
INSERT INTO `weekly_attendance` VALUES (20220166, 10000022, 1, '1');
INSERT INTO `weekly_attendance` VALUES (20220167, 10000022, 2, '');
INSERT INTO `weekly_attendance` VALUES (20220168, 10000022, 3, '');
INSERT INTO `weekly_attendance` VALUES (20220169, 10000022, 4, '');
INSERT INTO `weekly_attendance` VALUES (20220170, 10000022, 5, '');
INSERT INTO `weekly_attendance` VALUES (20220171, 10000022, 6, '');
INSERT INTO `weekly_attendance` VALUES (20220172, 10000022, 7, '');

-- ----------------------------
-- Table structure for weekly_comment
-- ----------------------------
DROP TABLE IF EXISTS `weekly_comment`;
CREATE TABLE `weekly_comment`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `weekly_id` int NOT NULL COMMENT '点评周报id',
  `user_id` int NOT NULL COMMENT '点评人id',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` int NOT NULL COMMENT '0：正常、1：删除',
  `create_time` timestamp NOT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `delete_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7080955 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of weekly_comment
-- ----------------------------
INSERT INTO `weekly_comment` VALUES (7080940, 10000000, 20220001, '已知悉，尽快汇报下周工作计划', 0, '2022-01-04 09:40:59', '2022-01-05 12:41:25', '2022-07-07 09:41:36');
INSERT INTO `weekly_comment` VALUES (7080941, 10000001, 20220001, '这是一次测试评论', 0, '2022-07-12 10:33:33', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080942, 10000000, 20220001, '已分配新任务，望及时调整', 0, '2022-07-12 14:50:46', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080943, 10000000, 20220001, '已知悉', 0, '2022-07-13 12:06:51', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080944, 10000000, 20220001, '已阅', 0, '2022-07-13 12:10:10', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080945, 10000000, 20220003, '已阅', 0, '2022-07-13 17:43:42', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080946, 10000000, 20220038, '一看', 0, '2022-07-13 19:20:02', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080947, 10000000, 20220038, '', 0, '2022-07-13 19:22:29', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080948, 10000000, 20220038, '辛苦了', 0, '2022-07-13 19:24:04', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080949, 10000001, 20220001, '第二次评论', 0, '2022-07-14 15:01:08', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080950, 10000001, 20220001, '第三次评论', 0, '2022-07-14 15:01:25', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080951, 10000000, 20220001, '请及时更新', 0, '2022-07-14 15:29:33', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080952, 10000002, 20220003, 'bbb', 0, '2022-07-14 17:07:47', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080953, 10000001, 20220001, '第四次', 0, '2022-07-15 08:32:46', NULL, NULL);
INSERT INTO `weekly_comment` VALUES (7080954, 10000001, 20220001, '2131331', 0, '2022-07-15 09:39:22', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
