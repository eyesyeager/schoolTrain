package com.eyes.train.constants;

/**
 * @author eyesYeager
 * @date 2023/6/23 17:41
 */

public class AuthConstants {
  public static final String AUTH_HEADER = "token";

  public static final String USER_ID = "userId";

  public static final String SECRET_KEY = "train";

  public static final String MDC_USER = "userId";
}
