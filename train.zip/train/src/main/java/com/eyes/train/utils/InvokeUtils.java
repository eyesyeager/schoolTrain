package com.eyes.train.utils;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @author eyesYeager
 * @date 2023/6/29 23:13
 */
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * @author eyesYeager
 * @date 2023/6/29 23:30
 */
public class InvokeUtils {

  /**
   * post调用
   *
   * @param url
   * @param jsonString
   * @return
   */
  public static String postInvoke(String url, String jsonString) {
    return invoke(url, jsonString, null, RequestMethod.POST);
  }

  /**
   * get调用
   *
   * @param url
   * @return
   */
  public static String getInvoke(String url) {
    return invoke(url, null, null, RequestMethod.GET);
  }

  /**
   * 通用
   *
   * @param url
   * @param jsonString
   * @param token
   * @param requestMethod
   * @return
   */
  public static String invoke(String url, String jsonString, String token, RequestMethod requestMethod) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.parseMediaType("application/json; charset=UTF-8"));
    headers.add("Accept", MediaType.APPLICATION_JSON.toString());
    if (!StringUtils.isEmpty(token)) {
      headers.add("Authorization", token);
    }
    HttpEntity<String> httpEntity;

    if (!StringUtils.isEmpty(jsonString)) {
      httpEntity = new HttpEntity<>(jsonString, headers);
    } else {
      httpEntity = new HttpEntity<>("parameters", headers);
    }
    RestTemplate rst = new RestTemplate();
    ResponseEntity<String> responseEntity = null;

    if (RequestMethod.POST.equals(requestMethod)) {
      try {
        responseEntity = rst.postForEntity(url, httpEntity, String.class);
      } catch (Exception e) {
        return e.getMessage();
      }
      return responseEntity.getBody();
    }
    try {
      responseEntity = rst.exchange(url, HttpMethod.GET, httpEntity, String.class);
    } catch (Exception e) {
      return e.getMessage();
    }
    return responseEntity.getBody();
  }
}

