package com.eyes.train.model.BO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/28 23:09
 */
@Data
@ApiModel
public class TrafficBO {
  @ApiModelProperty("应用名")
  private String name;

  @ApiModelProperty("流量")
  private Double traffic;
}
