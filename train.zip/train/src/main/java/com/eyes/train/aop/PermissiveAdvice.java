package com.eyes.train.aop;

import com.eyes.train.annotate.Permission;
import com.eyes.train.constants.AuthConstants;
import com.eyes.train.exception.AuthException;
import com.eyes.train.exception.CustomException;
import com.eyes.train.result.ResultCode;
import com.eyes.train.utils.JwtUtils;
import com.eyes.train.utils.WebUtils;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * @author eyesYeager
 * @date 2023/6/23 17:44
 */
@Aspect
@Component
@Slf4j
public class PermissiveAdvice {
  @Before("@annotation(com.eyes.train.annotate.Permission)")
  public void before(JoinPoint joinPoint) {
    HttpServletRequest request = WebUtils.getRequest();
    assert request != null;
    String token = request.getHeader(AuthConstants.AUTH_HEADER);
    if (StringUtils.isEmpty(token)) {
      throw new AuthException(ResultCode.NOT_LOGIN);
    }

    try {
      JwtUtils.getUserIdByJwtToken(token);
    } catch (ExpiredJwtException e) {
      Claims claims = e.getClaims();
      Integer uid = JwtUtils.getUserIdByClaims(claims);
      MDC.put(AuthConstants.MDC_USER, String.valueOf(uid));
    } catch (Exception e) {
      throw new AuthException(ResultCode.ILLEGAL_TOKEN);
    }
  }
}
