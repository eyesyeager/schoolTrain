package com.eyes.train.exception;

import com.eyes.train.result.ResultCode;
import lombok.ToString;

/**
 * @author eyesYeager
 * @date 2023/6/23 19:43
 */
@ToString
public class AuthException extends RuntimeException {
  protected final Integer errorCode;

  protected final String errorMsg;

  public AuthException() {
    this.errorCode = ResultCode.FAILURE.getCode();
    this.errorMsg = ResultCode.FAILURE.getMessage();
  }

  public AuthException(String errorMsg) {
    this.errorCode = ResultCode.FAILURE.getCode();
    this.errorMsg = errorMsg;
  }

  public AuthException(Integer errorCode, String errorMsg) {
    this.errorCode = errorCode;
    this.errorMsg = errorMsg;
  }

  public AuthException(ResultCode resultCode) {
    this.errorCode = resultCode.getCode();
    this.errorMsg = resultCode.getMessage();
  }

  public Integer getErrorCode() {
    return errorCode;
  }

  public String getErrorMsg() {
    return errorMsg;
  }
}
