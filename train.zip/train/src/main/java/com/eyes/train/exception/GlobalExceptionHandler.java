package com.eyes.train.exception;

import com.eyes.train.result.Result;
import com.eyes.train.result.ResultCode;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:14
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
  /**
   * 自定义异常
   * @param e CustomException
   * @return Result<Void>
   */
  @ExceptionHandler(value = CustomException.class)
  @ResponseBody
  public Result<Void> error(CustomException e) {
    log.warn("CustomException: {}", e.getErrorMsg());
    return Result.fail(e.getErrorCode(), e.getErrorMsg());
  }

  /**
   * 未知异常
   * @param e Exception
   * @return Result<Void>
   */
  @ExceptionHandler(value = Exception.class)
  @ResponseBody
  public Result<Void> error(Exception e) {
    log.error("未知异常:{}", e.getMessage());
    e.printStackTrace();
    return Result.fail();
  }

  /**
   * 权限异常
   * @param e AuthException
   * @return Result<Void>
   */
  @ExceptionHandler(value = AuthException.class)
  @ResponseBody
  public Result<Void> error(AuthException e) {
    log.error("权限异常:{}", e.getErrorMsg());
    return Result.fail(e.getErrorCode(), e.getErrorMsg());
  }

  /**
   * 日期格式异常
   * @param e HttpMessageNotReadableException
   * @return Result<Void>
   */
  @ExceptionHandler(value = HttpMessageNotReadableException.class)
  @ResponseBody
  public Result<Void> error(HttpMessageNotReadableException e) {
    log.error("日期格式异常:{}", e.getMessage());
    return Result.fail(ResultCode.FAILURE.getCode(), "日期格式错误");
  }


  /**
   * 验证异常(controller中使用注解)
   * @param e ConstraintViolationException
   * @return Result<Void>
   */
  @ExceptionHandler(value = ConstraintViolationException.class)
  @ResponseBody
  public Result<Void> error(ConstraintViolationException e) {
    StringBuffer errorMsg = new StringBuffer();
    e.getConstraintViolations().forEach((v) -> errorMsg.append(v.getMessage()).append(";"));
    log.warn("controller验证异常：{}", errorMsg);
    return Result.fail(errorMsg.toString());
  }

  /**
   * 验证异常(module中使用注解)
   * @param e MethodArgumentNotValidException
   * @return Result<Void>
   */
  @ExceptionHandler(value = MethodArgumentNotValidException.class)
  @ResponseBody
  public Result<Void> error(MethodArgumentNotValidException e) {
    List<ObjectError> allErrors = e.getBindingResult().getAllErrors();
    String message = allErrors.stream()
        .map(DefaultMessageSourceResolvable::getDefaultMessage)
        .collect(Collectors.joining(";"));
    log.warn("module验证异常：{}", message);
    return Result.fail(message);
  }
}
