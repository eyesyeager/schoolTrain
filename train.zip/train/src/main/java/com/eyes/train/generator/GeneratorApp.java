package com.eyes.train.generator;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.po.TableFill;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;

import java.util.ArrayList;
import java.util.Scanner;

public class GeneratorApp {
  public static String scanner(String tip) {
    Scanner scanner = new Scanner(System.in);
    StringBuilder help = new StringBuilder();
    help.append("请输入" + tip + "：");
    System.out.println(help.toString());
    if (scanner.hasNext()) {
      String ipt = scanner.next();
      if (StringUtils.isNotBlank(ipt)) {
        return ipt;
      }
    }
    throw new MybatisPlusException("请输入正确的" + tip + "！");
  }





  public static void main(String[] args) {
    // 代码生成器
    AutoGenerator mpg = new AutoGenerator();

    // 全局配置
    GlobalConfig gc = new GlobalConfig();
    String projectPath = System.getProperty("user.dir");
    gc.setOutputDir(projectPath + "/src/main/java");
    gc.setFileOverride(true);
    gc.setOpen(false);
    gc.setAuthor("eyesYeager");
    gc.setIdType(IdType.AUTO);
    gc.setBaseResultMap(true);
    gc.setBaseColumnList(true);
    gc.setServiceName("%sService");
    gc.setDateType(DateType.ONLY_DATE);
    mpg.setGlobalConfig(gc);

    // 数据源配置
    DataSourceConfig dsc = new DataSourceConfig();
    dsc.setUrl("jdbc:mysql://cn-cd-dx-8.natfrp.cloud:59472/train?useUnicode=true&characterEncoding=utf-8&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=GMT%2B8");
    dsc.setDriverName("com.mysql.cj.jdbc.Driver");
    dsc.setUsername("train");
    dsc.setPassword("train");
    mpg.setDataSource(dsc);

    // 包配置
    PackageConfig pc = new PackageConfig();
    pc.setParent("com.eyes");
    pc.setMapper("mapper");
    pc.setXml("mapper.xml");
    pc.setEntity("entity");
    pc.setService("service");
    pc.setServiceImpl("service.impl");
    pc.setController("controller");
    mpg.setPackageInfo(pc);

    // 策略配置
    StrategyConfig sc = new StrategyConfig();
    sc.setNaming(NamingStrategy.underline_to_camel);
    sc.setColumnNaming(NamingStrategy.underline_to_camel);
    sc.setEntityLombokModel(true);
    sc.setRestControllerStyle(true);
    sc.setControllerMappingHyphenStyle(true);

    sc.setLogicDeleteFieldName("deleted");

    // 设置自动填充配置
    TableFill gmt_create = new TableFill("create_time", FieldFill.INSERT);
    TableFill gmt_modified = new TableFill("update_time", FieldFill.INSERT_UPDATE);
    ArrayList<TableFill> tableFills=new ArrayList<>();
    tableFills.add(gmt_create);
    tableFills.add(gmt_modified);
    sc.setTableFillList(tableFills);

    // 乐观锁
//    sc.setVersionFieldName("version");
//    sc.setRestControllerStyle(true);

    sc.setInclude(scanner("表名，多个英文逗号分割").split(","));
    mpg.setStrategy(sc);

    // 生成代码
    mpg.execute();
  }
}