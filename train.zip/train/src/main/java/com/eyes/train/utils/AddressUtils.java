package com.eyes.train.utils;

import com.alibaba.fastjson.JSON;
import java.io.IOException;
import java.util.Objects;
import javax.annotation.Resource;
import lombok.Data;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

/**
 * @author eyesYeager
 * @date 2023/6/29 22:39
 */
public class AddressUtils {
  private static final String API_URL = "http://whois.pconline.com.cn/ipJson.jsp?json=true&ip=";

  public static String getAddresses(String ip) throws IOException {
    String response = InvokeUtils.getInvoke(API_URL + ip);
    System.out.println(response);
    if (Objects.nonNull(response)) {
      AddressResponse addressResponse = JSON.parseObject(response, AddressResponse.class);
      return addressResponse.getPro() + " " + addressResponse.getCity();
    }
    return "";
  }

  @Data
  public static class AddressResponse {
    private String ip;

    private String pro;

    private String proCode;

    private String city;

    private String cityCode;

    private String region;

    private String regionCode;

    private String addr;

    private String regionNames;

    private String err;
  }
}
