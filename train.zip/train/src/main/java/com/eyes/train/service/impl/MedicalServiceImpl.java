package com.eyes.train.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eyes.train.entity.Medical;
import com.eyes.train.mapper.MedicalMapper;
import com.eyes.train.service.MedicalService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-27
 */
@Service
public class MedicalServiceImpl extends ServiceImpl<MedicalMapper, Medical> implements MedicalService {

}
