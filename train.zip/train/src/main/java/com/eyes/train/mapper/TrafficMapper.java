package com.eyes.train.mapper;

import com.eyes.train.entity.Traffic;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-28
 */
@Mapper
public interface TrafficMapper extends BaseMapper<Traffic> {

}
