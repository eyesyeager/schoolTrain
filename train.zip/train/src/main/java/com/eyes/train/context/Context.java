package com.eyes.train.context;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.stereotype.Component;

/**
 * @author eyesYeager
 * @date 2023/6/23 14:01
 */
@Data
@Component
public class Context {
  @Value("${context.static-path}")
  private String staticPath;

  @Value("${context.speed-file}")
  private String speedFile;

  @Value("${context.file-path}")
  private String filePath;
}
