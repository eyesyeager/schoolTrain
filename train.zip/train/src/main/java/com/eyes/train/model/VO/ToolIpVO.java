package com.eyes.train.model.VO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:19
 */
@Data
@ApiModel
@AllArgsConstructor
public class ToolIpVO {
  @ApiModelProperty("ip地址")
  private String ip;

  @ApiModelProperty("地理位置地址")
  private String address;
}
