package com.eyes.train.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.eyes.train.entity.Medical;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-27
 */
@Mapper
public interface MedicalMapper extends BaseMapper<Medical> {

}
