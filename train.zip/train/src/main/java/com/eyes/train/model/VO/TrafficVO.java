package com.eyes.train.model.VO;

import com.eyes.train.model.BO.TrafficBO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/28 23:07
 */
@Data
@ApiModel
@AllArgsConstructor
public class TrafficVO {
  @ApiModelProperty("上传流量")
  private List<TrafficBO> upload;

  @ApiModelProperty("下载流量")
  private List<TrafficBO> download;
}
