package com.eyes.train.model.VO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/23 20:57
 */
@Data
@ApiModel
@AllArgsConstructor
public class PackageCheckUpdateVO {
  @ApiModelProperty("最新版本号")
  private String version;
}
