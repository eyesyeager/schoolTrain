package com.eyes.train.service;

import com.eyes.train.entity.Speed;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-28
 */
public interface SpeedService extends IService<Speed> {

}
