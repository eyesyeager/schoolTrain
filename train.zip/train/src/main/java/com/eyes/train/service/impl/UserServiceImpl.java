package com.eyes.train.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.eyes.train.constants.AuthConstants;
import com.eyes.train.entity.User;
import com.eyes.train.exception.CustomException;
import com.eyes.train.mapper.UserMapper;
import com.eyes.train.model.Request.UserLoginRequest;
import com.eyes.train.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eyes.train.utils.JwtUtils;
import com.eyes.train.utils.WebUtils;
import java.util.HashMap;
import java.util.Objects;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

  @Override
  public void login(UserLoginRequest userLoginRequest, HttpServletResponse response) throws CustomException {
    // 登录校验
    User user = getOne(Wrappers.<User>lambdaQuery().eq(User::getUsername, userLoginRequest.getUsername()));
    if (Objects.isNull(user)) {
      throw new CustomException("用户不存在");
    }
    String encryptedPassword = DigestUtils.md5DigestAsHex(userLoginRequest.getPassword().getBytes());
    if (!encryptedPassword.equals(user.getPassword())) {
      throw new CustomException("密码错误");
    }

    // 生成令牌
    String jwtToken = JwtUtils.createJwtToken(user.getId());
    WebUtils.setResponse(new HashMap<String, String>(2){{
      put(AuthConstants.AUTH_HEADER, jwtToken);
      put("Access-Control-Expose-Headers", AuthConstants.AUTH_HEADER);
    }});
  }
}
