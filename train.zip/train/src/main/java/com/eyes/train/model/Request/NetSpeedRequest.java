package com.eyes.train.model.Request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/28 0:55
 */
@Data
@ApiModel
public class NetSpeedRequest {
  @ApiModelProperty("上传速度")
  @NotNull(message = "上传速度不能为空")
  private Double upload;

  @ApiModelProperty("下载速度")
  @NotNull(message = "下载速度不能为空")
  private Double download;
}
