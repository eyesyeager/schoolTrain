package com.eyes.train.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:55
 */

public class StreamUtils {
  public static byte[] file2byte(InputStream is) {
    byte[] buffer = null;
    try {
      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      byte[] b = new byte[1024];
      int n;
      while ((n = is.read(b)) != -1) {
        bos.write(b, 0, n);
      }
      is.close();
      bos.close();
      buffer = bos.toByteArray();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return buffer;
  }
}
