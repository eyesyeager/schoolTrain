package com.eyes.train.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
@Data
@Accessors(chain = true)
public class Configure {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private Integer userId;

    @TableField("enabledAutoCheckUpdate")
    private Boolean enabledAutoCheckUpdate;

    @TableField("enabledAutoCheckup")
    private Boolean enabledAutoCheckup;

    @TableField("enabledAutoOptimizeNet")
    private Boolean enabledAutoOptimizeNet;

    @TableField("needSaveCheckupReport")
    private Boolean needSaveCheckupReport;

    @TableField("needSaveSpeedMeasureReport")
    private Boolean needSaveSpeedMeasureReport;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
