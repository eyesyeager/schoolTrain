package com.eyes.train.model.BO;

import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/23 19:53
 */
@Data
public class ConfigureBO {
  private Boolean enabledAutoCheckUpdate;

  private Boolean enabledAutoCheckup;

  private Boolean enabledAutoOptimizeNet;

  private Boolean needSaveCheckupReport;

  private Boolean needSaveNetOptimizeReport;

  private Boolean needSaveSpeedMeasureReport;
}
