package com.eyes.train.service;

import com.eyes.train.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.Request.UserLoginRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
public interface UserService extends IService<User> {
  void login(UserLoginRequest userLoginRequest, HttpServletResponse response) throws CustomException;
}
