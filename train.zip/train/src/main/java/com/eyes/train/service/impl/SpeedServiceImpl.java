package com.eyes.train.service.impl;

import com.eyes.train.entity.Speed;
import com.eyes.train.mapper.SpeedMapper;
import com.eyes.train.service.SpeedService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-28
 */
@Service
public class SpeedServiceImpl extends ServiceImpl<SpeedMapper, Speed> implements SpeedService {

}
