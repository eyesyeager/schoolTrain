package com.eyes.train.service;

import com.eyes.train.entity.Traffic;
import com.baomidou.mybatisplus.extension.service.IService;
import com.eyes.train.model.Request.TrafficRequest;
import com.eyes.train.model.VO.TrafficVO;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-28
 */
public interface TrafficService extends IService<Traffic> {

  void addTrafficReport(Integer uid, List<TrafficRequest>trafficRequestList);

  TrafficVO getTrafficReport(Integer uid, String date);
}
