package com.eyes.train.model.Request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/23 19:28
 */
@Data
@ApiModel
public class ConfigureUpdateRequest {
  @ApiModelProperty("是否开机自动检查更新")
  private Boolean enabledAutoCheckUpdate;

  @ApiModelProperty("是否开机自动体检")
  private Boolean enabledAutoCheckup;

  @ApiModelProperty("是否开机自动优化网络")
  private Boolean enabledAutoOptimizeNet;

  @ApiModelProperty("是否需要自动保存网络体检报告")
  private Boolean needSaveCheckupReport;

  @ApiModelProperty("是否需要自动保存网络测速报告")
  private Boolean needSaveSpeedMeasureReport;
}
