package com.eyes.train.utils;

import com.eyes.train.constants.AuthConstants;
import io.jsonwebtoken.*;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;

/**
 * @author eyesYeager
 * @date 2023/6/23 17:17
 */
@Slf4j
public class JwtUtils {
  private JwtUtils() {
    throw new UnsupportedOperationException("It is not recommended to instantiate this class. It is recommended to use static method calls");
  }

  /**
   * 生成token
   */
  public static String createJwtToken(Integer id) {
    return Jwts.builder()
        .setHeaderParam("typ", "JWT")
        .setHeaderParam("alg", "HS256")
        .setSubject("train")
        .setIssuer("eyes")
        .setIssuedAt(new Date())
        .setExpiration(new Date(System.currentTimeMillis()))
        .claim(AuthConstants.USER_ID, id)
        .signWith(SignatureAlgorithm.HS256, AuthConstants.SECRET_KEY)
        .compact();
  }

  /**
   * 从jwt中获取UserId
   * @param jwtToken token
   * @return ClaimModel
   */
  public static Integer getUserIdByJwtToken(String jwtToken) throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, IllegalArgumentException {
    Jws<Claims> claimsJws = Jwts.parser().setSigningKey(AuthConstants.SECRET_KEY).parseClaimsJws(jwtToken);
    Claims claims = claimsJws.getBody();
    return getUserIdByClaims(claims);
  }

  /**
   * 从claims中获取UserId
   * @param claims
   * @return
   */
  public static Integer getUserIdByClaims(Claims claims) {
    return (Integer)claims.get(AuthConstants.USER_ID);
  }
}