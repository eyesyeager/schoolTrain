package com.eyes.train.service;

import com.eyes.train.entity.Package;
import com.baomidou.mybatisplus.extension.service.IService;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.VO.PackageCheckUpdateVO;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
public interface PackageService extends IService<Package> {

  PackageCheckUpdateVO checkUpdate() throws CustomException;

  void uploadPackage(String version, MultipartFile multipartFile) throws CustomException;

  void downloadPackage() throws CustomException;
}
