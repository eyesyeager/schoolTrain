package com.eyes.train.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.eyes.train.annotate.Permission;
import com.eyes.train.constants.AuthConstants;
import com.eyes.train.entity.Medical;
import com.eyes.train.entity.Speed;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.Request.MedicalReportAddRequest;
import com.eyes.train.model.Request.NetSpeedRequest;
import com.eyes.train.model.Request.TrafficRequest;
import com.eyes.train.model.VO.MedicalReportVO;
import com.eyes.train.model.VO.TrafficVO;
import com.eyes.train.result.Result;
import com.eyes.train.result.ResultCode;
import com.eyes.train.service.MedicalService;
import com.eyes.train.service.SpeedService;
import com.eyes.train.service.TrafficService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:10
 */
@Api(tags = "日志模块")
@Validated
@RestController
@RequestMapping("/log")
public class LogController {
  private final static int PAGE_SIZE = 10;

  @Resource
  private MedicalService medicalService;

  @Resource
  private SpeedService speedService;

  @Resource
  private TrafficService trafficService;

  @ApiOperation("记录故障检测报告")
  @PostMapping("/addMedicalReport")
  @Permission
  public Result<Void> addMedicalReport(@Validated @RequestBody MedicalReportAddRequest medicalReportAddRequest) throws CustomException {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    Medical medical = new Medical();
    BeanUtils.copyProperties(medicalReportAddRequest, medical);
    medical.setUserId(uid);
    if (!medicalService.save(medical)) {
      throw new CustomException(ResultCode.ERROR_INSERT_DB);
    }
    return Result.success();
  }

  @ApiOperation("获取故障检测报告列表")
  @GetMapping("/getMedicalReportList")
  @Permission
  public Result<Page<Medical>> getMedicalReportList(@RequestParam(required = false) Integer page) {
    page = (Objects.isNull(page) || page < 1) ? 1 : page;
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    Page<Medical> pageData = medicalService.page(new Page<>(page, PAGE_SIZE), Wrappers.<Medical>lambdaQuery().eq(Medical::getUserId, uid).orderByDesc(Medical::getCreateTime));
    List<Medical> collect = pageData.getRecords().stream().peek(v -> v.setContent(null)).collect(Collectors.toList());
    pageData.setRecords(collect);
    return Result.success(pageData);
  }

  @ApiOperation("获取故障检测报告")
  @GetMapping("/getMedicalReport")
  @Permission
  public Result<MedicalReportVO> getMedicalReport(@NotNull(message = "报告id不能为空") @RequestParam("id") Integer id) throws CustomException {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    Medical medical = medicalService.getOne(Wrappers.<Medical>lambdaQuery().select(Medical::getContent).eq(Medical::getId, id).eq(Medical::getUserId, uid));
    if (Objects.isNull(medical)) {
      throw new CustomException("id为" + id + "的故障检测报告不存在");
    }
    return Result.success(new MedicalReportVO(medical.getContent()));
  }

  @ApiOperation("记录网络测速结果")
  @PostMapping("/addNetSpeedReport")
  @Permission
  public Result<Void> addNetSpeedReport(@Validated @RequestBody NetSpeedRequest netSpeedRequest) throws CustomException {
    if (netSpeedRequest.getDownload() < 0 || netSpeedRequest.getUpload() < 0) {
      throw new CustomException("网速不能为负");
    }

    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    Speed speed = new Speed();
    BeanUtils.copyProperties(netSpeedRequest, speed);
    speed.setUserId(uid);
    if (!speedService.save(speed)) {
      throw new CustomException(ResultCode.ERROR_INSERT_DB);
    }
    return Result.success();
  }

  @ApiOperation("获取网络测速结果列表")
  @GetMapping("/getNetSpeedReportList")
  @Permission
  public Result<Page<Speed>> getNetSpeedReportList(@RequestParam(required = false) Integer page) {
    page = (Objects.isNull(page) || page < 1) ? 1 : page;
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    Page<Speed> pageData = speedService.page(new Page<>(page, PAGE_SIZE), Wrappers.<Speed>lambdaQuery().eq(Speed::getUserId, uid).orderByDesc(Speed::getCreateTime));
    return Result.success(pageData);
  }

  @ApiOperation("记录流量数据")
  @PostMapping("/addTrafficReport")
  @Permission
  public Result<Void> addTrafficReport(@Validated @RequestBody List<TrafficRequest> trafficRequestList) {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    trafficService.addTrafficReport(uid, trafficRequestList);
    return Result.success();
  }

  @ApiOperation("获取流量数据列表")
  @GetMapping("/getTrafficReport")
  @Permission
  public Result<TrafficVO> getTrafficReport(@NotNull(message = "日期不能为空") @RequestParam("date") String date) {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    return Result.success(trafficService.getTrafficReport(uid, date));
  }
}