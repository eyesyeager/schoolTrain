package com.eyes.train.model.Request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/28 23:02
 */
@Data
@ApiModel
public class TrafficRequest {
  @ApiModelProperty("应用唯一标识")
  @NotBlank(message = "应用标识唯一不能为空")
  private String mark;

  @ApiModelProperty("应用名称")
  @NotBlank(message = "应用名称不能为空")
  private String name;

  @ApiModelProperty("上传流量")
  @NotNull(message = "上传流量不能为空")
  private Double upload;

  @ApiModelProperty("下载流量")
  @NotNull(message = "下载流量不能为空")
  private Double download;
}
