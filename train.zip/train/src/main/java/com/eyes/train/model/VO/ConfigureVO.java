package com.eyes.train.model.VO;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/23 19:04
 */
@Data
@ApiModel
public class ConfigureVO {
  @ApiModelProperty("是否开机自动检查更新")
  private Boolean enabledAutoCheckUpdate = false;

  @ApiModelProperty("是否开机自动体检")
  private Boolean enabledAutoCheckup = false;

  @ApiModelProperty("是否开机自动优化网络")
  private Boolean enabledAutoOptimizeNet = false;

  @ApiModelProperty("是否需要自动保存网络体检报告")
  private Boolean needSaveCheckupReport = false;

  @ApiModelProperty("是否需要自动保存网络测速报告")
  private Boolean needSaveSpeedMeasureReport = false;
}
