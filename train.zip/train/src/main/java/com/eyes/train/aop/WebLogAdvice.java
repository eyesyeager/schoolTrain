package com.eyes.train.aop;

import com.alibaba.fastjson.JSON;
import java.lang.reflect.Method;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

/**
 * @author eyesYeager
 * @date 2023/6/23 17:47
 */
@Aspect
@Component
@Slf4j
public class WebLogAdvice {
  /**
   * 打印日志,包括请求参数、返回结果、所耗时间
   * @param pjp ProceedingJoinPoint
   * @return Object
   */
  @Around("execution (* com.eyes.train.controller..*.*(..))")
  public Object around(ProceedingJoinPoint pjp) throws Throwable {
    MethodSignature signature = (MethodSignature) pjp.getSignature();
    Method method = signature.getMethod();
    Object[] args = pjp.getArgs();
    log.info("method: {}, paras: {}", method.getDeclaringClass() + "." + method.getName(), Arrays.toString(args));
    long start = System.currentTimeMillis();
    Object result = pjp.proceed();
    log.info("result: {}, time: {}", JSON.toJSON(result), System.currentTimeMillis() - start + "ms");
    return result;
  }
}