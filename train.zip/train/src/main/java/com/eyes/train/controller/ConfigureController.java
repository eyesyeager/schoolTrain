package com.eyes.train.controller;

import com.eyes.train.annotate.Permission;
import com.eyes.train.constants.AuthConstants;
import com.eyes.train.entity.Configure;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.Request.ConfigureUpdateRequest;
import com.eyes.train.model.VO.ConfigureVO;
import com.eyes.train.result.Result;
import com.eyes.train.service.ConfigureService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javax.annotation.Resource;
import javax.validation.constraints.NotBlank;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author eyesYeager
 * @since 2023-06-23
 */
@Api(tags = "配置模块")
@Validated
@RestController
@RequestMapping("/configure")
public class ConfigureController {

  @Resource
  private ConfigureService configureService;

  @ApiOperation("获取用户配置")
  @GetMapping
  @Permission
  public Result<ConfigureVO> getConfigure() throws CustomException {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    return Result.success(configureService.getConfigure(uid));
  }

  @ApiOperation("更新用户配置")
  @PutMapping
  @Permission
  public Result<Void> updateConfigure(@RequestBody ConfigureUpdateRequest configureUpdateRequest) {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    configureService.updateConfigure(uid, configureUpdateRequest);
    return Result.success();
  }

  @ApiOperation("检查配置更改")
  @GetMapping("/check")
  @Permission
  public Result<Void> check(@NotBlank(message = "md5值不能为空") String md5) throws CustomException {
    Integer uid = Integer.valueOf(MDC.get(AuthConstants.MDC_USER));
    configureService.check(uid, md5);
    return Result.success();
  }
}

