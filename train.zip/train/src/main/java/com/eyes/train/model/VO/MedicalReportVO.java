package com.eyes.train.model.VO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/28 0:08
 */
@Data
@ApiModel
@AllArgsConstructor
public class MedicalReportVO {
  @ApiModelProperty("报告详情")
  private String content;
}
