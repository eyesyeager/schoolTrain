package com.eyes.train.controller;

import com.eyes.train.annotate.Permission;
import com.eyes.train.context.Context;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.VO.PackageCheckUpdateVO;
import com.eyes.train.model.VO.ToolIpVO;
import com.eyes.train.result.Result;
import com.eyes.train.service.PackageService;
import com.eyes.train.utils.AddressUtils;
import com.eyes.train.utils.AddressUtils.AddressResponse;
import com.eyes.train.utils.IpUtils;
import com.eyes.train.utils.StreamUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:11
 */
@Api(tags = "工具模块")
@Validated
@RestController
@RequestMapping("/tool")
public class ToolController {
  @Resource
  private Context context;

  @Resource
  private PackageService packageService;

  @ApiOperation("获取用户ip地址")
  @GetMapping("/ip")
  public Result<ToolIpVO> ip(HttpServletRequest request) {
    String ip = IpUtils.getIpAddr(request);
    String address = "";
    try {
      address = AddressUtils.getAddresses(ip);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return Result.success(new ToolIpVO(ip, address));
  }

  @ApiOperation("测速——上传")
  @PostMapping("/uploadTest")
  public Result<Void> uploadTest(@RequestPart("file") MultipartFile multipartFile) {
    return Result.success();
  }

  @ApiOperation("测速——下载")
  @GetMapping("/downloadTest")
  public void speedDownloadTest(HttpServletResponse response) {
    try {
      InputStream is = this.getClass().getResourceAsStream(context.getStaticPath() + context.getSpeedFile());
      response.setCharacterEncoding("UTF-8");
      response.setContentType("application/x-download;charset=utf-8");
      OutputStream outputStream = response.getOutputStream();
      assert is != null;
      outputStream.write(StreamUtils.file2byte(is));
      outputStream.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @ApiOperation("检查应用更新")
  @GetMapping("/checkUpdate")
  public Result<PackageCheckUpdateVO> checkUpdate() throws CustomException {
    return Result.success(packageService.checkUpdate());
  }

  @ApiOperation("上传最新安装包")
  @Permission
  @PostMapping("/uploadPackage")
  public Result<Void> uploadPackage(
      @NotBlank(message = "版本号不能为空") String version,
      @RequestPart("file") MultipartFile multipartFile) throws CustomException {
    packageService.uploadPackage(version, multipartFile);
    return Result.success();
  }

  @ApiOperation("下载最新版安装包")
  @GetMapping("/downloadPackage")
  public void downloadPackage() throws CustomException {
    packageService.downloadPackage();
  }
}
