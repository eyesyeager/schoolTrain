package com.eyes.train.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.eyes.train.entity.Traffic;
import com.eyes.train.mapper.TrafficMapper;
import com.eyes.train.model.BO.TrafficBO;
import com.eyes.train.model.Request.TrafficRequest;
import com.eyes.train.model.VO.TrafficVO;
import com.eyes.train.service.TrafficService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-28
 */
@Service
public class TrafficServiceImpl extends ServiceImpl<TrafficMapper, Traffic> implements TrafficService {

  /**
   * 这个接口调用频率很高，这么做肯定是不对的，应该是批量操作，但是我懒得改了
   */
  @Override
  public void addTrafficReport(Integer uid, List<TrafficRequest> trafficRequestList) {
    Date date = new Date();
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    String strDate = df.format(date);
    trafficRequestList.forEach(v -> {
      Traffic traffic = getOne(Wrappers.<Traffic>lambdaQuery()
          .eq(Traffic::getUserId, uid)
          .eq(Traffic::getMark, v.getMark())
          .eq(Traffic::getDate, strDate));
      if (Objects.isNull(traffic)) {  // 插入数据
        traffic = new Traffic();
        BeanUtils.copyProperties(v, traffic);
        traffic.setUserId(uid);
        traffic.setDate(date);
        save(traffic);
      } else {  // 更新数据
        traffic.setUpload(traffic.getUpload() + v.getUpload());
        traffic.setDownload(traffic.getDownload() + v.getDownload());
        updateById(traffic);
      }
    });
  }

  @Override
  public TrafficVO getTrafficReport(Integer uid, String date) {
    List<Traffic> trafficList = baseMapper.selectList(Wrappers.<Traffic>lambdaQuery()
        .select(Traffic::getName, Traffic::getUpload, Traffic::getDownload)
        .eq(Traffic::getUserId, uid)
        .eq(Traffic::getDate, date)
        .orderByDesc(Traffic::getUpload)
    );
    if (CollectionUtils.isEmpty(trafficList)) {
      return new TrafficVO(Lists.newArrayList(), Lists.newArrayList());
    }

    List<TrafficBO> uploadTrafficBOList = trafficList.stream().map(v -> {
      TrafficBO trafficBO = new TrafficBO();
      trafficBO.setName(v.getName());
      trafficBO.setTraffic(v.getUpload());
      return trafficBO;
    }).collect(Collectors.toList());

    List<TrafficBO> downloadTrafficBOList = trafficList.stream()
        .sorted(Comparator.comparing(Traffic::getDownload).reversed()).map(v -> {
          TrafficBO trafficBO = new TrafficBO();
          trafficBO.setName(v.getName());
          trafficBO.setTraffic(v.getDownload());
          return trafficBO;
        }).collect(Collectors.toList());

    return new TrafficVO(uploadTrafficBOList, downloadTrafficBOList);
  }
}
