package com.eyes.train.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.eyes.train.entity.Configure;
import com.eyes.train.exception.CustomException;
import com.eyes.train.mapper.ConfigureMapper;
import com.eyes.train.model.BO.ConfigureBO;
import com.eyes.train.model.Request.ConfigureUpdateRequest;
import com.eyes.train.model.VO.ConfigureVO;
import com.eyes.train.result.ResultCode;
import com.eyes.train.service.ConfigureService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import java.util.Objects;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
@Service
public class ConfigureServiceImpl extends ServiceImpl<ConfigureMapper, Configure> implements ConfigureService {

  @Override
  public ConfigureVO getConfigure(Integer uid) throws CustomException {
    ConfigureVO configureVO = new ConfigureVO();
    Configure configure = getOne(Wrappers.<Configure>lambdaQuery().eq(Configure::getUserId, uid));
    if (Objects.isNull(configure)) {
      throw new CustomException("用户配置不存在");
    }
    BeanUtils.copyProperties(configure, configureVO);
    return configureVO;
  }

  @Override
  public void updateConfigure(Integer uid, ConfigureUpdateRequest configureUpdateRequest) {
    Configure configure = getOne(Wrappers.<Configure>lambdaQuery().eq(Configure::getUserId, uid));
    if (Objects.isNull(configure)) {
      configure = new Configure();
      configure.setUserId(uid);
      save(configure);
      return;
    }
    BeanUtils.copyProperties(configureUpdateRequest, configure);
    updateById(configure);
  }

  @Override
  public void check(Integer uid, String md5) throws CustomException {
    Configure configure = getOne(Wrappers.<Configure>lambdaQuery().eq(Configure::getUserId, uid));
    if (Objects.isNull(configure)) {
      throw new CustomException("业务执行异常");
    }
    ConfigureBO configureBO = new ConfigureBO();
    BeanUtils.copyProperties(configure, configureBO);
    String json = JSON.toJSONString(configureBO);
    if (!md5.equals(DigestUtils.md5DigestAsHex(json.getBytes()))) {
      throw new CustomException(ResultCode.CONFIGURE_FALSIFY);
    }
  }
}
