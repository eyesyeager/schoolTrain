package com.eyes.train.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.eyes.train.context.Context;
import com.eyes.train.entity.Package;
import com.eyes.train.exception.CustomException;
import com.eyes.train.mapper.PackageMapper;
import com.eyes.train.model.VO.PackageCheckUpdateVO;
import com.eyes.train.service.PackageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.eyes.train.utils.StreamUtils;
import com.eyes.train.utils.WebUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
@Service
public class PackageServiceImpl extends ServiceImpl<PackageMapper, Package> implements PackageService {
  @Resource
  private Context context;

  @Override
  public PackageCheckUpdateVO checkUpdate() throws CustomException {
    Package latestPackage = getOne(Wrappers.<Package>lambdaQuery()
        .select(Package::getVersion)
        .orderBy(true, false, Package::getCreateTime)
        .last("limit 1"));
    if (Objects.isNull(latestPackage)) {
      throw new CustomException("暂无有效发行版");
    }
    return new PackageCheckUpdateVO(latestPackage.getVersion());
  }

  @Override
  public void uploadPackage(String version, MultipartFile multipartFile) throws CustomException {
    // 保存文件
    String filePath;
    try {
      String filename = multipartFile.getOriginalFilename();
      assert filename != null;
      String ext = filename.substring(filename.lastIndexOf(".")).toLowerCase();
      String newName = UUID.randomUUID() + ext;
      filePath = context.getFilePath() + newName;
      File newFile = new File(filePath);
      multipartFile.transferTo(newFile);
    } catch (IOException e) {
      throw new CustomException("文件保存错误");
    }

    // 保存信息
    Package pkg = new Package();
    pkg.setVersion(version);
    pkg.setPath(filePath);
    save(pkg);
  }

  @Override
  public void downloadPackage() throws CustomException {
    Package latestPackage = getOne(Wrappers.<Package>lambdaQuery()
        .select(Package::getPath)
        .orderBy(true, false, Package::getCreateTime)
        .last("limit 1"));
    if (Objects.isNull(latestPackage)) {
      throw new CustomException("暂无有效发行版");
    }

    String file = latestPackage.getPath();
    String ext = file.substring(file.lastIndexOf(".")).toLowerCase();
    HttpServletResponse response = WebUtils.getResponse();
    assert response != null;
    try {
      FileInputStream inputStream = new FileInputStream(file);
      byte[] data = new byte[inputStream.available()];
      inputStream.read(data);

      String diskfilename = "train" + ext;
      response.setContentType("application/x-download;charset=utf-8");
      response.setHeader("Content-Disposition", "attachment; filename=\"" + diskfilename + "\"");
      OutputStream os = response.getOutputStream();
      os.write(data);

      os.flush();
      os.close();
      inputStream.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}