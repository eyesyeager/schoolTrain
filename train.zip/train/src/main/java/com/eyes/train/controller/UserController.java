package com.eyes.train.controller;

import com.eyes.train.exception.CustomException;
import com.eyes.train.model.Request.UserLoginRequest;
import com.eyes.train.result.Result;
import com.eyes.train.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author eyesYeager
 * @since 2023-06-23
 */
@Api(tags = "用户模块")
@Validated
@RestController
@RequestMapping("/user")
public class UserController {
  @Resource
  private UserService userService;

  @ApiOperation("登录")
  @PostMapping("/login")
  public Result<Void> login(@Validated @RequestBody UserLoginRequest userLoginRequest, HttpServletResponse response) throws CustomException {
    userService.login(userLoginRequest, response);
    return Result.success();
  }
}

