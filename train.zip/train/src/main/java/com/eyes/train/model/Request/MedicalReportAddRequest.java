package com.eyes.train.model.Request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDateTime;
import javax.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author eyesYeager
 * @date 2023/6/27 23:18
 */
@Data
@ApiModel
public class MedicalReportAddRequest {
  @ApiModelProperty("状态")
  @NotNull(message = "状态不能为空")
  private Integer status;

  @ApiModelProperty("异常数量")
  @NotNull(message = "异常数量不能为空")
  private Integer errorNum;

  @ApiModelProperty("检测时间")
  @NotNull(message = "检测时间不能为空")
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private LocalDateTime createTime;

  @ApiModelProperty("故障检测详情")
  @NotNull(message = "故障检测详情不能为空")
  private String content;
}
