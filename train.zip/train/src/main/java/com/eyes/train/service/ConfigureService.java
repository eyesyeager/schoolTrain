package com.eyes.train.service;

import com.eyes.train.entity.Configure;
import com.baomidou.mybatisplus.extension.service.IService;
import com.eyes.train.exception.CustomException;
import com.eyes.train.model.Request.ConfigureUpdateRequest;
import com.eyes.train.model.VO.ConfigureVO;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-23
 */
public interface ConfigureService extends IService<Configure> {

  ConfigureVO getConfigure(Integer uid) throws CustomException;

  void updateConfigure(Integer uid, ConfigureUpdateRequest configureUpdateRequest);

  void check(Integer uid, String md5) throws CustomException;
}
