package com.eyes.train.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.eyes.train.entity.Medical;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author eyesYeager
 * @since 2023-06-27
 */
public interface MedicalService extends IService<Medical> {

}
