package com.eyes.train.result;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:13
 */
@Getter
@AllArgsConstructor
public enum ResultCode {
  SUCCESS(200, "success"),

  FAILURE(400, "fail"),

  // 通用异常状态码
  ERROR_INSERT_DB(200, "数据库操作错误，请重试"),

  // 业务异常状态码
  CONFIGURE_FALSIFY(401, "本机配置被篡改"),

  // 全局异常状态码

  NOT_LOGIN(1000, "请先登录"),

  ILLEGAL_TOKEN(1001, "非法身份令牌");

  private final Integer code;

  private final String message;
}