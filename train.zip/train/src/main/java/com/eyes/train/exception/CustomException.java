package com.eyes.train.exception;

import com.eyes.train.result.ResultCode;
import lombok.ToString;

/**
 * @author eyesYeager
 * @date 2023/6/23 13:15
 */
@ToString
public class CustomException extends Exception {
  protected final Integer errorCode;

  protected final String errorMsg;

  public CustomException() {
    this.errorCode = ResultCode.FAILURE.getCode();
    this.errorMsg = ResultCode.FAILURE.getMessage();
  }

  public CustomException(String errorMsg) {
    this.errorCode = ResultCode.FAILURE.getCode();
    this.errorMsg = errorMsg;
  }

  public CustomException(Integer errorCode, String errorMsg) {
    this.errorCode = errorCode;
    this.errorMsg = errorMsg;
  }

  public CustomException(ResultCode resultCode) {
    this.errorCode = resultCode.getCode();
    this.errorMsg = resultCode.getMessage();
  }

  public Integer getErrorCode() {
    return errorCode;
  }

  public String getErrorMsg() {
    return errorMsg;
  }
}
